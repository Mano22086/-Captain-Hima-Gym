package com.example.viewmodel

import android.app.Application
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.GymCloudRepository
import com.example.data.GymCmsRepository
import com.example.model.*
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.random.Random

data class BookingModalUiState(
    val isOpen: Boolean = false,
    val genderCategory: String = "قسم الرجال",
    val bookingType: String = "اشتراك باقة", // "اشتراك باقة" or "حجز حصة جماعية"
    val selectedItemName: String = "باقة 3 شهور - 1,250 ج.م (الأكثر طلباً)",
    val confirmedRecord: BookingRecord? = null
)

class GymViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = GymCmsRepository(application)
    private val cloudRepository = GymCloudRepository(application)
    val cmsState: StateFlow<CaptainHimaCmsState> = repository.cmsState

    private val _hasEnteredApp = MutableStateFlow(
        !repository.cmsState.value.activeSubscriptionCode.isNullOrBlank()
    )
    val hasEnteredApp: StateFlow<Boolean> = _hasEnteredApp.asStateFlow()

    private val _isCodeEntryModalOpen = MutableStateFlow(false)
    val isCodeEntryModalOpen: StateFlow<Boolean> = _isCodeEntryModalOpen.asStateFlow()

    private val _currentTab = MutableStateFlow(MainTab.HOME)
    val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

    private val _selectedStoryIndex = MutableStateFlow(0)
    val selectedStoryIndex: StateFlow<Int> = _selectedStoryIndex.asStateFlow()

    private val _isAudioMuted = MutableStateFlow(false)
    val isAudioMuted: StateFlow<Boolean> = _isAudioMuted.asStateFlow()

    private val _classFilter = MutableStateFlow(ClassGenderFilter.ALL)
    val classFilter: StateFlow<ClassGenderFilter> = _classFilter.asStateFlow()

    private val _galleryFilter = MutableStateFlow(GalleryCategory.ALL)
    val galleryFilter: StateFlow<GalleryCategory> = _galleryFilter.asStateFlow()

    private val _bookingModalState = MutableStateFlow(BookingModalUiState())
    val bookingModalState: StateFlow<BookingModalUiState> = _bookingModalState.asStateFlow()

    private var syncJobs: List<Job> = emptyList()

    fun enterAsNewMember() {
        _hasEnteredApp.value = true
    }

    fun returnToWelcomePortal() {
        _hasEnteredApp.value = false
    }

    fun openCodeEntryModal() {
        _isCodeEntryModalOpen.value = true
    }

    fun closeCodeEntryModal() {
        _isCodeEntryModalOpen.value = false
    }

    fun verifyAndActivateSubscriptionCode(
        rawCode: String,
        navigateToSubscriptionTab: Boolean = true
    ): Boolean {
        val code = rawCode.trim().uppercase()
        if (code.isEmpty()) return false

        val state = cmsState.value
        val existingSub = state.subscriptions.firstOrNull { it.code.equals(code, ignoreCase = true) }
        if (existingSub != null) {
            repository.updateState { current ->
                current.copy(activeSubscriptionCode = existingSub.code)
            }
            _hasEnteredApp.value = true
            _isCodeEntryModalOpen.value = false
            if (navigateToSubscriptionTab) {
                _currentTab.value = MainTab.SUBSCRIPTION
            }
            return true
        }

        // Check if it matches any booking reference code
        val matchingBooking = state.bookings.firstOrNull {
            it.referenceCode.equals(code, ignoreCase = true)
        }
        if (matchingBooking != null) {
            val generatedSub = createSubscriptionFromBooking(matchingBooking, state.packages)
            repository.updateState { current ->
                current.copy(
                    subscriptions = listOf(generatedSub) + current.subscriptions,
                    activeSubscriptionCode = generatedSub.code
                )
            }
            _hasEnteredApp.value = true
            _isCodeEntryModalOpen.value = false
            if (navigateToSubscriptionTab) {
                _currentTab.value = MainTab.SUBSCRIPTION
            }
            return true
        }

        return false
    }

    fun clearActiveSubscriptionCode() {
        repository.updateState { current ->
            current.copy(activeSubscriptionCode = null)
        }
    }

    fun renewOrUpgradeSubscription(
        subscriptionCode: String,
        selectedPackage: MembershipPackage,
        onRenewed: (MemberSubscription) -> Unit = {}
    ) {
        val addedDays = selectedPackage.durationMonths * 30
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
        val cal = Calendar.getInstance()
        val currentSub = cmsState.value.subscriptions.firstOrNull {
            it.code.equals(subscriptionCode, ignoreCase = true)
        } ?: return

        val newRemainingDays = currentSub.remainingDays + addedDays
        val newTotalDays = currentSub.totalDays + addedDays
        cal.add(Calendar.DAY_OF_YEAR, newRemainingDays)
        val newEndDate = dateFormat.format(cal.time)

        val updatedSub = currentSub.copy(
            packageId = selectedPackage.id,
            packageTitle = "${selectedPackage.title} - ${selectedPackage.discountedPriceEgp} ج.م (مُجدد ✨)",
            pricePaidEgp = selectedPackage.discountedPriceEgp,
            durationMonths = selectedPackage.durationMonths,
            totalDays = newTotalDays,
            remainingDays = newRemainingDays,
            endDate = newEndDate,
            statusAr = "نشط وتم التجديد بنجاح ✅",
            freezeDaysAvailable = currentSub.freezeDaysAvailable + (selectedPackage.durationMonths * 3),
            freeInvitationsLeft = currentSub.freeInvitationsLeft + selectedPackage.durationMonths,
            perks = selectedPackage.perks
        )

        repository.updateState { state ->
            val updatedList = state.subscriptions.map {
                if (it.code.equals(subscriptionCode, ignoreCase = true)) updatedSub else it
            }
            state.copy(
                subscriptions = updatedList,
                activeSubscriptionCode = updatedSub.code
            )
        }
        onRenewed(updatedSub)
    }

    fun buildWhatsAppRenewalUrl(sub: MemberSubscription, pkg: MembershipPackage): String {
        val whatsappIntl = cmsState.value.brandInfo.whatsappIntl
        val message = buildString {
            appendLine("⚡ *طلب تجديد / ترقية اشتراك - كابتن هيما جيم* ⚡")
            appendLine("━━━━━━━━━━━━━━━━━━")
            appendLine("🔑 *كود الاشتراك:* ${sub.code}")
            appendLine("👤 *الاسم بالكامل:* ${sub.fullName}")
            appendLine("📱 *رقم الهاتف:* ${sub.phone}")
            appendLine("🏋️ *القسم:* ${sub.genderCategory}")
            appendLine("🏆 *الباقة المطلوبة للتجديد:* ${pkg.title} (${pkg.discountedPriceEgp} ج.م بدلاً من ${pkg.originalPriceEgp} ج.م - خصم 50%)")
            appendLine("⏳ *المدة المتبقية بعد التجديد:* ${sub.remainingDays} يوم (حتى ${sub.endDate})")
            appendLine("━━━━━━━━━━━━━━━━━━")
            append("📍 المنشية سيتي، الدور الثاني، شارع المنشية - فيصل")
        }
        return "https://wa.me/$whatsappIntl?text=${Uri.encode(message)}"
    }

    fun startCloudSync() {
        stopCloudSync()

        val configJob = viewModelScope.launch {
            cloudRepository.observeGymConfig()
                .catch { e -> Log.e("GymViewModel", "observeGymConfig error", e) }
                .collect { cloudConfig ->
                    if (cloudConfig != null) {
                        repository.updateState { state ->
                            val parsePrice = { str: String, fallback: Int ->
                                str.replace(",", "").trim().toIntOrNull() ?: fallback
                            }
                            val updatedPackages = state.packages.map { pkg ->
                                when (pkg.id) {
                                    "pkg_1m" -> {
                                        val p = parsePrice(cloudConfig.pkg1mPrice, pkg.discountedPriceEgp)
                                        pkg.copy(discountedPriceEgp = p, originalPriceEgp = p * 2)
                                    }
                                    "pkg_3m" -> {
                                        val p = parsePrice(cloudConfig.pkg3mPrice, pkg.discountedPriceEgp)
                                        pkg.copy(discountedPriceEgp = p, originalPriceEgp = p * 2)
                                    }
                                    "pkg_6m" -> {
                                        val p = parsePrice(cloudConfig.pkg6mPrice, pkg.discountedPriceEgp)
                                        pkg.copy(discountedPriceEgp = p, originalPriceEgp = p * 2)
                                    }
                                    "pkg_12m" -> {
                                        val p = parsePrice(cloudConfig.pkg12mPrice, pkg.discountedPriceEgp)
                                        pkg.copy(discountedPriceEgp = p, originalPriceEgp = p * 2)
                                    }
                                    else -> pkg
                                }
                            }
                            state.copy(
                                brandInfo = state.brandInfo.copy(
                                    phoneDisplay = cloudConfig.phoneDisplay.ifBlank { state.brandInfo.phoneDisplay },
                                    addressAr = cloudConfig.addressAr.ifBlank { state.brandInfo.addressAr },
                                    workingHours = cloudConfig.workingHours.ifBlank { state.brandInfo.workingHours },
                                    tiktokUrl = cloudConfig.tiktokUrl.ifBlank { state.brandInfo.tiktokUrl },
                                    facebookPageUrl = cloudConfig.facebookPageUrl.ifBlank { state.brandInfo.facebookPageUrl },
                                    instagramUrl = cloudConfig.instagramUrl.ifBlank { state.brandInfo.instagramUrl },
                                    googleMapsUrl = cloudConfig.googleMapsUrl.ifBlank { state.brandInfo.googleMapsUrl }
                                ),
                                packages = updatedPackages
                            )
                        }
                    }
                }
        }

        if (Firebase.auth.currentUser == null) {
            syncJobs = listOf(configJob)
            return
        }

        val bookingsJob = viewModelScope.launch {
            cloudRepository.observeMyBookings()
                .catch { e -> Log.e("GymViewModel", "observeMyBookings error", e) }
                .collect { cloudBookings ->
                    repository.updateState { state ->
                        state.copy(bookings = cloudBookings)
                    }
                }
        }

        val commentsJob = viewModelScope.launch {
            cloudRepository.observeStoryComments()
                .catch { e -> Log.e("GymViewModel", "observeStoryComments error", e) }
                .collect { cloudCommentsByStory ->
                    if (cloudCommentsByStory.isNotEmpty()) {
                        repository.updateState { state ->
                            val updatedStories = state.stories.map { story ->
                                val remoteList = cloudCommentsByStory[story.id].orEmpty()
                                val existingIds = remoteList.map { it.id }.toSet()
                                val merged = remoteList + story.comments.filterNot { it.id in existingIds }
                                story.copy(comments = merged)
                            }
                            state.copy(stories = updatedStories)
                        }
                    }
                }
        }

        syncJobs = listOf(bookingsJob, configJob, commentsJob)
    }

    fun stopCloudSync() {
        syncJobs.forEach { it.cancel() }
        syncJobs = emptyList()
    }

    fun selectTab(tab: MainTab) {
        _currentTab.value = tab
    }

    fun openStoryAtIndex(index: Int) {
        _selectedStoryIndex.value = index
        markStoryViewed(index)
        _currentTab.value = MainTab.STORIES
    }

    fun onStoryPageChanged(index: Int) {
        _selectedStoryIndex.value = index
        markStoryViewed(index)
    }

    private fun markStoryViewed(index: Int) {
        repository.updateState { state ->
            val updatedStories = state.stories.mapIndexed { idx, s ->
                if (idx == index) s.copy(isViewed = true) else s
            }
            state.copy(stories = updatedStories)
        }
    }

    fun toggleAudioMute() {
        _isAudioMuted.value = !_isAudioMuted.value
    }

    fun toggleFollowGym() {
        repository.updateState { state ->
            state.copy(isFollowingGym = !state.isFollowingGym)
        }
    }

    fun toggleStoryLike(storyId: String) {
        repository.updateState { state ->
            val updated = state.stories.map { story ->
                if (story.id == storyId) {
                    val nextLiked = !story.isLiked
                    val nextCount = if (nextLiked) story.likesCount + 1 else (story.likesCount - 1).coerceAtLeast(0)
                    story.copy(isLiked = nextLiked, likesCount = nextCount)
                } else story
            }
            state.copy(stories = updated)
        }
    }

    fun likeStoryOnDoubleTap(storyId: String) {
        repository.updateState { state ->
            val updated = state.stories.map { story ->
                if (story.id == storyId) {
                    val nextCount = if (!story.isLiked) story.likesCount + 1 else story.likesCount + 1
                    story.copy(isLiked = true, likesCount = nextCount)
                } else story
            }
            state.copy(stories = updated)
        }
    }

    fun addStoryComment(storyId: String, authorName: String, commentText: String) {
        val defaultName = Firebase.auth.currentUser?.displayName ?: "بطل كابتن هيما جيم 💪"
        val cleanAuthor = authorName.trim().ifEmpty { defaultName }
        val cleanText = commentText.trim()
        if (cleanText.isEmpty()) return

        val commentId = "c_${System.currentTimeMillis()}"
        val newComment = StoryComment(
            id = commentId,
            authorName = cleanAuthor,
            text = cleanText,
            timestamp = "الآن"
        )

        repository.updateState { state ->
            val updated = state.stories.map { story ->
                if (story.id == storyId) {
                    story.copy(comments = listOf(newComment) + story.comments)
                } else story
            }
            state.copy(stories = updated)
        }

        if (Firebase.auth.currentUser != null) {
            viewModelScope.launch {
                runCatching {
                    cloudRepository.addStoryComment(
                        commentId = commentId,
                        storyId = storyId,
                        authorName = cleanAuthor,
                        text = cleanText
                    )
                }.onFailure { e ->
                    Log.e("GymViewModel", "Failed to sync story comment to Firestore", e)
                }
            }
        }
    }

    fun incrementStoryShare(storyId: String) {
        repository.updateState { state ->
            val updated = state.stories.map { story ->
                if (story.id == storyId) {
                    story.copy(sharesCount = story.sharesCount + 1)
                } else story
            }
            state.copy(stories = updated)
        }
    }

    fun setClassGenderFilter(filter: ClassGenderFilter) {
        _classFilter.value = filter
    }

    fun setGalleryCategoryFilter(category: GalleryCategory) {
        _galleryFilter.value = category
    }

    fun openBookingModal(
        bookingType: String = "اشتراك باقة",
        selectedItemName: String = "باقة 3 شهور - 1,250 ج.م (الأكثر طلباً)",
        genderCategory: String = "قسم الرجال"
    ) {
        _bookingModalState.value = BookingModalUiState(
            isOpen = true,
            genderCategory = genderCategory,
            bookingType = bookingType,
            selectedItemName = selectedItemName,
            confirmedRecord = null
        )
    }

    fun closeBookingModal() {
        _bookingModalState.value = _bookingModalState.value.copy(
            isOpen = false,
            confirmedRecord = null
        )
    }

    fun submitBooking(
        fullName: String,
        phone: String,
        genderCategory: String,
        bookingType: String,
        selectedItemName: String,
        preferredDateTime: String,
        notes: String,
        onSubmitted: (BookingRecord) -> Unit = {}
    ) {
        val refNum = Random.nextInt(10, 99)
        val suffix = listOf("JMD", "VIP", "GYM", "PRO").random()
        val refCode = "KH${refNum}${suffix}"
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.ENGLISH)
        val bookingId = "bk_${System.currentTimeMillis()}"
        val cleanName = fullName.trim().ifEmpty {
            Firebase.auth.currentUser?.displayName ?: "مشترك جديد"
        }
        val cleanPhone = phone.trim().ifEmpty { "01039157200" }
        val cleanDate = preferredDateTime.trim().ifEmpty { "اليوم - في أقرب موعد" }
        val cleanNotes = notes.trim()

        val record = BookingRecord(
            id = bookingId,
            referenceCode = refCode,
            fullName = cleanName,
            phone = cleanPhone,
            genderCategory = genderCategory,
            bookingType = bookingType,
            selectedItemName = selectedItemName,
            preferredDateTime = cleanDate,
            notes = cleanNotes,
            createdAt = dateFormat.format(Date())
        )

        val generatedSub = createSubscriptionFromBooking(record, cmsState.value.packages)

        repository.updateState { state ->
            state.copy(
                bookings = listOf(record) + state.bookings,
                subscriptions = listOf(generatedSub) + state.subscriptions
            )
        }

        if (Firebase.auth.currentUser != null) {
            viewModelScope.launch {
                runCatching {
                    cloudRepository.createBooking(
                        bookingId = bookingId,
                        referenceCode = refCode,
                        fullName = cleanName,
                        phone = cleanPhone,
                        genderCategory = genderCategory,
                        bookingType = bookingType,
                        selectedItemName = selectedItemName,
                        preferredDateTime = cleanDate,
                        notes = cleanNotes
                    )
                }.onFailure { e ->
                    Log.e("GymViewModel", "Failed to sync booking to Firestore", e)
                }
            }
        }

        _bookingModalState.value = _bookingModalState.value.copy(
            confirmedRecord = record
        )
        onSubmitted(record)
    }

    private fun createSubscriptionFromBooking(
        record: BookingRecord,
        packages: List<MembershipPackage>
    ): MemberSubscription {
        val matchedPkg = packages.firstOrNull { pkg ->
            record.selectedItemName.contains(pkg.title)
        } ?: packages.getOrElse(1) { packages.first() }

        val durationMonths = matchedPkg.durationMonths
        val totalDays = durationMonths * 30
        val dayFormat = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
        val cal = Calendar.getInstance()
        val startDate = dayFormat.format(cal.time)
        cal.add(Calendar.DAY_OF_YEAR, totalDays)
        val endDate = dayFormat.format(cal.time)

        return MemberSubscription(
            code = record.referenceCode.uppercase(),
            fullName = record.fullName,
            phone = record.phone,
            genderCategory = record.genderCategory,
            packageId = matchedPkg.id,
            packageTitle = record.selectedItemName,
            pricePaidEgp = matchedPkg.discountedPriceEgp,
            durationMonths = durationMonths,
            totalDays = totalDays,
            remainingDays = totalDays,
            startDate = startDate,
            endDate = endDate,
            statusAr = "مؤكد عبر واتساب ونشط ✅",
            freezeDaysAvailable = durationMonths * 4,
            freeInvitationsLeft = durationMonths.coerceAtLeast(1),
            trainerNotes = record.notes.ifBlank { "متابعة شاملة مع كباتن الجيم + جدول تمرين وتغذية" },
            perks = matchedPkg.perks
        )
    }

    fun buildWhatsAppBookingUrl(record: BookingRecord): String {
        val whatsappIntl = cmsState.value.brandInfo.whatsappIntl
        val message = buildString {
            appendLine("🔥 *طلب حجز جديد - كابتن هيما جيم (CAPTAIN HIMA GYM)* 🔥")
            appendLine("━━━━━━━━━━━━━━━━━━")
            appendLine("🔑 *كود الاشتراك والمتابعة:* ${record.referenceCode}")
            appendLine("👤 *الاسم بالكامل:* ${record.fullName}")
            appendLine("📱 *رقم الهاتف / واتساب:* ${record.phone}")
            appendLine("🏋️ *القسم:* ${record.genderCategory}")
            appendLine("📋 *نوع الحجز:* ${record.bookingType}")
            appendLine("⚡ *الباقة / الحصة المختارة:* ${record.selectedItemName}")
            appendLine("📅 *موعد الحضور المفضل:* ${record.preferredDateTime}")
            if (record.notes.isNotBlank()) {
                appendLine("📝 *ملاحظات إضافية:* ${record.notes}")
            }
            appendLine("━━━━━━━━━━━━━━━━━━")
            append("📍 المنشية سيتي، الدور الثاني، شارع المنشية - فيصل")
        }
        return "https://wa.me/$whatsappIntl?text=${Uri.encode(message)}"
    }
}
