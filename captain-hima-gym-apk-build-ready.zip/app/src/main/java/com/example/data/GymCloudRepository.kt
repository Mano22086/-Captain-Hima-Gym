package com.example.data

import android.content.Context
import com.example.R
import com.example.model.BookingRecord
import com.example.model.StoryComment
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Locale

data class CloudGymConfig(
    val phoneDisplay: String = "01039157200",
    val addressAr: String = "المنشية سيتي، الدور الثاني، شارع المنشية متفرع من شارع الملك فيصل، أعلى كشري المدينة - بجوار توكيل التوكيلات التعليمي، المنشية الطوابق، محافظة الجيزة 12814",
    val workingHours: String = "مفتوح 24 ساعة يومياً (7 أيام في الأسبوع) + فترات مخصصة للسيدات بخصوصية تامة",
    val pkg1mPrice: String = "600",
    val pkg3mPrice: String = "1,250",
    val pkg6mPrice: String = "2,000",
    val pkg12mPrice: String = "2,750",
    val tiktokUrl: String = "https://www.tiktok.com/@captain_hima_gym",
    val facebookPageUrl: String = "https://www.facebook.com/CaptainHimaGym",
    val instagramUrl: String = "https://www.instagram.com/captain_hima_gym",
    val googleMapsUrl: String = "https://www.google.com/maps/place/CAPTAIN+HIMA+GYM/@30.0103345,31.1520416,17z/data=!3m1!4b1!4m6!3m5!1s0x145845d9c1f49dbb:0x5df219b46c0b3411!8m2!3d30.0103345!4d31.1520416!16s%2Fg%2F11nvgwdwkx"
)

class GymCloudRepository(
    context: Context,
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(
        context.getString(R.string.firestore_database_id)
    )
) {
    fun observeMyBookings(): Flow<List<BookingRecord>> = callbackFlow {
        val uid = Firebase.auth.currentUser?.uid
        if (uid == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }
        val path = "bookings"
        val registration = db.collection(path)
            .whereEqualTo("userId", uid)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(
                        runCatching { handleFirestoreError(error, OperationType.LIST, path) }
                            .exceptionOrNull() ?: error
                    )
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { it.toBookingRecord() }
                    ?.sortedByDescending { it.createdAt } ?: emptyList()
                trySend(list)
            }
        awaitClose { registration.remove() }
    }

    fun observeGymConfig(): Flow<CloudGymConfig?> = callbackFlow {
        val path = "gym_config/main"
        val registration = db.document(path)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close()
                    return@addSnapshotListener
                }
                if (snapshot != null && snapshot.exists()) {
                    trySend(
                        CloudGymConfig(
                            phoneDisplay = snapshot.getString("phoneDisplay") ?: "01039157200",
                            addressAr = snapshot.getString("addressAr") ?: "",
                            workingHours = snapshot.getString("workingHours") ?: "",
                            pkg1mPrice = snapshot.getString("pkg1mPrice") ?: "600",
                            pkg3mPrice = snapshot.getString("pkg3mPrice") ?: "1,250",
                            pkg6mPrice = snapshot.getString("pkg6mPrice") ?: "2,000",
                            pkg12mPrice = snapshot.getString("pkg12mPrice") ?: "2,750",
                            tiktokUrl = snapshot.getString("tiktokUrl") ?: "https://www.tiktok.com/@captain_hima_gym",
                            facebookPageUrl = snapshot.getString("facebookPageUrl") ?: "https://www.facebook.com/CaptainHimaGym",
                            instagramUrl = snapshot.getString("instagramUrl") ?: "https://www.instagram.com/captain_hima_gym",
                            googleMapsUrl = snapshot.getString("googleMapsUrl") ?: ""
                        )
                    )
                } else {
                    trySend(null)
                }
            }
        awaitClose { registration.remove() }
    }

    fun observeStoryComments(): Flow<Map<String, List<StoryComment>>> = callbackFlow {
        val uid = Firebase.auth.currentUser?.uid
        if (uid == null) {
            trySend(emptyMap())
            close()
            return@callbackFlow
        }
        val path = "story_comments"
        val registration = db.collection(path)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(
                        runCatching { handleFirestoreError(error, OperationType.LIST, path) }
                            .exceptionOrNull() ?: error
                    )
                    return@addSnapshotListener
                }
                val grouped = mutableMapOf<String, MutableList<StoryComment>>()
                snapshot?.documents?.forEach { doc ->
                    val storyId = doc.getString("storyId") ?: return@forEach
                    val comment = StoryComment(
                        id = doc.id,
                        authorName = doc.getString("authorName") ?: "عضو الجيم",
                        text = doc.getString("text") ?: "",
                        timestamp = doc.getTimestamp("createdAt").formatArabicTime()
                    )
                    grouped.getOrPut(storyId) { mutableListOf() }.add(comment)
                }
                trySend(grouped)
            }
        awaitClose { registration.remove() }
    }

    suspend fun createBooking(
        bookingId: String,
        referenceCode: String,
        fullName: String,
        phone: String,
        genderCategory: String,
        bookingType: String,
        selectedItemName: String,
        preferredDateTime: String,
        notes: String
    ) {
        val uid = Firebase.auth.currentUser?.uid
            ?: throw IllegalStateException("Must be signed in to create a booking")
        val path = "bookings/$bookingId"
        val payload = mapOf(
            "userId" to uid,
            "referenceCode" to referenceCode,
            "fullName" to fullName,
            "phone" to phone,
            "genderCategory" to genderCategory,
            "bookingType" to bookingType,
            "selectedItemName" to selectedItemName,
            "preferredDateTime" to preferredDateTime,
            "notes" to notes,
            "status" to "pending",
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            db.document(path).set(payload).await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
        }
    }

    suspend fun getBooking(bookingId: String): BookingRecord? {
        val path = "bookings/$bookingId"
        return try {
            db.document(path).get().await().toBookingRecord()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
        }
    }

    suspend fun addStoryComment(
        commentId: String,
        storyId: String,
        authorName: String,
        text: String
    ) {
        val uid = Firebase.auth.currentUser?.uid
            ?: throw IllegalStateException("Must be signed in to post a comment")
        val path = "story_comments/$commentId"
        val payload = mapOf(
            "userId" to uid,
            "storyId" to storyId,
            "authorName" to authorName,
            "text" to text,
            "createdAt" to FieldValue.serverTimestamp()
        )
        try {
            db.document(path).set(payload).await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
        }
    }

    private fun DocumentSnapshot.toBookingRecord(): BookingRecord? {
        if (!exists()) return null
        val referenceCode = getString("referenceCode") ?: return null
        val fullName = getString("fullName") ?: return null
        val phone = getString("phone") ?: return null
        val genderCategory = getString("genderCategory") ?: "رجال"
        val bookingType = getString("bookingType") ?: "package"
        val selectedItemName = getString("selectedItemName") ?: ""
        val preferredDateTime = getString("preferredDateTime") ?: ""
        val notes = getString("notes") ?: ""
        val createdAtTs = getTimestamp("createdAt")
        return BookingRecord(
            id = id,
            referenceCode = referenceCode,
            fullName = fullName,
            phone = phone,
            genderCategory = genderCategory,
            bookingType = bookingType,
            selectedItemName = selectedItemName,
            preferredDateTime = preferredDateTime,
            notes = notes,
            createdAt = createdAtTs.formatArabicTime()
        )
    }

    private fun Timestamp?.formatArabicTime(): String {
        if (this == null) return "الآن"
        return try {
            SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.forLanguageTag("ar")).format(this.toDate())
        } catch (_: Exception) {
            "الآن"
        }
    }
}
