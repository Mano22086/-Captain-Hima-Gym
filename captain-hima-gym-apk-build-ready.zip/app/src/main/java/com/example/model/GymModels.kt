package com.example.model

import androidx.annotation.DrawableRes

enum class MainTab(val titleAr: String, val testTag: String) {
    HOME("الرئيسية", "tab_home"),
    STORIES("استوري", "tab_stories"),
    PACKAGES("الباقات", "tab_packages"),
    SUBSCRIPTION("اشتراكي", "tab_subscription"),
    GALLERY("المعرض", "tab_gallery"),
    BOOK("احجز", "tab_book")
}

enum class ClassGenderFilter(val labelAr: String) {
    ALL("الكل"),
    MEN("قسم الرجال 💪"),
    LADIES("قسم السيدات 💃")
}

enum class GalleryCategory(val labelAr: String) {
    ALL("الكل"),
    WEIGHTS("صالة الحديد Cybex"),
    SPA("السبا والجاكوزي"),
    CLASSES("الحصص الجماعية"),
    OFFERS("بوسترات العروض")
}

data class GymBrandInfo(
    val nameAr: String = "كابتن هيما جيم",
    val nameEn: String = "CAPTAIN HIMA FITNESS GYM",
    val taglineAr: String = "أقوى جيم في المنشية",
    val taglineEn: String = "Build Your Best Version",
    val officialLogoUrl: String = "https://lh3.googleusercontent.com/gps-cs-s/ANWiy9TxE18nVjffUHGRDfNnpljKI30Ao2_jZCmTHnE8F-2aQ32PUjkcWpe_w54-P-9upFYS1KRdJNNrrf51b0qReHirgDlzbfAl-Pse_t3jVwHVAxMcCvupSJo2qoPSbH7jsd5kVh3sm80431L_",
    val facebookPageUrl: String = "https://www.facebook.com/CaptainHimaGym",
    val facebookCoverPhotoUrl: String = "https://www.facebook.com/photo?fbid=122124538407384387&set=pb.61591531637010.-2207520000",
    val facebookProfilePhotoUrl: String = "https://www.facebook.com/photo?fbid=122124538263384387&set=pb.61591531637010.-2207520000",
    val offersPosterUrl: String = "https://www.facebook.com/photo/?fbid=122148567543384387&set=pb.61591531637010.-2207520000",
    val classesSchedulePosterUrl: String = "https://www.facebook.com/photo/?fbid=122148460221384387&set=pb.61591531637010.-2207520000",
    val instagramUrl: String = "https://www.instagram.com/captain_hima_gym",
    val tiktokUrl: String = "https://www.tiktok.com/@captain_hima_gym",
    val googleMapsUrl: String = "https://www.google.com/maps/place/CAPTAIN+HIMA+GYM/@30.0103345,31.1520416,17z/data=!3m1!4b1!4m6!3m5!1s0x145845d9c1f49dbb:0x5df219b46c0b3411!8m2!3d30.0103345!4d31.1520416!16s%2Fg%2F11nvgwdwkx",
    val addressAr: String = "المنشية سيتي، الدور الثاني، شارع المنشية متفرع من شارع الملك فيصل، أعلى كشري المدينة - بجوار توكيل التوكيلات التعليمي، المنشية الطوابق، محافظة الجيزة 12814",
    val plusCode: String = "2562+4R الهرم، مصر",
    val phoneDisplay: String = "01039157200",
    val whatsappIntl: String = "201039157200",
    val workingHours: String = "مفتوح 24 ساعة يومياً (7 أيام في الأسبوع) + فترات مخصصة للسيدات فقط بخصوصية تامة",
    val ratingScore: String = "5.0"
)

data class StoryComment(
    val id: String,
    val authorName: String,
    val text: String,
    val timestamp: String
)

data class GymStory(
    val id: String,
    val title: String,
    val subtitle: String,
    val badgeText: String,
    val categoryTag: String,
    val programToBook: String,
    val bookingTypePreset: String, // "اشتراك باقة" or "حجز حصة جماعية"
    val genderPreset: String, // "قسم الرجال" or "قسم السيدات"
    @param:DrawableRes val drawableRes: Int,
    val likesCount: Int,
    val isLiked: Boolean,
    val sharesCount: Int,
    val comments: List<StoryComment>,
    val isViewed: Boolean = false,
    val audioTrackTitle: String
)

data class FacilityDepartment(
    val id: String,
    val title: String,
    val subtitle: String,
    val description: String,
    val features: List<String>,
    @param:DrawableRes val drawableRes: Int,
    val badge: String,
    val defaultBookingProgram: String
)

data class MembershipPackage(
    val id: String,
    val title: String,
    val subtitle: String,
    val durationMonths: Int,
    val discountedPriceEgp: Int,
    val originalPriceEgp: Int,
    val discountPercent: Int = 50,
    val badgeText: String,
    val isPopular: Boolean = false,
    val isVip: Boolean = false,
    val perks: List<String>
)

data class GroupClassItem(
    val id: String,
    val nameEn: String,
    val nameAr: String,
    val category: ClassGenderFilter,
    val daysAr: String,
    val timeSlotAr: String,
    val trainerName: String,
    val caloriesBurn: String,
    val intensityAr: String,
    @param:DrawableRes val drawableRes: Int
)

data class GalleryMediaItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val category: GalleryCategory,
    val description: String,
    @param:DrawableRes val drawableRes: Int,
    val externalReferenceUrl: String? = null,
    val badgeText: String
)

data class GymReview(
    val id: String,
    val reviewerName: String,
    val rating: Int = 5,
    val roleBadge: String,
    val dateText: String,
    val commentText: String
)

data class BookingRecord(
    val id: String,
    val referenceCode: String,
    val fullName: String,
    val phone: String,
    val genderCategory: String, // "قسم الرجال" or "قسم السيدات"
    val bookingType: String, // "اشتراك باقة" or "حجز حصة جماعية"
    val selectedItemName: String,
    val preferredDateTime: String,
    val notes: String,
    val createdAt: String
)

data class MemberSubscription(
    val code: String,
    val fullName: String,
    val phone: String,
    val genderCategory: String,
    val packageId: String,
    val packageTitle: String,
    val pricePaidEgp: Int,
    val durationMonths: Int,
    val totalDays: Int,
    val remainingDays: Int,
    val startDate: String,
    val endDate: String,
    val statusAr: String = "نشط ومؤكد عبر واتساب ✅",
    val freezeDaysAvailable: Int = 14,
    val freeInvitationsLeft: Int = 3,
    val trainerNotes: String = "متابعة شاملة لجدول الحديد Cybex + الكارديو + السبا والجاكوزي",
    val perks: List<String> = emptyList()
)

data class CaptainHimaCmsState(
    val brandInfo: GymBrandInfo,
    val stories: List<GymStory>,
    val facilities: List<FacilityDepartment>,
    val packages: List<MembershipPackage>,
    val groupClasses: List<GroupClassItem>,
    val galleryItems: List<GalleryMediaItem>,
    val reviews: List<GymReview>,
    val bookings: List<BookingRecord>,
    val subscriptions: List<MemberSubscription> = emptyList(),
    val activeSubscriptionCode: String? = null,
    val isFollowingGym: Boolean = false
)
