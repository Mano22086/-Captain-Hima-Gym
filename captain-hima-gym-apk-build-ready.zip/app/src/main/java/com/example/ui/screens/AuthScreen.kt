package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.GymBrandInfo
import com.example.ui.components.FacebookBrandBadgeIcon
import com.example.ui.components.GoogleBrandBadgeIcon
import com.example.ui.components.InstagramBrandBadgeIcon
import com.example.ui.components.LuxuryGymAmbientBackground
import com.example.ui.components.TikTokBrandBadgeIcon
import com.example.ui.components.launchExternalUrl
import com.example.ui.theme.*

@Composable
fun AuthScreen(
    brandInfo: GymBrandInfo = GymBrandInfo(),
    onEnterWithCode: (String) -> Boolean,
    onEnterAsNewMember: () -> Unit
) {
    val context = LocalContext.current
    var subscriptionCode by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    LuxuryGymAmbientBackground {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 20.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                color = CardSurfaceDark.copy(alpha = 0.95f),
                shape = RoundedCornerShape(32.dp),
                tonalElevation = 18.dp,
                shadowElevation = 24.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 480.dp)
                    .border(
                        width = 1.5.dp,
                        brush = Brush.linearGradient(
                            listOf(
                                FieryOrange.copy(alpha = 0.75f),
                                WarmGold.copy(alpha = 0.5f),
                                Color.White.copy(alpha = 0.1f)
                            )
                        ),
                        shape = RoundedCornerShape(32.dp)
                    )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 22.dp, vertical = 26.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Gym Official Emblem
                    Box(
                        modifier = Modifier
                            .size(92.dp)
                            .clip(CircleShape)
                            .border(
                                width = 2.5.dp,
                                brush = Brush.linearGradient(listOf(FieryOrange, WarmGold)),
                                shape = CircleShape
                            )
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_launcher_icon_1794007815888),
                            contentDescription = "شعار كابتن هيما جيم",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Surface(
                        color = FieryOrange.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(1.dp, WarmGold.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = null,
                                tint = WarmGold,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = "CAPTAIN HIMA FITNESS GYM • 5.0 ★",
                                style = MaterialTheme.typography.labelMedium,
                                color = WarmGold,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "كابتن هيما جيم",
                        style = MaterialTheme.typography.headlineMedium,
                        color = CrispWhite,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = "أقوى جيم في المنشية • مفتوح 24 ساعة يومياً",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MutedZinc,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Section 1: Subscription Code Box for Existing Members
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(22.dp))
                            .background(ObsidianBlack.copy(alpha = 0.72f))
                            .border(1.dp, WarmGold.copy(alpha = 0.4f), RoundedCornerShape(22.dp))
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCodeScanner,
                                contentDescription = null,
                                tint = WarmGold,
                                modifier = Modifier.size(22.dp)
                            )
                            Text(
                                text = "لديك اشتراك حالي؟ اكتب كود الاشتراك لمتابعة اشتراكك",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = CrispWhite
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Quick Demo Chip for KH37JMD
                        Surface(
                            onClick = {
                                subscriptionCode = "KH37JMD"
                                errorMessage = null
                                onEnterWithCode("KH37JMD")
                            },
                            color = WarmGold.copy(alpha = 0.14f),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, WarmGold.copy(alpha = 0.65f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("portal_demo_code_chip")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "كود تجريبي جاهز: KH37JMD (اضغط للتجربة ⚡)",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = WarmGold
                                )
                                Icon(
                                    imageVector = Icons.Default.Verified,
                                    contentDescription = null,
                                    tint = EmeraldSuccess,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = subscriptionCode,
                            onValueChange = {
                                subscriptionCode = it
                                errorMessage = null
                            },
                            label = { Text("اكتب كود الاشتراك لمتابعة اشتراكك") },
                            placeholder = { Text("مثال: KH37JMD") },
                            leadingIcon = {
                                Icon(Icons.Default.Key, contentDescription = null, tint = FieryOrange)
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("portal_subscription_code_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = FieryOrange,
                                unfocusedBorderColor = GlassBorderWhite,
                                focusedTextColor = CrispWhite,
                                unfocusedTextColor = CrispWhite
                            )
                        )

                        if (errorMessage != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Surface(
                                color = MaterialTheme.colorScheme.error.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(
                                    1.dp,
                                    MaterialTheme.colorScheme.error.copy(alpha = 0.45f)
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = errorMessage ?: "",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CrispWhite,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                val ok = onEnterWithCode(subscriptionCode)
                                if (!ok) {
                                    errorMessage = "يرجى إدخال كود اشتراك صحيح (مثل الكود التجريبي KH37JMD) أو الدخول كمشترك جديد."
                                }
                            },
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = WarmGold,
                                contentColor = ObsidianBlack
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("portal_enter_with_code_button")
                        ) {
                            Icon(Icons.Default.AssignmentTurnedIn, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "متابعة اشتراكي الآن 🔑",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Divider with "أو"
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        HorizontalDivider(modifier = Modifier.weight(1f), color = GlassBorderWhite)
                        Text(
                            text = "  أو للمشتركين الجدد  ",
                            style = MaterialTheme.typography.labelMedium,
                            color = MutedZinc
                        )
                        HorizontalDivider(modifier = Modifier.weight(1f), color = GlassBorderWhite)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Section 2: New Member Prominent Button
                    Button(
                        onClick = onEnterAsNewMember,
                        shape = RoundedCornerShape(18.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = FieryOrange,
                            contentColor = CrispWhite
                        ),
                        contentPadding = PaddingValues(vertical = 16.dp, horizontal = 20.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 58.dp)
                            .testTag("portal_new_member_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocalFireDepartment,
                            contentDescription = null,
                            tint = ChampagneGold,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "مشترك جديد • تصفح الجيم واحجز الآن 🔥",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "شاهد الباقات بخصم 50%، استوريهات الجيم، واحجز باقتك عبر واتساب",
                                style = MaterialTheme.typography.labelSmall,
                                color = ChampagneGold,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Text(
                        text = "تابع صفحاتنا الرسمية على المنصات",
                        style = MaterialTheme.typography.labelMedium,
                        color = MutedZinc
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PortalSocialPill(
                            label = "جوجل",
                            borderColor = WarmGold,
                            icon = { GoogleBrandBadgeIcon(size = 20.dp) },
                            onClick = { launchExternalUrl(context, brandInfo.googleMapsUrl) }
                        )
                        PortalSocialPill(
                            label = "فيسبوك",
                            borderColor = FacebookBlue,
                            icon = { FacebookBrandBadgeIcon(size = 20.dp) },
                            onClick = { launchExternalUrl(context, brandInfo.facebookPageUrl) }
                        )
                        PortalSocialPill(
                            label = "إنستجرام",
                            borderColor = InstagramPink,
                            icon = { InstagramBrandBadgeIcon(size = 20.dp) },
                            onClick = { launchExternalUrl(context, brandInfo.instagramUrl) }
                        )
                        PortalSocialPill(
                            label = "تيك توك",
                            borderColor = Color(0xFF00F2FE),
                            icon = { TikTokBrandBadgeIcon(size = 20.dp) },
                            onClick = { launchExternalUrl(context, brandInfo.tiktokUrl) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PortalSocialPill(
    label: String,
    borderColor: Color,
    icon: @Composable () -> Unit,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        color = ObsidianBlack.copy(alpha = 0.78f),
        shape = RoundedCornerShape(50),
        border = BorderStroke(1.dp, borderColor.copy(alpha = 0.7f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            icon()
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = CrispWhite,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

