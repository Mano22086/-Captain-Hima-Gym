package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.model.*
import com.example.ui.theme.*
import com.example.viewmodel.BookingModalUiState

fun launchExternalUrl(context: Context, url: String) {
    try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    } catch (_: Exception) {
    }
}

fun launchPhoneDialer(context: Context, phone: String) {
    try {
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    } catch (_: Exception) {
    }
}

fun shareTextContent(context: Context, title: String, text: String) {
    try {
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_TEXT, text)
        }
        val chooser = Intent.createChooser(sendIntent, "مشاركة عبر").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    } catch (_: Exception) {
    }
}

@Composable
fun LuxuryGymAmbientBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBlack)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            // Top-right fiery ambient glow orb
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        FieryOrange.copy(alpha = 0.16f),
                        Color.Transparent
                    ),
                    center = Offset(size.width * 0.85f, size.height * 0.08f),
                    radius = size.width * 0.65f
                ),
                center = Offset(size.width * 0.85f, size.height * 0.08f),
                radius = size.width * 0.65f
            )
            // Mid-left royal gold ambient glow orb
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        WarmGold.copy(alpha = 0.10f),
                        Color.Transparent
                    ),
                    center = Offset(size.width * 0.12f, size.height * 0.45f),
                    radius = size.width * 0.6f
                ),
                center = Offset(size.width * 0.12f, size.height * 0.45f),
                radius = size.width * 0.6f
            )
        }
        content()
    }
}

@Composable
fun CaptainHimaLogoAvatar(
    logoUrl: String,
    size: Dp = 48.dp,
    borderWidth: Dp = 2.dp
) {
    val context = LocalContext.current
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(ObsidianBlack)
            .border(
                width = borderWidth,
                brush = Brush.linearGradient(listOf(FieryOrange, WarmGold, FieryOrange)),
                shape = CircleShape
            )
            .padding(2.dp),
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = ImageRequest.Builder(context)
                .data(logoUrl)
                .crossfade(true)
                .build(),
            placeholder = painterResource(id = R.drawable.img_launcher_icon_1794007815888),
            error = painterResource(id = R.drawable.img_launcher_icon_1794007815888),
            contentDescription = "شعار كابتن هيما جيم الرسمي",
            modifier = Modifier
                .fillMaxSize()
                .clip(CircleShape),
            contentScale = ContentScale.Crop
        )
    }
}

@Composable
fun PulsingBookNowButton(
    text: String = "احجز الآن 🔥",
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = "pulsing_book_now_button"
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_cta")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale_pulse"
    )

    Surface(
        onClick = onClick,
        modifier = modifier
            .scale(scale)
            .heightIn(min = 48.dp)
            .testTag(testTag),
        shape = RoundedCornerShape(50),
        color = Color.Transparent,
        shadowElevation = 10.dp
    ) {
        Row(
            modifier = Modifier
                .background(
                    brush = Brush.horizontalGradient(
                        colors = listOf(FieryOrange, Color(0xFFFF8800))
                    ),
                    shape = RoundedCornerShape(50)
                )
                .border(
                    width = 1.dp,
                    brush = Brush.horizontalGradient(
                        colors = listOf(ChampagneGold.copy(alpha = 0.8f), Color.Transparent)
                    ),
                    shape = RoundedCornerShape(50)
                )
                .padding(horizontal = 18.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.LocalFireDepartment,
                contentDescription = null,
                tint = ChampagneGold,
                modifier = Modifier.size(19.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.ExtraBold,
                color = CrispWhite
            )
        }
    }
}

@Composable
fun StickyGymTopHeader(
    brandInfo: GymBrandInfo,
    activeSubscriptionCode: String? = null,
    onSubscriptionCodeClick: () -> Unit = {},
    onBookNowClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Surface(
            color = CardSurfaceDark.copy(alpha = 0.92f),
            tonalElevation = 12.dp,
            shadowElevation = 14.dp,
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    width = 1.dp,
                    brush = SubtleGlassBorderBrush,
                    shape = RoundedCornerShape(24.dp)
                )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    CaptainHimaLogoAvatar(
                        logoUrl = brandInfo.officialLogoUrl,
                        size = 44.dp,
                        borderWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = brandInfo.nameAr,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = CrispWhite,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Surface(
                                color = WarmGold.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(50),
                                border = BorderStroke(1.dp, WarmGold.copy(alpha = 0.6f))
                            ) {
                                Text(
                                    text = "★ ${brandInfo.ratingScore}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = WarmGold,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(EmeraldSuccess)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (activeSubscriptionCode != null) {
                                    "اشتراك نشط: $activeSubscriptionCode"
                                } else {
                                    "مفتوح 24 ساعة • المنشية فيصل"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = if (activeSubscriptionCode != null) WarmGold else MutedZinc,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(6.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        onClick = onSubscriptionCodeClick,
                        shape = RoundedCornerShape(50),
                        color = if (activeSubscriptionCode != null) {
                            EmeraldSuccess.copy(alpha = 0.16f)
                        } else {
                            WarmGold.copy(alpha = 0.16f)
                        },
                        border = BorderStroke(
                            width = 1.dp,
                            color = if (activeSubscriptionCode != null) EmeraldSuccess else WarmGold
                        ),
                        modifier = Modifier
                            .heightIn(min = 42.dp)
                            .testTag("header_subscription_code_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = if (activeSubscriptionCode != null) Icons.Default.Verified else Icons.Default.Key,
                                contentDescription = "كود الاشتراك",
                                tint = if (activeSubscriptionCode != null) EmeraldSuccess else WarmGold,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = activeSubscriptionCode ?: "كود الاشتراك",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (activeSubscriptionCode != null) EmeraldSuccess else WarmGold
                            )
                        }
                    }

                    PulsingBookNowButton(
                        text = "احجز الآن",
                        onClick = onBookNowClick,
                        testTag = "header_book_now_button"
                    )
                }
            }
        }
    }
}

@Composable
fun StoryRingsSection(
    stories: List<GymStory>,
    onStoryClick: (Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp, bottom = 10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(FieryOrange.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Whatshot,
                        contentDescription = null,
                        tint = FieryOrange,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "استوري الجيم المباشر (Reels)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = CrispWhite
                    )
                }
            }
            Surface(
                color = WarmGold.copy(alpha = 0.14f),
                shape = RoundedCornerShape(50),
                border = BorderStroke(1.dp, WarmGold.copy(alpha = 0.4f))
            ) {
                Text(
                    text = "تيك توك الجيم 🔥",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = WarmGold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Modern Vertical Reel Preview Cards instead of basic flat circles
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.testTag("home_story_rings_row")
        ) {
            itemsIndexed(stories) { index, story ->
                val ringBrush = if (story.isViewed) {
                    Brush.linearGradient(listOf(GlassBorderWhite, SubtleZinc))
                } else {
                    Brush.linearGradient(listOf(FieryOrange, WarmGold, LikeCrimson))
                }

                Box(
                    modifier = Modifier
                        .width(114.dp)
                        .height(162.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .border(2.dp, ringBrush, RoundedCornerShape(20.dp))
                        .clickable { onStoryClick(index) }
                        .testTag("story_ring_$index")
                ) {
                    Image(
                        painter = painterResource(id = story.drawableRes),
                        contentDescription = story.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        ObsidianBlack.copy(alpha = 0.25f),
                                        Color.Transparent,
                                        ObsidianBlack.copy(alpha = 0.92f)
                                    )
                                )
                            )
                    )

                    // Top LIVE + Likes Pill
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.TopCenter)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = FieryOrange,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "REEL",
                                style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.sp),
                                fontWeight = FontWeight.ExtraBold,
                                color = CrispWhite,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(ObsidianBlack.copy(alpha = 0.65f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = null,
                                tint = LikeCrimson,
                                modifier = Modifier.size(10.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "${story.likesCount}",
                                style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.sp),
                                color = CrispWhite,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Center Play Circle
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .align(Alignment.Center)
                            .clip(CircleShape)
                            .background(ObsidianBlack.copy(alpha = 0.55f))
                            .border(1.dp, WarmGold.copy(alpha = 0.8f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = CrispWhite,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    // Bottom Title
                    Text(
                        text = story.badgeText.substringBefore("•").trim(),
                        style = MaterialTheme.typography.labelLarge.copy(fontSize = 12.sp),
                        fontWeight = FontWeight.ExtraBold,
                        color = CrispWhite,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                            .padding(horizontal = 8.dp, vertical = 10.dp)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InteractiveBookingModal(
    modalState: BookingModalUiState,
    packages: List<MembershipPackage>,
    classes: List<GroupClassItem>,
    onDismiss: () -> Unit,
    onSubmitBooking: (
        fullName: String,
        phone: String,
        genderCategory: String,
        bookingType: String,
        selectedItemName: String,
        preferredDateTime: String,
        notes: String
    ) -> Unit,
    onConfirmViaWhatsApp: (BookingRecord) -> Unit,
    onActivateBookedCode: (String) -> Unit = {}
) {
    if (!modalState.isOpen) return

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .heightIn(max = 720.dp)
                .border(1.5.dp, LuxuryGoldBorderBrush, RoundedCornerShape(28.dp)),
            shape = RoundedCornerShape(28.dp),
            color = CardSurfaceDark,
            shadowElevation = 24.dp
        ) {
            val confirmed = modalState.confirmedRecord
            if (confirmed != null) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(76.dp)
                            .clip(CircleShape)
                            .background(EmeraldSuccess.copy(alpha = 0.18f))
                            .border(2.dp, EmeraldSuccess, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = null,
                            tint = EmeraldSuccess,
                            modifier = Modifier.size(42.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "تم تسجيل حجزك وإصدار كود اشتراكك! 🎉",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = CrispWhite,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "أكد حجزك عبر واتساب ثم اضغط على متابعة اشتراكك بالأسفل لعرض باقتك والمدة المتبقية.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MutedZinc,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Surface(
                        color = CardSurfaceElevated,
                        shape = RoundedCornerShape(20.dp),
                        border = BorderStroke(1.dp, WarmGold.copy(alpha = 0.55f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "كود الاشتراك والمتابعة الخاص بك",
                                style = MaterialTheme.typography.labelMedium,
                                color = MutedZinc
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = confirmed.referenceCode,
                                style = MaterialTheme.typography.headlineLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = WarmGold
                            )
                            HorizontalDivider(
                                modifier = Modifier.padding(vertical = 10.dp),
                                color = GlassBorderWhite
                            )
                            BookingSummaryRow("الاسم:", confirmed.fullName)
                            BookingSummaryRow("الهاتف:", confirmed.phone)
                            BookingSummaryRow("القسم:", confirmed.genderCategory)
                            BookingSummaryRow("الاختيار:", confirmed.selectedItemName)
                            BookingSummaryRow("الموعد:", confirmed.preferredDateTime)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { onConfirmViaWhatsApp(confirmed) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("modal_confirm_whatsapp_button"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = WhatsAppGreen,
                            contentColor = CrispWhite
                        )
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "1. تأكيد الحجز عبر واتساب الآن 💬",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = { onActivateBookedCode(confirmed.referenceCode) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("modal_activate_code_button"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = WarmGold,
                            contentColor = ObsidianBlack
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Key,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "2. متابعة اشتراكي بالكود (${confirmed.referenceCode}) 🔑",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("إغلاق والعودة للتطبيق", color = MutedZinc)
                    }
                }
            } else {
                var fullName by remember { mutableStateOf("") }
                var phone by remember { mutableStateOf("") }
                var genderCategory by remember(modalState.genderCategory) {
                    mutableStateOf(modalState.genderCategory)
                }
                var bookingType by remember(modalState.bookingType) {
                    mutableStateOf(modalState.bookingType)
                }

                val packageOptions = remember(packages) {
                    packages.map { "${it.title} - ${it.discountedPriceEgp} ج.م بدلاً من ${it.originalPriceEgp} ج.م" }
                }
                val classOptions = remember(classes) {
                    classes.map { "${it.nameAr} (${it.daysAr})" } + listOf(
                        "جلسة السبا والجاكوزي والساونا",
                        "التدريب الشخصي والتغذية (Personal Training)"
                    )
                }

                val currentOptions = if (bookingType == "اشتراك باقة") packageOptions else classOptions
                var selectedItemName by remember(modalState.selectedItemName, bookingType) {
                    mutableStateOf(
                        currentOptions.firstOrNull { it.contains(modalState.selectedItemName.take(10)) }
                            ?: currentOptions.firstOrNull()
                            ?: modalState.selectedItemName
                    )
                }
                var preferredDateTime by remember { mutableStateOf("اليوم - الساعة 7:00 مساءً") }
                var notes by remember { mutableStateOf("") }
                var showError by remember { mutableStateOf(false) }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(FieryOrange.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.LocalFireDepartment,
                                    contentDescription = null,
                                    tint = FieryOrange,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "بطاقة الحجز الفوري VIP",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = CrispWhite
                                )
                                Text(
                                    text = "خصم 50% حصري • تأكيد فوري عبر واتساب",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = WarmGold
                                )
                            }
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إغلاق",
                                tint = MutedZinc
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = fullName,
                        onValueChange = {
                            fullName = it
                            showError = false
                        },
                        label = { Text("الاسم بالكامل *") },
                        placeholder = { Text("مثال: أحمد محمد علي") },
                        leadingIcon = {
                            Icon(Icons.Default.Person, contentDescription = null, tint = FieryOrange)
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("booking_name_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = FieryOrange,
                            unfocusedBorderColor = GlassBorderWhite,
                            focusedTextColor = CrispWhite,
                            unfocusedTextColor = CrispWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = phone,
                        onValueChange = {
                            phone = it
                            showError = false
                        },
                        label = { Text("رقم الهاتف / واتساب *") },
                        placeholder = { Text("010XXXXXXXX") },
                        leadingIcon = {
                            Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = FieryOrange)
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("booking_phone_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = FieryOrange,
                            unfocusedBorderColor = GlassBorderWhite,
                            focusedTextColor = CrispWhite,
                            unfocusedTextColor = CrispWhite
                        )
                    )

                    if (showError) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "يرجى إدخال الاسم ورقم الهاتف لتأكيد الحجز",
                            color = LikeCrimson,
                            style = MaterialTheme.typography.labelMedium
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "اختر القسم:",
                        style = MaterialTheme.typography.labelLarge,
                        color = CrispWhite
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        listOf("قسم الرجال", "قسم السيدات").forEach { cat ->
                            val selected = genderCategory == cat
                            Surface(
                                onClick = { genderCategory = cat },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(14.dp),
                                color = if (selected) FieryOrange.copy(alpha = 0.22f) else CardSurfaceElevated,
                                border = BorderStroke(
                                    width = if (selected) 2.dp else 1.dp,
                                    color = if (selected) FieryOrange else GlassBorderWhite
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 12.dp, horizontal = 10.dp),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (cat == "قسم الرجال") "💪 قسم الرجال" else "💃 قسم السيدات",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = if (selected) CrispWhite else MutedZinc
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "نوع الحجز:",
                        style = MaterialTheme.typography.labelLarge,
                        color = CrispWhite
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        listOf("اشتراك باقة", "حجز حصة جماعية").forEach { type ->
                            val selected = bookingType == type
                            Surface(
                                onClick = {
                                    bookingType = type
                                    val newPool = if (type == "اشتراك باقة") packageOptions else classOptions
                                    selectedItemName = newPool.firstOrNull() ?: ""
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(14.dp),
                                color = if (selected) WarmGold.copy(alpha = 0.2f) else CardSurfaceElevated,
                                border = BorderStroke(
                                    width = if (selected) 2.dp else 1.dp,
                                    color = if (selected) WarmGold else GlassBorderWhite
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 12.dp, horizontal = 10.dp),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (type == "اشتراك باقة") "🏆 اشتراك باقة" else "⚡ حصة / سبا",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = if (selected) WarmGold else MutedZinc
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = if (bookingType == "اشتراك باقة") "اختر الباقة (خصم 50%):" else "اختر الحصة أو الخدمة:",
                        style = MaterialTheme.typography.labelLarge,
                        color = CrispWhite
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        currentOptions.forEach { option ->
                            val isSelected = selectedItemName == option
                            Surface(
                                onClick = { selectedItemName = option },
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) FieryOrange.copy(alpha = 0.18f) else CardSurfaceElevated,
                                border = BorderStroke(
                                    width = if (isSelected) 1.5.dp else 1.dp,
                                    color = if (isSelected) FieryOrange else GlassBorderWhite
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = isSelected,
                                        onClick = { selectedItemName = option },
                                        colors = RadioButtonDefaults.colors(selectedColor = FieryOrange)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = option,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) CrispWhite else MutedZinc
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = preferredDateTime,
                        onValueChange = { preferredDateTime = it },
                        label = { Text("تاريخ وموعد الحضور المفضل") },
                        leadingIcon = {
                            Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = WarmGold)
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = FieryOrange,
                            unfocusedBorderColor = GlassBorderWhite,
                            focusedTextColor = CrispWhite,
                            unfocusedTextColor = CrispWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("ملاحظات إضافية (اختياري)") },
                        placeholder = { Text("مثال: أرغب في متابعة خاصة أو استفسار عن مواعيد السيدات") },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = FieryOrange,
                            unfocusedBorderColor = GlassBorderWhite,
                            focusedTextColor = CrispWhite,
                            unfocusedTextColor = CrispWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    PulsingBookNowButton(
                        text = "تأكيد الحجز واستلام الكود 🔥",
                        onClick = {
                            if (fullName.isBlank() || phone.isBlank()) {
                                showError = true
                            } else {
                                onSubmitBooking(
                                    fullName,
                                    phone,
                                    genderCategory,
                                    bookingType,
                                    selectedItemName,
                                    preferredDateTime,
                                    notes
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "booking_submit_button"
                    )
                }
            }
        }
    }
}

@Composable
private fun BookingSummaryRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = MutedZinc)
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = CrispWhite,
            modifier = Modifier.padding(start = 12.dp)
        )
    }
}

@Composable
fun SubscriptionCodeEntryDialog(
    isOpen: Boolean,
    onDismiss: () -> Unit,
    onVerifyCode: (String) -> Boolean
) {
    if (!isOpen) return

    var codeInput by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf<String?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .border(1.5.dp, LuxuryGoldBorderBrush, RoundedCornerShape(28.dp)),
            shape = RoundedCornerShape(28.dp),
            color = CardSurfaceDark,
            shadowElevation = 24.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Key,
                            contentDescription = null,
                            tint = WarmGold,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = "إدخال كود الاشتراك 🔑",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = CrispWhite
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = MutedZinc)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "بعد تأكيد حجزك عبر واتساب، اكتب كود الاشتراك هنا لعرض تفاصيل باقتك، المدة المتبقية، وتجديد اشتراكك.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MutedZinc,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(14.dp))

                Surface(
                    onClick = {
                        codeInput = "KH37JMD"
                        errorText = null
                        onVerifyCode("KH37JMD")
                    },
                    color = WarmGold.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, WarmGold.copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "تجربة الكود التجريبي: KH37JMD ⚡",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = WarmGold
                        )
                        Icon(
                            imageVector = Icons.Default.TouchApp,
                            contentDescription = null,
                            tint = WarmGold,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = codeInput,
                    onValueChange = {
                        codeInput = it
                        errorText = null
                    },
                    label = { Text("اكتب كود الاشتراك") },
                    placeholder = { Text("KH37JMD") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = FieryOrange,
                        unfocusedBorderColor = GlassBorderWhite,
                        focusedTextColor = CrispWhite,
                        unfocusedTextColor = CrispWhite
                    )
                )

                if (errorText != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = errorText ?: "",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.error,
                        textAlign = TextAlign.Center
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val ok = onVerifyCode(codeInput)
                        if (!ok) {
                            errorText = "كود غير صحيح، جرب الكود التجريبي KH37JMD أو كود حجزك."
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = FieryOrange,
                        contentColor = CrispWhite
                    )
                ) {
                    Text(
                        text = "متابعة اشتراكي الآن 🔥",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }
        }
    }
}

