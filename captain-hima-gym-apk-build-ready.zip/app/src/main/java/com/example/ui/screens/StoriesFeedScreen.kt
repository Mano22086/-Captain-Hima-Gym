package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CaptainHimaCmsState
import com.example.model.GymStory
import com.example.ui.components.*
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

data class FloatingHeartParticle(
    val id: Long,
    val offset: Offset
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoriesFeedScreen(
    cmsState: CaptainHimaCmsState,
    initialStoryIndex: Int,
    isAudioMuted: Boolean,
    onStoryPageChanged: (Int) -> Unit,
    onToggleAudioMute: () -> Unit,
    onToggleFollowGym: () -> Unit,
    onToggleLike: (String) -> Unit,
    onDoubleTapLike: (String) -> Unit,
    onAddComment: (storyId: String, authorName: String, commentText: String) -> Unit,
    onShareStory: (String) -> Unit,
    onBookStoryWorkout: (GymStory) -> Unit
) {
    val stories = cmsState.stories
    val pagerState = rememberPagerState(
        initialPage = initialStoryIndex.coerceIn(0, (stories.size - 1).coerceAtLeast(0)),
        pageCount = { stories.size }
    )

    LaunchedEffect(initialStoryIndex) {
        val target = initialStoryIndex.coerceIn(0, (stories.size - 1).coerceAtLeast(0))
        if (pagerState.currentPage != target) {
            pagerState.scrollToPage(target)
        }
    }

    LaunchedEffect(pagerState.currentPage) {
        onStoryPageChanged(pagerState.currentPage)
    }

    var activeCommentsStoryId by remember { mutableStateOf<String?>(null) }
    var activeShareStory by remember { mutableStateOf<GymStory?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .testTag("stories_feed_screen")
    ) {
        VerticalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize()
        ) { pageIndex ->
            val story = stories[pageIndex]
            TikTokStorySlide(
                story = story,
                storyIndex = pageIndex,
                totalStories = stories.size,
                officialLogoUrl = cmsState.brandInfo.officialLogoUrl,
                isFollowingGym = cmsState.isFollowingGym,
                isAudioMuted = isAudioMuted,
                onToggleAudioMute = onToggleAudioMute,
                onToggleFollow = onToggleFollowGym,
                onToggleLike = { onToggleLike(story.id) },
                onDoubleTapLike = { onDoubleTapLike(story.id) },
                onOpenComments = { activeCommentsStoryId = story.id },
                onOpenShare = {
                    onShareStory(story.id)
                    activeShareStory = story
                },
                onBookThisWorkout = { onBookStoryWorkout(story) }
            )
        }

        // Comments Glassmorphic Bottom Sheet Drawer
        val commentStory = stories.firstOrNull { it.id == activeCommentsStoryId }
        if (commentStory != null) {
            StoryCommentsBottomSheet(
                story = commentStory,
                onDismiss = { activeCommentsStoryId = null },
                onSubmitComment = { author, text ->
                    onAddComment(commentStory.id, author, text)
                }
            )
        }

        // Share Story Modal
        val shareStory = activeShareStory
        if (shareStory != null) {
            StoryShareBottomSheet(
                story = shareStory,
                facebookUrl = cmsState.brandInfo.facebookPageUrl,
                whatsappIntl = cmsState.brandInfo.whatsappIntl,
                onDismiss = { activeShareStory = null }
            )
        }
    }
}

@Composable
private fun TikTokStorySlide(
    story: GymStory,
    storyIndex: Int,
    totalStories: Int,
    officialLogoUrl: String,
    isFollowingGym: Boolean,
    isAudioMuted: Boolean,
    onToggleAudioMute: () -> Unit,
    onToggleFollow: () -> Unit,
    onToggleLike: () -> Unit,
    onDoubleTapLike: () -> Unit,
    onOpenComments: () -> Unit,
    onOpenShare: () -> Unit,
    onBookThisWorkout: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val heartParticles = remember { mutableStateListOf<FloatingHeartParticle>() }

    // Subtle Ken-Burns dynamic zoom for living reel feel
    val infiniteTransition = rememberInfiniteTransition(label = "story_motion")
    val zoomScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 8000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ken_burns_zoom"
    )

    // Optional subtle athletic pulse sound effect when unmuted on page enter
    LaunchedEffect(story.id, isAudioMuted) {
        if (!isAudioMuted) {
            try {
                val toneGen = ToneGenerator(AudioManager.STREAM_MUSIC, 25)
                toneGen.startTone(ToneGenerator.TONE_PROP_BEEP, 60)
                delay(100)
                toneGen.release()
            } catch (_: Exception) {
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(story.id) {
                detectTapGestures(
                    onDoubleTap = { tapOffset ->
                        onDoubleTapLike()
                        val particle = FloatingHeartParticle(
                            id = System.nanoTime(),
                            offset = tapOffset
                        )
                        heartParticles.add(particle)
                        coroutineScope.launch {
                            delay(950)
                            heartParticles.remove(particle)
                        }
                    }
                )
            }
    ) {
        // Background Reel Visual with Ken-Burns Zoom
        Image(
            painter = painterResource(id = story.drawableRes),
            contentDescription = story.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .scale(zoomScale)
        )

        // Multi-stop luxury dark vignette overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            ObsidianBlack.copy(alpha = 0.65f),
                            Color.Transparent,
                            ObsidianBlack.copy(alpha = 0.45f),
                            ObsidianBlack.copy(alpha = 0.95f)
                        )
                    )
                )
        )

        // Double-Tap Floating Heart Particles
        val density = LocalDensity.current
        heartParticles.forEach { particle ->
            key(particle.id) {
                var visible by remember { mutableStateOf(true) }
                val floatY by animateFloatAsState(
                    targetValue = if (visible) -140f else 0f,
                    animationSpec = tween(850, easing = FastOutSlowInEasing),
                    label = "particle_y"
                )
                LaunchedEffect(Unit) {
                    visible = true
                }
                Box(
                    modifier = Modifier.offset {
                        IntOffset(
                            x = (particle.offset.x - with(density) { 42.dp.toPx() }).roundToInt(),
                            y = (particle.offset.y + floatY - with(density) { 42.dp.toPx() }).roundToInt()
                        )
                    }
                ) {
                    AnimatedVisibility(
                        visible = visible,
                        enter = scaleIn(animationSpec = spring(dampingRatio = 0.45f)) + fadeIn(),
                        exit = fadeOut()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Favorite,
                            contentDescription = null,
                            tint = LikeCrimson,
                            modifier = Modifier.size(84.dp)
                        )
                    }
                }
            }
        }

        // Top Story Progress Indicators + Audio Mute/Unmute Toggle
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            // Segmented Story Progress Bars
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                for (i in 0 until totalStories) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(4.dp)
                            .clip(RoundedCornerShape(50))
                            .background(
                                when {
                                    i == storyIndex -> FieryOrange
                                    i < storyIndex -> WarmGold.copy(alpha = 0.85f)
                                    else -> CrispWhite.copy(alpha = 0.28f)
                                }
                            )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = ObsidianBlack.copy(alpha = 0.65f),
                    shape = RoundedCornerShape(50),
                    border = BorderStroke(1.dp, FieryOrange.copy(alpha = 0.6f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocalFireDepartment,
                            contentDescription = null,
                            tint = FieryOrange,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = story.badgeText,
                            style = MaterialTheme.typography.labelLarge,
                            color = CrispWhite
                        )
                    }
                }

                // Mute / Unmute Audio Pill
                Surface(
                    onClick = onToggleAudioMute,
                    color = ObsidianBlack.copy(alpha = 0.7f),
                    shape = RoundedCornerShape(50),
                    border = BorderStroke(1.dp, GlassBorderWhite),
                    modifier = Modifier.testTag("story_audio_toggle_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isAudioMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = if (isAudioMuted) "تشغيل الصوت" else "كتم الصوت",
                            tint = if (isAudioMuted) MutedZinc else WarmGold,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isAudioMuted) "مكتوم" else "صوت حي",
                            style = MaterialTheme.typography.labelMedium,
                            color = CrispWhite
                        )
                    }
                }
            }
        }

        // Bottom Content + Floating TikTok Action Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(horizontal = 16.dp, vertical = 18.dp),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Story Caption, Hashtags, Audio Track, and Pulsing "Book This Workout" CTA
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = WarmGold,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "CAPTAIN HIMA GYM",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = ObsidianBlack,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "• اسحب للأعلى للاستوري التالي ⬆️",
                        style = MaterialTheme.typography.labelMedium,
                        color = MutedZinc
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = story.title,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = CrispWhite
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = story.subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = CrispWhite.copy(alpha = 0.9f),
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = story.categoryTag,
                    style = MaterialTheme.typography.labelLarge,
                    color = WarmGold
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Scrolling Audio Track Row
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.MusicNote,
                        contentDescription = null,
                        tint = FieryOrange,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = story.audioTrackTitle,
                        style = MaterialTheme.typography.labelMedium,
                        color = MutedZinc,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Book This Workout CTA Pill
                PulsingBookNowButton(
                    text = "احجز تمرينك الآن 🔥",
                    onClick = onBookThisWorkout,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "story_book_workout_cta"
                )
            }

            // Floating Vertical TikTok Action Bar
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(18.dp),
                modifier = Modifier.padding(bottom = 6.dp)
            ) {
                // 1. Gym Profile Avatar with + Follow Badge
                Box(
                    contentAlignment = Alignment.BottomCenter,
                    modifier = Modifier
                        .size(58.dp)
                        .clickable { onToggleFollow() }
                        .testTag("story_follow_avatar")
                ) {
                    CaptainHimaLogoAvatar(
                        logoUrl = officialLogoUrl,
                        size = 52.dp,
                        borderWidth = 2.dp
                    )
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(if (isFollowingGym) EmeraldSuccess else FieryOrange)
                            .border(1.5.dp, ObsidianBlack, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isFollowingGym) Icons.Default.Check else Icons.Default.Add,
                            contentDescription = "متابعة الجيم",
                            tint = CrispWhite,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }

                // 2. Like Button (زر لايك)
                val likeScale by animateFloatAsState(
                    targetValue = if (story.isLiked) 1.22f else 1.0f,
                    animationSpec = spring(dampingRatio = 0.4f),
                    label = "like_scale"
                )
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clickable { onToggleLike() }
                        .testTag("story_like_button")
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(ObsidianBlack.copy(alpha = 0.6f))
                            .border(
                                1.dp,
                                if (story.isLiked) LikeCrimson else GlassBorderWhite,
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (story.isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "لايك",
                            tint = if (story.isLiked) LikeCrimson else CrispWhite,
                            modifier = Modifier
                                .size(28.dp)
                                .scale(likeScale)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${story.likesCount}",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = if (story.isLiked) LikeCrimson else CrispWhite
                    )
                }

                // 3. Comment Button (زر كومنت)
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clickable { onOpenComments() }
                        .testTag("story_comment_button")
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(ObsidianBlack.copy(alpha = 0.6f))
                            .border(1.dp, GlassBorderWhite, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ChatBubbleOutline,
                            contentDescription = "تعليقات",
                            tint = CrispWhite,
                            modifier = Modifier.size(25.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${story.comments.size}",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = CrispWhite
                    )
                }

                // 4. Share Button (زر شير)
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clickable { onOpenShare() }
                        .testTag("story_share_button")
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(ObsidianBlack.copy(alpha = 0.6f))
                            .border(1.dp, GlassBorderWhite, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "مشاركة",
                            tint = WarmGold,
                            modifier = Modifier.size(25.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${story.sharesCount}",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = CrispWhite
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StoryCommentsBottomSheet(
    story: GymStory,
    onDismiss: () -> Unit,
    onSubmitComment: (author: String, text: String) -> Unit
) {
    var authorName by remember { mutableStateOf("") }
    var commentText by remember { mutableStateOf("") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = CardSurfaceDark,
        contentColor = CrispWhite,
        shape = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 380.dp, max = 560.dp)
                .padding(horizontal = 18.dp, vertical = 8.dp)
                .navigationBarsPadding()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "التعليقات (${story.comments.size}) 💬",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = CrispWhite
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = MutedZinc)
                }
            }

            HorizontalDivider(color = GlassBorderWhite, modifier = Modifier.padding(vertical = 8.dp))

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(story.comments, key = { it.id }) { comment ->
                    Surface(
                        color = CardSurfaceElevated,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, GlassBorderWhite),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(FieryOrange.copy(alpha = 0.22f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = comment.authorName.take(1),
                                    fontWeight = FontWeight.ExtraBold,
                                    color = FieryOrange
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = comment.authorName,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = WarmGold
                                    )
                                    Text(
                                        text = comment.timestamp,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MutedZinc
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = comment.text,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = CrispWhite
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Add Live Comment Input Bar
            OutlinedTextField(
                value = authorName,
                onValueChange = { authorName = it },
                label = { Text("اسمك (اختياري)") },
                placeholder = { Text("مثال: كابتن عمر") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("comment_author_input")
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = commentText,
                    onValueChange = { commentText = it },
                    placeholder = { Text("اكتب تعليقك على الاستوري... 🔥") },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("comment_text_input")
                )
                Button(
                    onClick = {
                        if (commentText.isNotBlank()) {
                            onSubmitComment(authorName, commentText)
                            commentText = ""
                        }
                    },
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = FieryOrange),
                    modifier = Modifier
                        .height(54.dp)
                        .testTag("comment_send_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "إرسال التعليق", tint = CrispWhite)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StoryShareBottomSheet(
    story: GymStory,
    facebookUrl: String,
    whatsappIntl: String,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var copiedNotice by remember { mutableStateOf(false) }
    val shareMessage = "شاهد استوري كابتن هيما جيم (CAPTAIN HIMA GYM): ${story.title}\n${story.subtitle}\n📍 المنشية فيصل | للحجز: 01039157200\n$facebookUrl"

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = CardSurfaceDark,
        contentColor = CrispWhite,
        shape = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .navigationBarsPadding()
        ) {
            Text(
                text = "مشاركة الاستوري مع أصدقائك 🚀",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.ExtraBold,
                color = CrispWhite
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = story.title,
                style = MaterialTheme.typography.bodyMedium,
                color = WarmGold
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    val waUrl = "https://wa.me/?text=${android.net.Uri.encode(shareMessage)}"
                    launchExternalUrl(context, waUrl)
                },
                colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("مشاركة عبر واتساب (WhatsApp)", fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = { launchExternalUrl(context, facebookUrl) },
                colors = ButtonDefaults.buttonColors(containerColor = FacebookBlue),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Public, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("مشاركة عبر صفحة فيسبوك الرسمية", fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                        clipboard?.setPrimaryClip(ClipData.newPlainText("Captain Hima Story", shareMessage))
                        copiedNotice = true
                    },
                    border = BorderStroke(1.dp, WarmGold),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, tint = WarmGold)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("نسخ الرابط", color = WarmGold)
                }

                OutlinedButton(
                    onClick = {
                        shareTextContent(context, story.title, shareMessage)
                    },
                    border = BorderStroke(1.dp, FieryOrange),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, tint = FieryOrange)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("مشاركة سريعة", color = FieryOrange)
                }
            }

            if (copiedNotice) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "✅ تم نسخ رابط وتفاصيل الاستوري بنجاح!",
                    color = EmeraldSuccess,
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}
