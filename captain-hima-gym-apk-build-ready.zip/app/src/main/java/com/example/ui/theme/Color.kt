package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Ultra-Luxury Dark Athletic & Royal Gold Palette
val ObsidianBlack = Color(0xFF060609)
val CardSurfaceDark = Color(0xFF111218)
val CardSurfaceElevated = Color(0xFF191B24)
val GlassBorderWhite = Color(0x24FFFFFF)
val GlassFillWhite = Color(0x12FFFFFF)

val FieryOrange = Color(0xFFFF5E00)
val FieryOrangeDark = Color(0xFFD94600)
val WarmGold = Color(0xFFFFB800)
val ChampagneGold = Color(0xFFFFE082)
val LikeCrimson = Color(0xFFFF2E63)
val WhatsAppGreen = Color(0xFF25D366)
val FacebookBlue = Color(0xFF1877F2)
val InstagramPink = Color(0xFFE1306C)

val CrispWhite = Color(0xFFFFFFFF)
val MutedZinc = Color(0xFFA1A6B4)
val SubtleZinc = Color(0xFF6E7382)
val EmeraldSuccess = Color(0xFF10B981)

val FieryGradientBrush = Brush.horizontalGradient(
    colors = listOf(FieryOrange, WarmGold)
)

val VerticalFieryBrush = Brush.linearGradient(
    colors = listOf(FieryOrange, FieryOrangeDark)
)

val LuxuryGoldBorderBrush = Brush.linearGradient(
    colors = listOf(WarmGold, FieryOrange, WarmGold.copy(alpha = 0.3f))
)

val SubtleGlassBorderBrush = Brush.linearGradient(
    colors = listOf(Color(0x38FFFFFF), Color(0x0DFFFFFF), Color(0x28FF5E00))
)
