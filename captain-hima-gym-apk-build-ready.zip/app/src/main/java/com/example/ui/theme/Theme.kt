package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

private val CaptainHimaDarkColorScheme = darkColorScheme(
    primary = FieryOrange,
    onPrimary = CrispWhite,
    primaryContainer = FieryOrangeDark,
    onPrimaryContainer = CrispWhite,
    secondary = WarmGold,
    onSecondary = ObsidianBlack,
    secondaryContainer = CardSurfaceElevated,
    onSecondaryContainer = WarmGold,
    tertiary = LikeCrimson,
    background = ObsidianBlack,
    onBackground = CrispWhite,
    surface = CardSurfaceDark,
    onSurface = CrispWhite,
    surfaceVariant = CardSurfaceElevated,
    onSurfaceVariant = MutedZinc,
    outline = GlassBorderWhite
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = CaptainHimaDarkColorScheme,
            typography = Typography,
            content = content
        )
    }
}
