package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    cmsState: CaptainHimaCmsState,
    onStoryClick: (Int) -> Unit,
    onOpenBooking: (bookingType: String, itemName: String, gender: String) -> Unit,
    onNavigateToTab: (MainTab) -> Unit
) {
    val context = LocalContext.current
    val brand = cmsState.brandInfo

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_screen_list"),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // 1. Vertical Reel Preview Cards
        item {
            StoryRingsSection(
                stories = cmsState.stories,
                onStoryClick = onStoryClick
            )
        }

        // 2. Magazine-Style Asymmetric Hero Showcase
        item {
            HeroBannerSection(
                brand = brand,
                onBookNow = {
                    onOpenBooking(
                        "اشتراك باقة",
                        "باقة 3 شهور - 1,250 ج.م بدلاً من 2,500 ج.م",
                        "قسم الرجال"
                    )
                },
                onWatchStories = { onStoryClick(0) }
            )
        }

        // 3. Overlapping Luxury Bento Stats Bar
        item {
            QuickStatsGrid()
        }

        // 4. Numbered Luxury Facilities Showcase
        item {
            SectionHeaderRow(
                badge = "PREMIUM ARENAS",
                title = "أقسام وتجهيزات الجيم العالمية",
                subtitle = "أحدث أجهزة Cybex، حمام سباحة مغطى، جاكوزي وساونا",
                actionLabel = "معرض الصور",
                onActionClick = { onNavigateToTab(MainTab.GALLERY) }
            )
        }

        itemsIndexed(cmsState.facilities, key = { _, it -> it.id }) { index, facility ->
            FacilityDepartmentCard(
                indexNumber = "0${index + 1}",
                facility = facility,
                onBookClick = {
                    onOpenBooking(
                        if (facility.id == "fac_weights") "اشتراك باقة" else "حجز حصة جماعية",
                        facility.defaultBookingProgram,
                        "قسم الرجال"
                    )
                }
            )
        }

        // 5. VIP Membership Packages 50% OFF Carousel
        item {
            Spacer(modifier = Modifier.height(8.dp))
            SectionHeaderRow(
                badge = "LIMITED 50% OFF",
                title = "باقات العضوية الملكية 🔥",
                subtitle = "خصم 50% شامل الحديد والكارديو والسبا والجاكوزي",
                actionLabel = "حاسبة التوفير",
                onActionClick = { onNavigateToTab(MainTab.PACKAGES) }
            )
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(cmsState.packages, key = { it.id }) { pkg ->
                    HomePackageCard(
                        pkg = pkg,
                        onBookPackage = {
                            onOpenBooking(
                                "اشتراك باقة",
                                "${pkg.title} - ${pkg.discountedPriceEgp} ج.م بدلاً من ${pkg.originalPriceEgp} ج.م",
                                "قسم الرجال"
                            )
                        }
                    )
                }
            }
        }

        // 6. Group Classes Schedule Preview
        item {
            Spacer(modifier = Modifier.height(10.dp))
            SectionHeaderRow(
                badge = "WEEKLY SCHEDULE",
                title = "الحصص الجماعية (السبت - الخميس)",
                subtitle = "فترات خاصة للسيدات بخصوصية تامة 100% + حصص للرجال",
                actionLabel = "كل الحصص",
                onActionClick = { onNavigateToTab(MainTab.PACKAGES) }
            )
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(cmsState.groupClasses, key = { it.id }) { cls ->
                    HomeGroupClassCard(
                        cls = cls,
                        onBookClass = {
                            val gender = if (cls.category == ClassGenderFilter.LADIES) "قسم السيدات" else "قسم الرجال"
                            onOpenBooking("حجز حصة جماعية", "${cls.nameAr} (${cls.daysAr})", gender)
                        }
                    )
                }
            }
        }

        // 7. Verified Google Maps 5.0★ Wall of Fame
        item {
            Spacer(modifier = Modifier.height(12.dp))
            ReviewsShowcaseSection(
                reviews = cmsState.reviews,
                onOpenGoogleMaps = { launchExternalUrl(context, brand.googleMapsUrl) }
            )
        }

        // 8. Luxury Location & Social Hub Card
        item {
            LocationAndSocialFooterCard(
                brand = brand,
                onCallClick = { launchPhoneDialer(context, brand.phoneDisplay) },
                onWhatsAppClick = {
                    val url = "https://wa.me/${brand.whatsappIntl}?text=" +
                        android.net.Uri.encode("مرحباً كابتن هيما جيم، أرغب في الاستفسار عن عروض الـ 50% ومواعيد التمرين 🔥")
                    launchExternalUrl(context, url)
                },
                onMapsClick = { launchExternalUrl(context, brand.googleMapsUrl) },
                onFacebookClick = { launchExternalUrl(context, brand.facebookPageUrl) },
                onInstagramClick = { launchExternalUrl(context, brand.instagramUrl) },
                onTikTokClick = { launchExternalUrl(context, brand.tiktokUrl) }
            )
        }
    }
}

@Composable
private fun HeroBannerSection(
    brand: GymBrandInfo,
    onBookNow: () -> Unit,
    onWatchStories: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp)
            .height(375.dp)
            .clip(RoundedCornerShape(30.dp))
            .border(1.5.dp, LuxuryGoldBorderBrush, RoundedCornerShape(30.dp))
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_gym_weights_1794007816793),
            contentDescription = brand.nameAr,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Multi-layer dramatic spotlight vignette
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            ObsidianBlack.copy(alpha = 0.25f),
                            ObsidianBlack.copy(alpha = 0.65f),
                            ObsidianBlack.copy(alpha = 0.97f)
                        )
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(22.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Luxury Badges
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = Color.Transparent,
                    shape = RoundedCornerShape(50)
                ) {
                    Row(
                        modifier = Modifier
                            .background(FieryGradientBrush, RoundedCornerShape(50))
                            .padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.WorkspacePremium,
                            contentDescription = null,
                            tint = ObsidianBlack,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = brand.taglineAr,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = ObsidianBlack
                        )
                    }
                }

                Surface(
                    color = ObsidianBlack.copy(alpha = 0.80f),
                    shape = RoundedCornerShape(50),
                    border = BorderStroke(1.dp, WarmGold)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = WarmGold,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "5.0 ★ Google Maps",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = WarmGold
                        )
                    }
                }
            }

            // Bottom Hero Typography & CTAs
            Column {
                Surface(
                    color = FieryOrange.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, FieryOrange.copy(alpha = 0.6f))
                ) {
                    Text(
                        text = "⚡ ${brand.taglineEn.uppercase()} • 50% OFF",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = ChampagneGold,
                        letterSpacing = 1.2.sp,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = brand.nameAr,
                    style = MaterialTheme.typography.displayMedium.copy(fontSize = 30.sp),
                    fontWeight = FontWeight.ExtraBold,
                    color = CrispWhite
                )
                Text(
                    text = brand.nameEn,
                    style = MaterialTheme.typography.labelLarge,
                    color = WarmGold,
                    letterSpacing = 1.5.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "صالة حديد بأحدث أجهزة Cybex العالمية • حمام سباحة مغطى وجاكوزي بشلالات وساونا • مفتوح 24 ساعة + فترات خاصة للسيدات بخصوصية 100%.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedZinc,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PulsingBookNowButton(
                        text = "احجز بخصم 50% 🔥",
                        onClick = onBookNow,
                        modifier = Modifier.weight(1.25f),
                        testTag = "hero_book_now_button"
                    )

                    OutlinedButton(
                        onClick = onWatchStories,
                        modifier = Modifier
                            .weight(0.9f)
                            .height(48.dp)
                            .testTag("hero_watch_stories_button"),
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(1.5.dp, WarmGold),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = CardSurfaceDark.copy(alpha = 0.78f),
                            contentColor = WarmGold
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.SlowMotionVideo,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "استوري الجيم",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickStatsGrid() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        StatBadgeCard(
            icon = Icons.Default.Schedule,
            value = "24/7",
            label = "مفتوح يومياً",
            accent = FieryOrange,
            modifier = Modifier.weight(1f)
        )
        StatBadgeCard(
            icon = Icons.Default.LocalOffer,
            value = "50%",
            label = "خصم حصري",
            accent = WarmGold,
            modifier = Modifier.weight(1f)
        )
        StatBadgeCard(
            icon = Icons.Default.HotTub,
            value = "SPA",
            label = "مسبح وجاكوزي",
            accent = FieryOrange,
            modifier = Modifier.weight(1f)
        )
        StatBadgeCard(
            icon = Icons.Default.AutoAwesome,
            value = "100%",
            label = "خصوصية سيدات",
            accent = LikeCrimson,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun StatBadgeCard(
    icon: ImageVector,
    value: String,
    label: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.border(1.dp, SubtleGlassBorderBrush, RoundedCornerShape(20.dp)),
        color = CardSurfaceDark.copy(alpha = 0.9f),
        shape = RoundedCornerShape(20.dp),
        tonalElevation = 8.dp
    ) {
        Column(
            modifier = Modifier.padding(vertical = 14.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(accent.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = CrispWhite
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium.copy(fontSize = 11.sp),
                color = MutedZinc,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun SectionHeaderRow(
    badge: String,
    title: String,
    subtitle: String,
    actionLabel: String,
    onActionClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Bottom
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = badge,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.ExtraBold,
                color = WarmGold,
                letterSpacing = 1.4.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.ExtraBold,
                color = CrispWhite
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MutedZinc
            )
        }
        Surface(
            onClick = onActionClick,
            color = CardSurfaceElevated,
            shape = RoundedCornerShape(50),
            border = BorderStroke(1.dp, FieryOrange.copy(alpha = 0.5f))
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = actionLabel,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = FieryOrange
                )
                Icon(
                    imageVector = Icons.Default.ChevronLeft,
                    contentDescription = null,
                    tint = FieryOrange,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
private fun FacilityDepartmentCard(
    indexNumber: String,
    facility: FacilityDepartment,
    onBookClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .border(1.dp, SubtleGlassBorderBrush, RoundedCornerShape(26.dp)),
        color = CardSurfaceDark,
        shape = RoundedCornerShape(26.dp),
        shadowElevation = 12.dp
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(195.dp)
            ) {
                Image(
                    painter = painterResource(id = facility.drawableRes),
                    contentDescription = facility.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    ObsidianBlack.copy(alpha = 0.15f),
                                    ObsidianBlack.copy(alpha = 0.94f)
                                )
                            )
                        )
                )

                // Top Row: Index Number + Facility Badge
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = FieryOrange,
                        shape = RoundedCornerShape(50)
                    ) {
                        Text(
                            text = facility.badge,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = CrispWhite,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                        )
                    }

                    Surface(
                        color = ObsidianBlack.copy(alpha = 0.72f),
                        shape = CircleShape,
                        border = BorderStroke(1.dp, WarmGold.copy(alpha = 0.7f))
                    ) {
                        Text(
                            text = indexNumber,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = WarmGold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }

                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {
                    Text(
                        text = facility.subtitle.uppercase(),
                        style = MaterialTheme.typography.labelMedium,
                        color = WarmGold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = facility.title,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = CrispWhite
                    )
                }
            }

            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = facility.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedZinc
                )
                Spacer(modifier = Modifier.height(12.dp))

                facility.features.forEach { feat ->
                    Surface(
                        color = CardSurfaceElevated.copy(alpha = 0.75f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Verified,
                                contentDescription = null,
                                tint = WarmGold,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = feat,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium,
                                color = CrispWhite
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = onBookClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = FieryOrange.copy(alpha = 0.16f),
                        contentColor = CrispWhite
                    ),
                    border = BorderStroke(1.dp, FieryOrange)
                ) {
                    Icon(
                        imageVector = Icons.Default.LocalFireDepartment,
                        contentDescription = null,
                        tint = FieryOrange,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "احجز الآن في ${facility.title}",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = CrispWhite
                    )
                }
            }
        }
    }
}

@Composable
private fun HomePackageCard(
    pkg: MembershipPackage,
    onBookPackage: () -> Unit
) {
    val savingsEgp = pkg.originalPriceEgp - pkg.discountedPriceEgp

    Surface(
        modifier = Modifier
            .width(280.dp)
            .border(
                width = if (pkg.isPopular || pkg.isVip) 2.dp else 1.dp,
                brush = if (pkg.isVip || pkg.isPopular) LuxuryGoldBorderBrush else SubtleGlassBorderBrush,
                shape = RoundedCornerShape(26.dp)
            ),
        color = CardSurfaceDark,
        shape = RoundedCornerShape(26.dp),
        shadowElevation = 14.dp
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = if (pkg.isVip) WarmGold else FieryOrange,
                    shape = RoundedCornerShape(50)
                ) {
                    Text(
                        text = pkg.badgeText,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (pkg.isVip) ObsidianBlack else CrispWhite,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }

                Surface(
                    color = EmeraldSuccess.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(50),
                    border = BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = "وفر $savingsEgp ج",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldSuccess,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = pkg.title,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.ExtraBold,
                color = CrispWhite
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = "${pkg.discountedPriceEgp}",
                    style = MaterialTheme.typography.displayMedium.copy(fontSize = 32.sp),
                    fontWeight = FontWeight.ExtraBold,
                    color = if (pkg.isVip) WarmGold else FieryOrange
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "ج.م",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = WarmGold,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "${pkg.originalPriceEgp} ج.م",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        textDecoration = TextDecoration.LineThrough
                    ),
                    color = MutedZinc,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }

            HorizontalDivider(
                modifier = Modifier.padding(vertical = 12.dp),
                color = GlassBorderWhite
            )

            pkg.perks.take(3).forEach { perk ->
                Row(
                    modifier = Modifier.padding(vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = if (pkg.isVip) WarmGold else FieryOrange,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = perk,
                        style = MaterialTheme.typography.bodyMedium,
                        color = CrispWhite,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            PulsingBookNowButton(
                text = "اشترك في ${pkg.title} 🔥",
                onClick = onBookPackage,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun HomeGroupClassCard(
    cls: GroupClassItem,
    onBookClass: () -> Unit
) {
    Surface(
        modifier = Modifier
            .width(255.dp)
            .border(1.dp, SubtleGlassBorderBrush, RoundedCornerShape(24.dp)),
        color = CardSurfaceDark,
        shape = RoundedCornerShape(24.dp),
        shadowElevation = 10.dp
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(115.dp)
            ) {
                Image(
                    painter = painterResource(id = cls.drawableRes),
                    contentDescription = cls.nameAr,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, CardSurfaceDark)
                            )
                        )
                )
                Surface(
                    color = if (cls.category == ClassGenderFilter.LADIES) LikeCrimson else FieryOrange,
                    shape = RoundedCornerShape(50),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(10.dp)
                ) {
                    Text(
                        text = cls.category.labelAr,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = CrispWhite,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                    )
                }
            }

            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = cls.nameAr,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = CrispWhite,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "📅 ${cls.daysAr}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MutedZinc
                )
                Text(
                    text = "⏰ ${cls.timeSlotAr}",
                    style = MaterialTheme.typography.labelMedium,
                    color = WarmGold
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = onBookClass,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CardSurfaceElevated),
                    border = BorderStroke(1.dp, FieryOrange.copy(alpha = 0.6f))
                ) {
                    Text("احجز مكانك 🔥", color = CrispWhite, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun ReviewsShowcaseSection(
    reviews: List<GymReview>,
    onOpenGoogleMaps: () -> Unit
) {
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "GOOGLE MAPS VERIFIED",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = WarmGold,
                    letterSpacing = 1.4.sp
                )
                Text(
                    text = "آراء أبطال كابتن هيما جيم ⭐",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = CrispWhite
                )
            }
            Surface(
                onClick = onOpenGoogleMaps,
                color = WarmGold.copy(alpha = 0.16f),
                shape = RoundedCornerShape(50),
                border = BorderStroke(1.dp, WarmGold)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    GoogleBrandBadgeIcon(size = 18.dp)
                    Text(
                        text = "5.0 ★ تقييم جوجل",
                        style = MaterialTheme.typography.labelLarge,
                        color = WarmGold,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        reviews.forEach { rev ->
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .border(1.dp, SubtleGlassBorderBrush, RoundedCornerShape(22.dp)),
                color = CardSurfaceDark,
                shape = RoundedCornerShape(22.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(FieryGradientBrush),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = rev.reviewerName.take(1),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = ObsidianBlack
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = rev.reviewerName,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = CrispWhite
                                )
                                Text(
                                    text = rev.roleBadge,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MutedZinc
                                )
                            }
                        }
                        Surface(
                            color = WarmGold.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(50)
                        ) {
                            Text(
                                text = "★★★★★",
                                color = WarmGold,
                                style = MaterialTheme.typography.labelLarge,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = rev.commentText,
                        style = MaterialTheme.typography.bodyLarge,
                        color = CrispWhite
                    )
                }
            }
        }
    }
}

@Composable
private fun LocationAndSocialFooterCard(
    brand: GymBrandInfo,
    onCallClick: () -> Unit,
    onWhatsAppClick: () -> Unit,
    onMapsClick: () -> Unit,
    onFacebookClick: () -> Unit,
    onInstagramClick: () -> Unit,
    onTikTokClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .border(1.5.dp, LuxuryGoldBorderBrush, RoundedCornerShape(26.dp)),
        color = CardSurfaceDark,
        shape = RoundedCornerShape(26.dp),
        shadowElevation = 16.dp
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(FieryOrange.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = FieryOrange,
                        modifier = Modifier.size(26.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "عنوان وموقع كابتن هيما جيم",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = CrispWhite
                    )
                    Text(
                        text = "Plus Code: ${brand.plusCode}",
                        style = MaterialTheme.typography.labelMedium,
                        color = WarmGold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Surface(
                color = CardSurfaceElevated,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "📍 ${brand.addressAr}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = CrispWhite
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "🕒 ${brand.workingHours}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldSuccess
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "📞 الخط الساخن وواتساب: ${brand.phoneDisplay}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = WarmGold
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onWhatsAppClick,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("واتساب", color = CrispWhite, fontWeight = FontWeight.ExtraBold)
                }
                Button(
                    onClick = onCallClick,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = FieryOrange),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("اتصال مباشر", color = CrispWhite, fontWeight = FontWeight.ExtraBold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Row 1 of Socials: Google Maps & Facebook with real filled icons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onMapsClick,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("home_social_google_button"),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, WarmGold),
                    contentPadding = PaddingValues(horizontal = 10.dp)
                ) {
                    GoogleBrandBadgeIcon(size = 20.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "خرائط جوجل",
                        color = WarmGold,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
                OutlinedButton(
                    onClick = onFacebookClick,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("home_social_facebook_button"),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, FacebookBlue),
                    contentPadding = PaddingValues(horizontal = 10.dp)
                ) {
                    FacebookBrandBadgeIcon(size = 20.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "فيسبوك",
                        color = FacebookBlue,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Row 2 of Socials: Instagram & TikTok with real filled icons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onInstagramClick,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("home_social_instagram_button"),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, InstagramPink),
                    contentPadding = PaddingValues(horizontal = 10.dp)
                ) {
                    InstagramBrandBadgeIcon(size = 20.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "إنستجرام",
                        color = InstagramPink,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
                OutlinedButton(
                    onClick = onTikTokClick,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("home_social_tiktok_button"),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, Color(0xFF00F2FE)),
                    contentPadding = PaddingValues(horizontal = 10.dp)
                ) {
                    TikTokBrandBadgeIcon(size = 20.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "تيك توك",
                        color = CrispWhite,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }
        }
    }
}
