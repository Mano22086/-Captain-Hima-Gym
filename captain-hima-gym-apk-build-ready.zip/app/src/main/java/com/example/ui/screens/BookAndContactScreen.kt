package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.model.*
import com.example.ui.components.launchExternalUrl
import com.example.ui.components.launchPhoneDialer
import com.example.ui.theme.*

@Composable
fun BookAndContactScreen(
    cmsState: CaptainHimaCmsState,
    onSubmitDirectBooking: (
        fullName: String,
        phone: String,
        genderCategory: String,
        bookingType: String,
        selectedItemName: String,
        preferredDateTime: String,
        notes: String,
        onDone: (BookingRecord) -> Unit
    ) -> Unit,
    onConfirmViaWhatsApp: (BookingRecord) -> Unit,
    onActivateBookedCode: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val brand = cmsState.brandInfo

    var fullName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var genderCategory by remember { mutableStateOf("قسم الرجال") }
    var bookingType by remember { mutableStateOf("اشتراك باقة") }

    val packageOptions = remember(cmsState.packages) {
        cmsState.packages.map { "${it.title} - ${it.discountedPriceEgp} ج.م بدلاً من ${it.originalPriceEgp} ج.م" }
    }
    val classOptions = remember(cmsState.groupClasses) {
        cmsState.groupClasses.map { "${it.nameAr} (${it.daysAr})" } + listOf(
            "جلسة السبا والجاكوزي والساونا",
            "التدريب الشخصي والتغذية (Personal Training)"
        )
    }
    val currentPool = if (bookingType == "اشتراك باقة") packageOptions else classOptions

    var selectedItemName by remember(bookingType) {
        mutableStateOf(currentPool.firstOrNull() ?: "")
    }
    var preferredDateTime by remember { mutableStateOf("اليوم - الساعة 8:00 مساءً") }
    var notes by remember { mutableStateOf("") }
    var validationError by remember { mutableStateOf(false) }
    var submittedRecord by remember { mutableStateOf<BookingRecord?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("book_contact_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Direct Booking Form OR Celebratory Confirmation Card
        item {
            Surface(
                color = CardSurfaceDark,
                shape = RoundedCornerShape(28.dp),
                shadowElevation = 18.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, LuxuryGoldBorderBrush, RoundedCornerShape(28.dp))
            ) {
                val record = submittedRecord
                if (record != null) {
                    Column(
                        modifier = Modifier.padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(68.dp)
                                .clip(CircleShape)
                                .background(EmeraldSuccess.copy(alpha = 0.2f))
                                .border(2.dp, EmeraldSuccess, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Verified,
                                contentDescription = null,
                                tint = EmeraldSuccess,
                                modifier = Modifier.size(38.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "تم تسجيل حجزك بنجاح! 🔥",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = CrispWhite
                        )
                        Text(
                            text = "كود الاشتراك والمتابعة: ${record.referenceCode}",
                            style = MaterialTheme.typography.titleLarge,
                            color = WarmGold,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "الاسم: ${record.fullName} | الهاتف: ${record.phone}\n${record.genderCategory} • ${record.selectedItemName}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MutedZinc,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = { onConfirmViaWhatsApp(record) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("direct_booking_whatsapp_button"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "1. تأكيد الحجز عبر واتساب الآن 💬",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = CrispWhite
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Button(
                            onClick = { onActivateBookedCode(record.referenceCode) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("direct_booking_activate_code_button"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = WarmGold,
                                contentColor = ObsidianBlack
                            )
                        ) {
                            Icon(Icons.Default.Key, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "2. متابعة اشتراكي بالكود (${record.referenceCode}) 🔑",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Black
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        TextButton(onClick = { submittedRecord = null }) {
                            Text("تسجيل حجز آخر جديد", color = WarmGold)
                        }
                    }
                } else {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.EventAvailable,
                                contentDescription = null,
                                tint = FieryOrange,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "استمارة الحجز المباشر (خصم 50%)",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = CrispWhite
                                )
                                Text(
                                    text = "احجز باقتك أو حصتك واستلم كود الحجز وتأكيد واتساب فوراً",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = WarmGold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        OutlinedTextField(
                            value = fullName,
                            onValueChange = {
                                fullName = it
                                validationError = false
                            },
                            label = { Text("الاسم بالكامل *") },
                            leadingIcon = { Icon(Icons.Default.Person, null, tint = FieryOrange) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("direct_name_input")
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = phone,
                            onValueChange = {
                                phone = it
                                validationError = false
                            },
                            label = { Text("رقم الهاتف / واتساب *") },
                            leadingIcon = { Icon(Icons.Default.PhoneAndroid, null, tint = FieryOrange) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("direct_phone_input")
                        )

                        if (validationError) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "يرجى إدخال الاسم ورقم الهاتف لإتمام الحجز",
                                color = LikeCrimson,
                                style = MaterialTheme.typography.labelMedium
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text("القسم:", style = MaterialTheme.typography.labelLarge, color = CrispWhite)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("قسم الرجال", "قسم السيدات").forEach { g ->
                                val selected = genderCategory == g
                                Surface(
                                    onClick = { genderCategory = g },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (selected) FieryOrange.copy(alpha = 0.22f) else CardSurfaceElevated,
                                    border = BorderStroke(1.dp, if (selected) FieryOrange else GlassBorderWhite)
                                ) {
                                    Box(
                                        modifier = Modifier.padding(vertical = 10.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = if (g == "قسم الرجال") "💪 قسم الرجال" else "💃 قسم السيدات",
                                            style = MaterialTheme.typography.labelLarge,
                                            color = if (selected) CrispWhite else MutedZinc
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text("نوع الحجز:", style = MaterialTheme.typography.labelLarge, color = CrispWhite)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("اشتراك باقة", "حجز حصة جماعية").forEach { t ->
                                val selected = bookingType == t
                                Surface(
                                    onClick = { bookingType = t },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (selected) WarmGold.copy(alpha = 0.2f) else CardSurfaceElevated,
                                    border = BorderStroke(1.dp, if (selected) WarmGold else GlassBorderWhite)
                                ) {
                                    Box(
                                        modifier = Modifier.padding(vertical = 10.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = if (t == "اشتراك باقة") "🏆 اشتراك باقة" else "⚡ حصة / سبا",
                                            style = MaterialTheme.typography.labelLarge,
                                            color = if (selected) WarmGold else MutedZinc
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        currentPool.forEach { option ->
                            val selected = selectedItemName == option
                            Surface(
                                onClick = { selectedItemName = option },
                                shape = RoundedCornerShape(10.dp),
                                color = if (selected) FieryOrange.copy(alpha = 0.16f) else CardSurfaceElevated,
                                border = BorderStroke(1.dp, if (selected) FieryOrange else GlassBorderWhite),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = selected,
                                        onClick = { selectedItemName = option },
                                        colors = RadioButtonDefaults.colors(selectedColor = FieryOrange)
                                    )
                                    Text(
                                        text = option,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = if (selected) CrispWhite else MutedZinc
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = preferredDateTime,
                            onValueChange = { preferredDateTime = it },
                            label = { Text("تاريخ وموعد الحضور المفضل") },
                            leadingIcon = { Icon(Icons.Default.Schedule, null, tint = WarmGold) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = notes,
                            onValueChange = { notes = it },
                            label = { Text("ملاحظات إضافية") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                if (fullName.isBlank() || phone.isBlank()) {
                                    validationError = true
                                } else {
                                    onSubmitDirectBooking(
                                        fullName,
                                        phone,
                                        genderCategory,
                                        bookingType,
                                        selectedItemName,
                                        preferredDateTime,
                                        notes
                                    ) { record ->
                                        submittedRecord = record
                                    }
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("direct_booking_submit_button"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = FieryOrange)
                        ) {
                            Icon(Icons.Default.LocalFireDepartment, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "إرسال الحجز واستلام كود التأكيد 🔥",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = CrispWhite
                            )
                        }
                    }
                }
            }
        }

        // 2. Interactive Map & Verified Address Card
        item {
            Surface(
                color = CardSurfaceDark,
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, GlassBorderWhite),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Map,
                            contentDescription = null,
                            tint = WarmGold,
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "موقع الجيم على خرائط جوجل 🗺️",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = CrispWhite
                            )
                            Text(
                                text = "Plus Code: ${brand.plusCode} • تقييم 5.0 ★",
                                style = MaterialTheme.typography.labelMedium,
                                color = WarmGold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Surface(
                        color = CardSurfaceElevated,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, FieryOrange.copy(alpha = 0.35f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "📍 العنوان بالتفصيل:",
                                style = MaterialTheme.typography.labelLarge,
                                color = FieryOrange
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = brand.addressAr,
                                style = MaterialTheme.typography.bodyLarge,
                                color = CrispWhite
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "🕒 مواعيد العمل: ${brand.workingHours}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = EmeraldSuccess
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { launchExternalUrl(context, brand.googleMapsUrl) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = WarmGold)
                    ) {
                        com.example.ui.components.GoogleBrandBadgeIcon(size = 22.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "افتح الاتجاهات في Google Maps",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = ObsidianBlack
                        )
                    }
                }
            }
        }

        // 3. Direct Phone, WhatsApp & Social Channels Card
        item {
            Surface(
                color = CardSurfaceDark,
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, GlassBorderWhite),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "قنوات التواصل والصفحات الرسمية 📞",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = CrispWhite
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { launchPhoneDialer(context, brand.phoneDisplay) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = FieryOrange)
                    ) {
                        Icon(Icons.Default.Call, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "اتصال مباشر: ${brand.phoneDisplay}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            val waUrl = "https://wa.me/${brand.whatsappIntl}?text=" +
                                android.net.Uri.encode("السلام عليكم كابتن هيما جيم، أريد الاستفسار عن الاشتراكات ومواعيد التمرين 💪")
                            launchExternalUrl(context, waUrl)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "تواصل عبر واتساب (+${brand.whatsappIntl})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Row 1: Google & Facebook with real filled icons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { launchExternalUrl(context, brand.googleMapsUrl) },
                            border = BorderStroke(1.dp, WarmGold),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("contact_google_button")
                        ) {
                            com.example.ui.components.GoogleBrandBadgeIcon(size = 20.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("جوجل مابس", color = WarmGold, fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = { launchExternalUrl(context, brand.facebookPageUrl) },
                            border = BorderStroke(1.dp, FacebookBlue),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("contact_facebook_button")
                        ) {
                            com.example.ui.components.FacebookBrandBadgeIcon(size = 20.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("فيسبوك", color = FacebookBlue, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Row 2: Instagram & TikTok with real filled icons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { launchExternalUrl(context, brand.instagramUrl) },
                            border = BorderStroke(1.dp, InstagramPink),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("contact_instagram_button")
                        ) {
                            com.example.ui.components.InstagramBrandBadgeIcon(size = 20.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("إنستجرام", color = InstagramPink, fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = { launchExternalUrl(context, brand.tiktokUrl) },
                            border = BorderStroke(1.dp, androidx.compose.ui.graphics.Color(0xFF00F2FE)),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("contact_tiktok_button")
                        ) {
                            com.example.ui.components.TikTokBrandBadgeIcon(size = 20.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("تيك توك", color = CrispWhite, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
