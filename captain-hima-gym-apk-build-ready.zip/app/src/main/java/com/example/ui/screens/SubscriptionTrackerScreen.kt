package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CaptainHimaCmsState
import com.example.model.MemberSubscription
import com.example.model.MembershipPackage
import com.example.ui.components.PulsingBookNowButton
import com.example.ui.theme.*

@Composable
fun SubscriptionTrackerScreen(
    cmsState: CaptainHimaCmsState,
    onActivateCode: (String) -> Boolean,
    onClearActiveCode: () -> Unit,
    onRenewSubscription: (String, MembershipPackage) -> Unit,
    onConfirmRenewalViaWhatsApp: (MemberSubscription, MembershipPackage) -> Unit,
    onOpenNewBooking: (String, String, String) -> Unit
) {
    val activeCode = cmsState.activeSubscriptionCode
    val activeSubscription = remember(cmsState.subscriptions, activeCode) {
        if (activeCode.isNullOrBlank()) null
        else cmsState.subscriptions.firstOrNull { it.code.equals(activeCode, ignoreCase = true) }
    }

    var inputCode by remember { mutableStateOf("") }
    var codeError by remember { mutableStateOf<String?>(null) }
    var renewalBannerMessage by remember { mutableStateOf<String?>(null) }
    var isSwitchingCode by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("subscription_tracker_screen"),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        if (activeSubscription == null || isSwitchingCode) {
            item {
                SubscriptionCodeLookupCard(
                    inputCode = inputCode,
                    onInputCodeChange = {
                        inputCode = it
                        codeError = null
                    },
                    codeError = codeError,
                    recentBookings = cmsState.bookings,
                    hasActiveSub = activeSubscription != null,
                    onCancelSwitch = { isSwitchingCode = false },
                    onSubmitCode = { codeToSubmit ->
                        val ok = onActivateCode(codeToSubmit)
                        if (ok) {
                            codeError = null
                            isSwitchingCode = false
                        } else {
                            codeError = "كود الاشتراك غير صحيح. جرب الكود التجريبي KH37JMD أو احجز باقة جديدة لاستلام كودك."
                        }
                    },
                    onQuickFillDemo = {
                        inputCode = "KH37JMD"
                        val ok = onActivateCode("KH37JMD")
                        if (ok) {
                            codeError = null
                            isSwitchingCode = false
                        }
                    },
                    onBookNewPackage = {
                        onOpenNewBooking(
                            "اشتراك باقة",
                            "باقة 3 شهور - 1,250 ج.م (الأكثر طلباً)",
                            "قسم الرجال"
                        )
                    }
                )
            }
        }

        if (activeSubscription != null) {
            // Celebratory Renewal Banner if just renewed
            item {
                AnimatedVisibility(visible = renewalBannerMessage != null) {
                    Surface(
                        color = EmeraldSuccess.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.5.dp, EmeraldSuccess),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Verified,
                                contentDescription = null,
                                tint = EmeraldSuccess,
                                modifier = Modifier.size(28.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "تم تحديث وتجديد اشتراكك بنجاح! 🎉",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = CrispWhite
                                )
                                Text(
                                    text = renewalBannerMessage ?: "",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = ChampagneGold
                                )
                            }
                            IconButton(onClick = { renewalBannerMessage = null }) {
                                Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = MutedZinc)
                            }
                        }
                    }
                }
            }

            // 1. Digital VIP Membership Identity Card
            item {
                MemberDigitalPassCard(
                    subscription = activeSubscription,
                    onSwitchCodeClick = {
                        inputCode = ""
                        codeError = null
                        isSwitchingCode = true
                    },
                    onLogoutCodeClick = {
                        onClearActiveCode()
                    }
                )
            }

            // 2. Remaining Duration & Progress Gauge Card
            item {
                RemainingDurationGaugeCard(subscription = activeSubscription)
            }

            // 3. Full Member Personal & Subscription Details Card
            item {
                SubscriptionFullDetailsCard(subscription = activeSubscription)
            }

            // 4. Renewal & New Packages Section Header
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(FieryOrange.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Autorenew,
                                contentDescription = null,
                                tint = FieryOrange,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "تجديد الاشتراك والباقات الجديدة 🔥",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = CrispWhite
                            )
                            Text(
                                text = "جدد باقتك الآن بخصم 50% وأضف المدة فوراً إلى رصيد أيامك المتبقية",
                                style = MaterialTheme.typography.bodySmall,
                                color = WarmGold
                            )
                        }
                    }
                }
            }

            // 5. All Packages for Instant Renewal / Upgrade
            items(cmsState.packages, key = { it.id }) { pkg ->
                RenewalPackageCard(
                    pkg = pkg,
                    isCurrentPackage = activeSubscription.packageId == pkg.id,
                    onInstantRenew = {
                        onRenewSubscription(activeSubscription.code, pkg)
                        renewalBannerMessage =
                            "تمت إضافة ${pkg.durationMonths * 30} يوم (${pkg.title}) إلى اشتراكك الكود ${activeSubscription.code}!"
                    },
                    onWhatsAppConfirmRenewal = {
                        onRenewSubscription(activeSubscription.code, pkg)
                        onConfirmRenewalViaWhatsApp(activeSubscription, pkg)
                    }
                )
            }
        }
    }
}

@Composable
private fun SubscriptionCodeLookupCard(
    inputCode: String,
    onInputCodeChange: (String) -> Unit,
    codeError: String?,
    recentBookings: List<com.example.model.BookingRecord>,
    hasActiveSub: Boolean,
    onCancelSwitch: () -> Unit,
    onSubmitCode: (String) -> Unit,
    onQuickFillDemo: () -> Unit,
    onBookNewPackage: () -> Unit
) {
    Surface(
        color = CardSurfaceDark,
        shape = RoundedCornerShape(28.dp),
        border = BorderStroke(1.5.dp, LuxuryGoldBorderBrush),
        shadowElevation = 20.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (hasActiveSub) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onCancelSwitch) {
                        Text("إلغاء والعودة لاشتراكي الحالي", color = WarmGold)
                    }
                }
            }

            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(FieryOrange.copy(alpha = 0.25f), WarmGold.copy(alpha = 0.15f))
                        )
                    )
                    .border(1.5.dp, WarmGold, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.QrCode2,
                    contentDescription = null,
                    tint = WarmGold,
                    modifier = Modifier.size(36.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "متابعة اشتراكك في كابتن هيما جيم",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.ExtraBold,
                color = CrispWhite,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "اكتب كود الاشتراك الذي استلمته بعد الحجز وتأكيد الواتساب لمتابعة تفاصيل باقتك، المدة المتبقية، وتجديد اشتراكك.",
                style = MaterialTheme.typography.bodyMedium,
                color = MutedZinc,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Quick Demo Code Chip for KH37JMD
            Surface(
                onClick = onQuickFillDemo,
                color = WarmGold.copy(alpha = 0.14f),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, WarmGold.copy(alpha = 0.65f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("demo_code_kh37jmd_chip")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.VerifiedUser,
                            contentDescription = null,
                            tint = WarmGold,
                            modifier = Modifier.size(20.dp)
                        )
                        Column {
                            Text(
                                text = "كود الاشتراك التجريبي الجاهز:",
                                style = MaterialTheme.typography.labelSmall,
                                color = MutedZinc
                            )
                            Text(
                                text = "KH37JMD (اضغط هنا للتجربة الفورية ⚡)",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = WarmGold
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.Default.TouchApp,
                        contentDescription = null,
                        tint = WarmGold
                    )
                }
            }

            // Show user's recent booked codes if they booked during this session
            if (recentBookings.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(CardSurfaceElevated)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "أكواد حجوزاتك الأخيرة (اضغط لعرض تفاصيل الاشتراك):",
                        style = MaterialTheme.typography.labelMedium,
                        color = ChampagneGold
                    )
                    recentBookings.take(3).forEach { booking ->
                        Surface(
                            onClick = { onSubmitCode(booking.referenceCode) },
                            color = FieryOrange.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, FieryOrange.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${booking.fullName} • ${booking.selectedItemName.take(22)}...",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CrispWhite
                                )
                                Text(
                                    text = booking.referenceCode,
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = WarmGold
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            OutlinedTextField(
                value = inputCode,
                onValueChange = onInputCodeChange,
                label = { Text("اكتب كود الاشتراك (مثال: KH37JMD)") },
                placeholder = { Text("KH37JMD") },
                leadingIcon = {
                    Icon(Icons.Default.Key, contentDescription = null, tint = FieryOrange)
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("subscription_code_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = FieryOrange,
                    unfocusedBorderColor = GlassBorderWhite,
                    focusedTextColor = CrispWhite,
                    unfocusedTextColor = CrispWhite
                )
            )

            if (codeError != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = codeError,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.error,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { onSubmitCode(inputCode) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("submit_subscription_code_button"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = FieryOrange,
                    contentColor = CrispWhite
                )
            ) {
                Icon(Icons.Default.Login, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "عرض تفاصيل اشتراكي الآن 🔑",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(
                onClick = onBookNewPackage,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, WarmGold.copy(alpha = 0.6f))
            ) {
                Icon(Icons.Default.AddCard, contentDescription = null, tint = WarmGold)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "مشترك جديد؟ احجز باقتك واستلم كودك فوراً 🔥",
                    color = WarmGold,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun MemberDigitalPassCard(
    subscription: MemberSubscription,
    onSwitchCodeClick: () -> Unit,
    onLogoutCodeClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(28.dp),
        color = CardSurfaceDark,
        border = BorderStroke(1.5.dp, LuxuryGoldBorderBrush),
        shadowElevation = 22.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            FieryOrange.copy(alpha = 0.18f),
                            CardSurfaceDark,
                            WarmGold.copy(alpha = 0.12f)
                        )
                    )
                )
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = EmeraldSuccess.copy(alpha = 0.18f),
                    shape = RoundedCornerShape(50),
                    border = BorderStroke(1.dp, EmeraldSuccess)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(EmeraldSuccess)
                        )
                        Text(
                            text = subscription.statusAr,
                            style = MaterialTheme.typography.labelMedium,
                            color = EmeraldSuccess,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(
                        onClick = onSwitchCodeClick,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SwapHoriz,
                            contentDescription = null,
                            tint = WarmGold,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "تغيير الكود",
                            style = MaterialTheme.typography.labelMedium,
                            color = WarmGold
                        )
                    }
                    IconButton(
                        onClick = onLogoutCodeClick,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Logout,
                            contentDescription = "خروج من الكود",
                            tint = MutedZinc,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "بطاقة العضوية الملكية • CAPTAIN HIMA VIP",
                        style = MaterialTheme.typography.labelSmall,
                        color = WarmGold,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = subscription.fullName,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Black,
                        color = CrispWhite
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "📱 ${subscription.phone}  •  ${subscription.genderCategory}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MutedZinc,
                        fontWeight = FontWeight.Medium
                    )
                }

                Surface(
                    color = ObsidianBlack.copy(alpha = 0.8f),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.5.dp, WarmGold)
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "كود الاشتراك",
                            style = MaterialTheme.typography.labelSmall,
                            color = MutedZinc
                        )
                        Text(
                            text = subscription.code,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black,
                            color = WarmGold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = GlassBorderWhite)
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "الباقة المشترك بها حالياً:",
                        style = MaterialTheme.typography.labelSmall,
                        color = MutedZinc
                    )
                    Text(
                        text = subscription.packageTitle,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = ChampagneGold
                    )
                }
                Surface(
                    color = FieryOrange.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, FieryOrange)
                ) {
                    Text(
                        text = "${subscription.pricePaidEgp} ج.م",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = CrispWhite,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun RemainingDurationGaugeCard(
    subscription: MemberSubscription
) {
    val progressTarget = remember(subscription.remainingDays, subscription.totalDays) {
        if (subscription.totalDays <= 0) 0f
        else (subscription.remainingDays.toFloat() / subscription.totalDays.toFloat()).coerceIn(0f, 1f)
    }
    val animatedProgress by animateFloatAsState(
        targetValue = progressTarget,
        animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
        label = "remaining_days_gauge"
    )
    val elapsedDays = (subscription.totalDays - subscription.remainingDays).coerceAtLeast(0)

    Surface(
        shape = RoundedCornerShape(26.dp),
        color = CardSurfaceDark,
        border = BorderStroke(1.dp, SubtleGlassBorderBrush),
        shadowElevation = 16.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Timer,
                    contentDescription = null,
                    tint = FieryOrange,
                    modifier = Modifier.size(22.dp)
                )
                Text(
                    text = "المدة المتبقية لانتهاء الاشتراك",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = CrispWhite
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                // Circular Progress Ring
                Box(
                    modifier = Modifier.size(136.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val strokeWidth = 12.dp.toPx()
                        drawArc(
                            color = Color.White.copy(alpha = 0.08f),
                            startAngle = -90f,
                            sweepAngle = 360f,
                            useCenter = false,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                        )
                        drawArc(
                            brush = Brush.sweepGradient(
                                listOf(FieryOrange, WarmGold, EmeraldSuccess, FieryOrange)
                            ),
                            startAngle = -90f,
                            sweepAngle = 360f * animatedProgress,
                            useCenter = false,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${subscription.remainingDays}",
                            style = MaterialTheme.typography.headlineLarge.copy(fontSize = 34.sp),
                            fontWeight = FontWeight.Black,
                            color = WarmGold
                        )
                        Text(
                            text = "يوم متبقي",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = CrispWhite
                        )
                        Text(
                            text = "من ${subscription.totalDays} يوم",
                            style = MaterialTheme.typography.labelSmall,
                            color = MutedZinc
                        )
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                // Start Date, End Date & Stats
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    DurationMetricTile(
                        label = "تاريخ بداية الاشتراك",
                        value = subscription.startDate,
                        accent = EmeraldSuccess
                    )
                    DurationMetricTile(
                        label = "تاريخ انتهاء الاشتراك",
                        value = subscription.endDate,
                        accent = FieryOrange
                    )
                    DurationMetricTile(
                        label = "الأيام المستهلكة حتى الآن",
                        value = "$elapsedDays يوم تمرين 💪",
                        accent = WarmGold
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = GlassBorderWhite)
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    color = CardSurfaceElevated,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, GlassBorderWhite),
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AcUnit,
                            contentDescription = null,
                            tint = WarmGold,
                            modifier = Modifier.size(20.dp)
                        )
                        Column {
                            Text(
                                text = "رصيد التجميد (Freeze)",
                                style = MaterialTheme.typography.labelSmall,
                                color = MutedZinc
                            )
                            Text(
                                text = "${subscription.freezeDaysAvailable} يوم متاح",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = CrispWhite
                            )
                        }
                    }
                }

                Surface(
                    color = CardSurfaceElevated,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, GlassBorderWhite),
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CardGiftcard,
                            contentDescription = null,
                            tint = FieryOrange,
                            modifier = Modifier.size(20.dp)
                        )
                        Column {
                            Text(
                                text = "دعوات الأصدقاء VIP",
                                style = MaterialTheme.typography.labelSmall,
                                color = MutedZinc
                            )
                            Text(
                                text = "${subscription.freeInvitationsLeft} دعوات مجانية",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = CrispWhite
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DurationMetricTile(
    label: String,
    value: String,
    accent: Color
) {
    Surface(
        color = CardSurfaceElevated,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.35f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MutedZinc
            )
            Text(
                text = value,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.ExtraBold,
                color = accent
            )
        }
    }
}

@Composable
private fun SubscriptionFullDetailsCard(
    subscription: MemberSubscription
) {
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = CardSurfaceDark,
        border = BorderStroke(1.dp, GlassBorderWhite),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.AssignmentInd,
                    contentDescription = null,
                    tint = WarmGold,
                    modifier = Modifier.size(22.dp)
                )
                Text(
                    text = "كافة تفاصيل المشترك ومميزات الباقة",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = CrispWhite
                )
            }

            DetailInfoRow("اسم المشترك:", subscription.fullName)
            DetailInfoRow("رقم الهاتف / واتساب:", subscription.phone)
            DetailInfoRow("كود الاشتراك الفعال:", subscription.code)
            DetailInfoRow("القسم:", subscription.genderCategory)
            DetailInfoRow("الباقة الحالية:", subscription.packageTitle)
            DetailInfoRow("قيمة الاشتراك المدفوع:", "${subscription.pricePaidEgp} ج.م (شامل خصم 50%)")
            DetailInfoRow("خطة المتابعة:", subscription.trainerNotes)

            if (subscription.perks.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "الخدمات المتاحة لك داخل الجيم بموجب اشتراكك:",
                    style = MaterialTheme.typography.labelLarge,
                    color = WarmGold,
                    fontWeight = FontWeight.Bold
                )
                subscription.perks.forEach { perk ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = EmeraldSuccess,
                            modifier = Modifier.size(17.dp)
                        )
                        Text(
                            text = perk,
                            style = MaterialTheme.typography.bodySmall,
                            color = CrispWhite.copy(alpha = 0.92f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailInfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(CardSurfaceElevated.copy(alpha = 0.7f))
            .padding(horizontal = 12.dp, vertical = 9.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MutedZinc
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold,
            color = CrispWhite,
            textAlign = TextAlign.End
        )
    }
}

@Composable
private fun RenewalPackageCard(
    pkg: MembershipPackage,
    isCurrentPackage: Boolean,
    onInstantRenew: () -> Unit,
    onWhatsAppConfirmRenewal: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = CardSurfaceDark,
        border = BorderStroke(
            width = if (pkg.isPopular || pkg.isVip) 1.5.dp else 1.dp,
            brush = if (pkg.isPopular || pkg.isVip) LuxuryGoldBorderBrush else SubtleGlassBorderBrush
        ),
        shadowElevation = 14.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = if (pkg.isVip) WarmGold.copy(alpha = 0.2f) else FieryOrange.copy(alpha = 0.18f),
                    shape = RoundedCornerShape(50),
                    border = BorderStroke(1.dp, if (pkg.isVip) WarmGold else FieryOrange)
                ) {
                    Text(
                        text = pkg.badgeText,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (pkg.isVip) WarmGold else CrispWhite,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }

                if (isCurrentPackage) {
                    Surface(
                        color = EmeraldSuccess.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(1.dp, EmeraldSuccess)
                    ) {
                        Text(
                            text = "باقتك الحالية ⭐",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldSuccess,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = pkg.title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = CrispWhite
                    )
                    Text(
                        text = "إضافة +${pkg.durationMonths * 30} يوم إلى اشتراكك الحالي",
                        style = MaterialTheme.typography.bodySmall,
                        color = WarmGold
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "${pkg.discountedPriceEgp} ج.م",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Black,
                        color = FieryOrange
                    )
                    Text(
                        text = "بدلاً من ${pkg.originalPriceEgp} ج.م",
                        style = MaterialTheme.typography.labelSmall.copy(
                            textDecoration = TextDecoration.LineThrough
                        ),
                        color = MutedZinc
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onInstantRenew,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("renew_pkg_${pkg.id}"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = FieryOrange,
                        contentColor = CrispWhite
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "تجديد فوري (+${pkg.durationMonths * 30} يوم)",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.ExtraBold
                    )
                }

                OutlinedButton(
                    onClick = onWhatsAppConfirmRenewal,
                    modifier = Modifier.height(48.dp),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, WhatsAppGreen),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = WhatsAppGreen)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = null,
                        tint = WhatsAppGreen,
                        modifier = Modifier.size(17.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "واتساب",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = CrispWhite
                    )
                }
            }
        }
    }
}
