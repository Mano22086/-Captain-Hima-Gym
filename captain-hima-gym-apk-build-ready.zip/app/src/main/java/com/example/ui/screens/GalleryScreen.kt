package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.*
import com.example.ui.components.PulsingBookNowButton
import com.example.ui.components.launchExternalUrl
import com.example.ui.theme.*

@Composable
fun GalleryScreen(
    cmsState: CaptainHimaCmsState,
    selectedCategory: GalleryCategory,
    onSelectCategory: (GalleryCategory) -> Unit,
    onOpenBooking: (bookingType: String, itemName: String, gender: String) -> Unit
) {
    val context = LocalContext.current
    var lightboxItem by remember { mutableStateOf<GalleryMediaItem?>(null) }

    val filteredGallery = remember(cmsState.galleryItems, selectedCategory) {
        if (selectedCategory == GalleryCategory.ALL) {
            cmsState.galleryItems
        } else {
            cmsState.galleryItems.filter { it.category == selectedCategory }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("gallery_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header + Official Social Album Links
        item {
            Column {
                Text(
                    text = "VISUAL SHOWCASE & POSTERS",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = WarmGold
                )
                Text(
                    text = "معرض صور وبوسترات كابتن هيما جيم 📸",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = CrispWhite
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "اضغط على أي صورة لتكبيرها (Lightbox) أو استعرض ألبومات فيسبوك وإنستجرام الرسمية",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedZinc
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Filter Chips Row
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(GalleryCategory.entries) { cat ->
                        val selected = selectedCategory == cat
                        Surface(
                            onClick = { onSelectCategory(cat) },
                            shape = RoundedCornerShape(50),
                            color = if (selected) FieryOrange else CardSurfaceDark,
                            border = BorderStroke(
                                1.dp,
                                if (selected) FieryOrange else GlassBorderWhite
                            ),
                            modifier = Modifier.testTag("gallery_filter_${cat.name.lowercase()}")
                        ) {
                            Text(
                                text = cat.labelAr,
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = if (selected) CrispWhite else MutedZinc,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                            )
                        }
                    }
                }
            }
        }

        // Gallery Media Cards
        items(filteredGallery, key = { it.id }) { item ->
            GalleryPhotoCard(
                item = item,
                onOpenLightbox = { lightboxItem = item },
                onOpenExternal = { url -> launchExternalUrl(context, url) }
            )
        }

        // Official Social Media Albums Reference Card
        item {
            Surface(
                color = CardSurfaceDark,
                shape = RoundedCornerShape(22.dp),
                border = BorderStroke(1.dp, WarmGold.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "روابط الصفحات الرسمية (فيسبوك • إنستجرام • تيك توك • جوجل) 🔗",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = WarmGold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OfficialLinkRow(
                        label = "بوستر عروض الـ 50% الرسمي (Facebook)",
                        onClick = { launchExternalUrl(context, cmsState.brandInfo.offersPosterUrl) }
                    )
                    OfficialLinkRow(
                        label = "جدول الحصص الجماعية الرسمي (Facebook)",
                        onClick = { launchExternalUrl(context, cmsState.brandInfo.classesSchedulePosterUrl) }
                    )
                    OfficialLinkRow(
                        label = "حساب إنستجرام الرسمي (@captain_hima_gym)",
                        onClick = { launchExternalUrl(context, cmsState.brandInfo.instagramUrl) }
                    )
                    OfficialLinkRow(
                        label = "حساب تيك توك الرسمي (TikTok Reels)",
                        onClick = { launchExternalUrl(context, cmsState.brandInfo.tiktokUrl) }
                    )
                    OfficialLinkRow(
                        label = "موقع وتقييمات كابتن هيما جيم على Google Maps",
                        onClick = { launchExternalUrl(context, cmsState.brandInfo.googleMapsUrl) }
                    )
                }
            }
        }
    }

    // Lightbox Full-Screen Modal
    val activeItem = lightboxItem
    if (activeItem != null) {
        Dialog(
            onDismissRequest = { lightboxItem = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.95f)
                    .border(1.5.dp, FieryOrange, RoundedCornerShape(26.dp)),
                shape = RoundedCornerShape(26.dp),
                color = CardSurfaceDark
            ) {
                Column {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(310.dp)
                    ) {
                        Image(
                            painter = painterResource(id = activeItem.drawableRes),
                            contentDescription = activeItem.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        IconButton(
                            onClick = { lightboxItem = null },
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(12.dp)
                                .clip(CircleShape)
                                .background(ObsidianBlack.copy(alpha = 0.75f))
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = CrispWhite)
                        }
                    }

                    Column(modifier = Modifier.padding(20.dp)) {
                        Surface(
                            color = FieryOrange.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = activeItem.badgeText,
                                style = MaterialTheme.typography.labelLarge,
                                color = FieryOrange,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = activeItem.title,
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = CrispWhite
                        )
                        Text(
                            text = activeItem.subtitle,
                            style = MaterialTheme.typography.labelLarge,
                            color = WarmGold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = activeItem.description,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MutedZinc
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            PulsingBookNowButton(
                                text = "احجز الآن 🔥",
                                onClick = {
                                    lightboxItem = null
                                    onOpenBooking(
                                        "اشتراك باقة",
                                        "باقة 3 شهور - 1,250 ج.م (الأكثر طلباً)",
                                        "قسم الرجال"
                                    )
                                },
                                modifier = Modifier.weight(1f)
                            )

                            if (activeItem.externalReferenceUrl != null) {
                                OutlinedButton(
                                    onClick = { launchExternalUrl(context, activeItem.externalReferenceUrl) },
                                    border = BorderStroke(1.dp, WarmGold),
                                    shape = RoundedCornerShape(50),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                ) {
                                    Text("البوست الأصلي 🔗", color = WarmGold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GalleryPhotoCard(
    item: GalleryMediaItem,
    onOpenLightbox: () -> Unit,
    onOpenExternal: (String) -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpenLightbox() },
        color = CardSurfaceDark,
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, GlassBorderWhite)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
            ) {
                Image(
                    painter = painterResource(id = item.drawableRes),
                    contentDescription = item.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, ObsidianBlack.copy(alpha = 0.88f))
                            )
                        )
                )
                Surface(
                    color = FieryOrange,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(12.dp)
                ) {
                    Text(
                        text = item.badgeText,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = CrispWhite,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }

                IconButton(
                    onClick = onOpenLightbox,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(10.dp)
                        .clip(CircleShape)
                        .background(ObsidianBlack.copy(alpha = 0.65f))
                ) {
                    Icon(
                        imageVector = Icons.Default.ZoomIn,
                        contentDescription = "تكبير الصورة",
                        tint = WarmGold
                    )
                }

                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(14.dp)
                ) {
                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = CrispWhite
                    )
                    Text(
                        text = item.subtitle,
                        style = MaterialTheme.typography.labelMedium,
                        color = WarmGold
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = item.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedZinc,
                    modifier = Modifier.weight(1f)
                )
                if (item.externalReferenceUrl != null) {
                    Spacer(modifier = Modifier.width(8.dp))
                    TextButton(onClick = { onOpenExternal(item.externalReferenceUrl) }) {
                        Text("فيسبوك 🔗", color = FieryOrange)
                    }
                }
            }
        }
    }
}

@Composable
private fun OfficialLinkRow(
    label: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        color = CardSurfaceElevated,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, GlassBorderWhite),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = CrispWhite
            )
            Icon(
                imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                contentDescription = null,
                tint = FieryOrange,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}
