package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.components.PulsingBookNowButton
import com.example.ui.components.launchExternalUrl
import com.example.ui.theme.*

@Composable
fun PackagesAndClassesScreen(
    cmsState: CaptainHimaCmsState,
    selectedClassFilter: ClassGenderFilter,
    onSelectClassFilter: (ClassGenderFilter) -> Unit,
    onOpenBooking: (bookingType: String, itemName: String, gender: String) -> Unit
) {
    val context = LocalContext.current
    val filteredClasses = remember(cmsState.groupClasses, selectedClassFilter) {
        when (selectedClassFilter) {
            ClassGenderFilter.ALL -> cmsState.groupClasses
            ClassGenderFilter.MEN -> cmsState.groupClasses.filter {
                it.category == ClassGenderFilter.MEN || it.category == ClassGenderFilter.ALL
            }
            ClassGenderFilter.LADIES -> cmsState.groupClasses.filter {
                it.category == ClassGenderFilter.LADIES || it.category == ClassGenderFilter.ALL
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("packages_classes_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Interactive VIP Black & Gold Digital Pass & 50% Calculator
        item {
            DiscountCalculatorCard(
                packages = cmsState.packages,
                onBookCalculated = { pkgTitle, membersCount, totalEgp ->
                    onOpenBooking(
                        "اشتراك باقة",
                        "$pkgTitle (عدد $membersCount مشترك - الإجمالي $totalEgp ج.م بعد خصم 50%)",
                        "قسم الرجال"
                    )
                }
            )
        }

        // 2. Membership Packages Header + Official Facebook Offers Poster Link
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "VIP MEMBERSHIP PLANS",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = WarmGold,
                        letterSpacing = 1.4.sp
                    )
                    Text(
                        text = "باقات العضوية (خصم 50% 🔥)",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = CrispWhite
                    )
                }
                OutlinedButton(
                    onClick = { launchExternalUrl(context, cmsState.brandInfo.offersPosterUrl) },
                    border = BorderStroke(1.dp, WarmGold),
                    shape = RoundedCornerShape(50)
                ) {
                    Icon(Icons.Default.Image, contentDescription = null, tint = WarmGold, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("بوستر العروض", color = WarmGold, style = MaterialTheme.typography.labelLarge)
                }
            }
        }

        // 3. Full Membership Package Cards
        items(cmsState.packages, key = { it.id }) { pkg ->
            FullPackagePlanCard(
                pkg = pkg,
                onBookPackage = { gender ->
                    onOpenBooking(
                        "اشتراك باقة",
                        "${pkg.title} - ${pkg.discountedPriceEgp} ج.م بدلاً من ${pkg.originalPriceEgp} ج.م",
                        gender
                    )
                }
            )
        }

        // 4. Weekly Group Classes Schedule Header + Gender Filter Tabs
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "SATURDAY TO THURSDAY",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = FieryOrange,
                        letterSpacing = 1.4.sp
                    )
                    Text(
                        text = "جدول الحصص الجماعية الأسبوعي",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = CrispWhite
                    )
                }
                OutlinedButton(
                    onClick = { launchExternalUrl(context, cmsState.brandInfo.classesSchedulePosterUrl) },
                    border = BorderStroke(1.dp, FieryOrange),
                    shape = RoundedCornerShape(50)
                ) {
                    Text("جدول فيسبوك", color = FieryOrange, style = MaterialTheme.typography.labelLarge)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Filter Pills: All / Men / Ladies
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ClassGenderFilter.entries.forEach { filter ->
                    val isSelected = selectedClassFilter == filter
                    Surface(
                        onClick = { onSelectClassFilter(filter) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("class_filter_${filter.name.lowercase()}"),
                        shape = RoundedCornerShape(50),
                        color = if (isSelected) FieryOrange else CardSurfaceDark,
                        border = BorderStroke(
                            1.dp,
                            if (isSelected) WarmGold else GlassBorderWhite
                        )
                    ) {
                        Box(
                            modifier = Modifier.padding(vertical = 11.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = filter.labelAr,
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (isSelected) CrispWhite else MutedZinc
                            )
                        }
                    }
                }
            }
        }

        // 5. Filtered Group Class Cards
        items(filteredClasses, key = { it.id }) { cls ->
            DetailedGroupClassCard(
                cls = cls,
                onBookClass = {
                    val gender = if (cls.category == ClassGenderFilter.LADIES) "قسم السيدات" else "قسم الرجال"
                    onOpenBooking(
                        "حجز حصة جماعية",
                        "${cls.nameAr} (${cls.daysAr} - ${cls.timeSlotAr})",
                        gender
                    )
                }
            )
        }
    }
}

@Composable
private fun DiscountCalculatorCard(
    packages: List<MembershipPackage>,
    onBookCalculated: (pkgTitle: String, membersCount: Int, totalEgp: Int) -> Unit
) {
    var selectedPkgIndex by remember { mutableIntStateOf(1) }
    var membersCount by remember { mutableIntStateOf(1) }

    val selectedPkg = packages.getOrElse(selectedPkgIndex) { packages.first() }
    val totalOriginal = selectedPkg.originalPriceEgp * membersCount
    val totalDiscounted = selectedPkg.discountedPriceEgp * membersCount
    val totalSaved = totalOriginal - totalDiscounted
    val monthlyCostPerMember = selectedPkg.discountedPriceEgp / selectedPkg.durationMonths.coerceAtLeast(1)

    Surface(
        color = CardSurfaceDark,
        shape = RoundedCornerShape(28.dp),
        shadowElevation = 18.dp,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.5.dp, LuxuryGoldBorderBrush, RoundedCornerShape(28.dp))
            .testTag("discount_calculator_card")
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(WarmGold.copy(alpha = 0.18f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.WorkspacePremium,
                            contentDescription = null,
                            tint = WarmGold,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "حاسبة خصم الـ 50% الذكية ⚡",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = CrispWhite
                        )
                        Text(
                            text = "صمم باقتك واحسب توفيرك الفوري",
                            style = MaterialTheme.typography.labelMedium,
                            color = WarmGold
                        )
                    }
                }

                Surface(
                    color = EmeraldSuccess.copy(alpha = 0.18f),
                    shape = RoundedCornerShape(50),
                    border = BorderStroke(1.dp, EmeraldSuccess)
                ) {
                    Text(
                        text = "-50% OFF",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = EmeraldSuccess,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "1. اختر مدة العضوية:",
                style = MaterialTheme.typography.labelLarge,
                color = CrispWhite
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                packages.forEachIndexed { index, pkg ->
                    val selected = selectedPkgIndex == index
                    Surface(
                        onClick = { selectedPkgIndex = index },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(16.dp),
                        color = if (selected) FieryOrange else CardSurfaceElevated,
                        border = BorderStroke(1.dp, if (selected) WarmGold else GlassBorderWhite)
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "${pkg.durationMonths} ${if (pkg.durationMonths == 1) "شهر" else "شهور"}",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = CrispWhite
                            )
                            Text(
                                text = "${pkg.discountedPriceEgp} ج",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (selected) ChampagneGold else WarmGold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "2. عدد المشتركين: ($membersCount ${if (membersCount == 1) "بطل" else "أبطال"})",
                style = MaterialTheme.typography.labelLarge,
                color = CrispWhite
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                (1..4).forEach { count ->
                    val selected = membersCount == count
                    Surface(
                        onClick = { membersCount = count },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp),
                        color = if (selected) WarmGold.copy(alpha = 0.22f) else CardSurfaceElevated,
                        border = BorderStroke(1.dp, if (selected) WarmGold else GlassBorderWhite)
                    ) {
                        Box(
                            modifier = Modifier.padding(vertical = 9.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "$count 👤",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (selected) WarmGold else MutedZinc
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Digital VIP Membership Summary Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(ObsidianBlack, CardSurfaceElevated)
                        )
                    )
                    .border(1.dp, WarmGold.copy(alpha = 0.45f), RoundedCornerShape(20.dp))
                    .padding(16.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("السعر الرسمي قبل العرض:", color = MutedZinc, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            text = "$totalOriginal ج.م",
                            color = MutedZinc,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                textDecoration = TextDecoration.LineThrough
                            )
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("إجمالي التوفير الفوري:", color = EmeraldSuccess, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            text = "وفرت $totalSaved ج.م 🎉",
                            color = EmeraldSuccess,
                            fontWeight = FontWeight.ExtraBold,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("تكلفة الشهر للفرد:", color = WarmGold, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            text = "$monthlyCostPerMember ج.م / شهر فقط",
                            color = WarmGold,
                            fontWeight = FontWeight.ExtraBold,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = GlassBorderWhite)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "الإجمالي بعد خصم 50%:",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = CrispWhite
                        )
                        Text(
                            text = "$totalDiscounted ج.م",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = FieryOrange
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            PulsingBookNowButton(
                text = "احجز ${selectedPkg.title} بـ $totalDiscounted ج.م 🔥",
                onClick = { onBookCalculated(selectedPkg.title, membersCount, totalDiscounted) },
                modifier = Modifier.fillMaxWidth(),
                testTag = "calculator_book_button"
            )
        }
    }
}

@Composable
private fun FullPackagePlanCard(
    pkg: MembershipPackage,
    onBookPackage: (gender: String) -> Unit
) {
    Surface(
        color = CardSurfaceDark,
        shape = RoundedCornerShape(26.dp),
        shadowElevation = 14.dp,
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (pkg.isPopular || pkg.isVip) 2.dp else 1.dp,
                brush = if (pkg.isVip || pkg.isPopular) LuxuryGoldBorderBrush else SubtleGlassBorderBrush,
                shape = RoundedCornerShape(26.dp)
            )
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = if (pkg.isVip) WarmGold else FieryOrange,
                    shape = RoundedCornerShape(50)
                ) {
                    Text(
                        text = pkg.badgeText,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (pkg.isVip) ObsidianBlack else CrispWhite,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }

                Surface(
                    color = EmeraldSuccess.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(50),
                    border = BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = "وفر ${pkg.originalPriceEgp - pkg.discountedPriceEgp} ج.م",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = EmeraldSuccess,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = pkg.title,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = CrispWhite
                    )
                    Text(
                        text = pkg.subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MutedZinc
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "${pkg.originalPriceEgp} ج.م",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            textDecoration = TextDecoration.LineThrough
                        ),
                        color = MutedZinc
                    )
                    Text(
                        text = "${pkg.discountedPriceEgp} ج.م",
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (pkg.isVip) WarmGold else FieryOrange
                    )
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = GlassBorderWhite)

            pkg.perks.forEach { perk ->
                Row(
                    modifier = Modifier.padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Verified,
                        contentDescription = null,
                        tint = if (pkg.isVip) WarmGold else FieryOrange,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = perk,
                        style = MaterialTheme.typography.bodyMedium,
                        color = CrispWhite
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { onBookPackage("قسم الرجال") },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = FieryOrange)
                ) {
                    Text("احجز للرجال 💪", fontWeight = FontWeight.ExtraBold, color = CrispWhite)
                }
                OutlinedButton(
                    onClick = { onBookPackage("قسم السيدات") },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.5.dp, WarmGold)
                ) {
                    Text("احجزي للسيدات 💃", fontWeight = FontWeight.ExtraBold, color = WarmGold)
                }
            }
        }
    }
}

@Composable
private fun DetailedGroupClassCard(
    cls: GroupClassItem,
    onBookClass: () -> Unit
) {
    Surface(
        color = CardSurfaceDark,
        shape = RoundedCornerShape(24.dp),
        shadowElevation = 10.dp,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SubtleGlassBorderBrush, RoundedCornerShape(24.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .border(1.dp, GlassBorderWhite, RoundedCornerShape(18.dp))
            ) {
                Image(
                    painter = painterResource(id = cls.drawableRes),
                    contentDescription = cls.nameAr,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, ObsidianBlack.copy(alpha = 0.85f))
                            )
                        )
                )
                Text(
                    text = cls.nameEn,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = WarmGold,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(6.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = if (cls.category == ClassGenderFilter.LADIES) LikeCrimson.copy(alpha = 0.2f)
                        else FieryOrange.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(50)
                    ) {
                        Text(
                            text = cls.category.labelAr,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (cls.category == ClassGenderFilter.LADIES) LikeCrimson else FieryOrange,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                        )
                    }
                    Text(
                        text = "🔥 ${cls.caloriesBurn}",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = WarmGold
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = cls.nameAr,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = CrispWhite
                )

                Text(
                    text = "📅 ${cls.daysAr}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedZinc
                )
                Text(
                    text = "⏰ ${cls.timeSlotAr}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = CrispWhite
                )
                Text(
                    text = "👟 ${cls.trainerName}",
                    style = MaterialTheme.typography.labelMedium,
                    color = WarmGold
                )

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = onBookClass,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(42.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = FieryOrange),
                    contentPadding = PaddingValues(vertical = 4.dp)
                ) {
                    Text("احجز مكانك في الحصة 🔥", color = CrispWhite, fontWeight = FontWeight.ExtraBold)
                }
            }
        }
    }
}
