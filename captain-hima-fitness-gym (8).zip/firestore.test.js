import { test, before, after, beforeEach } from 'node:test';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const {
  initializeTestEnvironment,
  assertSucceeds,
  assertFails,
} = require('@firebase/rules-unit-testing');
const rutPkgRequire = createRequire(require.resolve('@firebase/rules-unit-testing'));
const {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  collection,
  getDocs,
  serverTimestamp,
  setLogLevel,
} = rutPkgRequire('firebase/firestore');

setLogLevel('error');

const PROJECT_ID = 'demo-test-project';
let testEnv;

before(async () => {
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules: readFileSync('firestore.rules', 'utf8'),
      host: '127.0.0.1',
      port: 8085,
    },
  });
});

beforeEach(async () => {
  await testEnv.clearFirestore();
});

after(async () => {
  await testEnv.cleanup();
});

const validBooking = (userId, overrides = {}) => ({
  userId,
  referenceCode: 'CHG-1234',
  fullName: 'محمود نعيم',
  phone: '01039157200',
  genderCategory: 'رجال',
  bookingType: 'package',
  selectedItemName: 'باقة 3 شهور (الأكثر طلباً)',
  preferredDateTime: 'السبت 6 مساءً',
  notes: 'أول مرة في الجيم',
  status: 'pending',
  createdAt: serverTimestamp(),
  updatedAt: serverTimestamp(),
  ...overrides,
});

const validGymConfig = (adminUid, overrides = {}) => ({
  phoneDisplay: '01039157200',
  addressAr: 'المنشية سيتي، الدور الثاني، شارع المنشية متفرع من شارع الملك فيصل',
  workingHours: 'مفتوح 24 ساعة يومياً',
  pkg1mPrice: '600',
  pkg3mPrice: '1,250',
  pkg6mPrice: '2,000',
  pkg12mPrice: '2,750',
  updatedBy: adminUid,
  updatedAt: serverTimestamp(),
  ...overrides,
});

const validComment = (userId, overrides = {}) => ({
  userId,
  storyId: 'story_1',
  authorName: 'كابتن أحمد',
  text: 'أقوى جيم في المنشية عاش يا وحوش!',
  createdAt: serverTimestamp(),
  ...overrides,
});

test('unauthenticated user cannot read or create bookings', async () => {
  const unauthedDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(getDoc(doc(unauthedDb, 'bookings/b1')));
  await assertFails(setDoc(doc(unauthedDb, 'bookings/b1'), validBooking('anon')));
});

test('owner can create and read their own booking', async () => {
  const aliceDb = testEnv.authenticatedContext('alice').firestore();
  const ref = doc(aliceDb, 'bookings/b1');
  await assertSucceeds(setDoc(ref, validBooking('alice')));
  await assertSucceeds(getDoc(ref));
});

test('non-owner cannot read or delete another user booking', async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await setDoc(doc(ctx.firestore(), 'bookings/b1'), validBooking('alice'));
  });

  const bobDb = testEnv.authenticatedContext('bob').firestore();
  await assertFails(getDoc(doc(bobDb, 'bookings/b1')));
  await assertFails(deleteDoc(doc(bobDb, 'bookings/b1')));
});

test('bootstrapped admin can read, update status, and list all bookings', async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await setDoc(doc(ctx.firestore(), 'bookings/b1'), validBooking('alice'));
  });

  const adminDb = testEnv.authenticatedContext('admin_user', {
    email: 'Manohegazy595@gmail.com',
    email_verified: true,
  }).firestore();

  await assertSucceeds(getDoc(doc(adminDb, 'bookings/b1')));
  await assertSucceeds(getDocs(collection(adminDb, 'bookings')));
  await assertSucceeds(
    updateDoc(doc(adminDb, 'bookings/b1'), {
      status: 'confirmed',
      updatedAt: serverTimestamp(),
    })
  );
});

test('only admin can write gym_config/main, while any signed-in user can read it', async () => {
  const aliceDb = testEnv.authenticatedContext('alice').firestore();
  const adminDb = testEnv.authenticatedContext('admin_user', {
    email: 'Manohegazy595@gmail.com',
    email_verified: true,
  }).firestore();

  await assertFails(setDoc(doc(aliceDb, 'gym_config/main'), validGymConfig('alice')));
  await assertSucceeds(setDoc(doc(adminDb, 'gym_config/main'), validGymConfig('admin_user')));
  await assertSucceeds(getDoc(doc(aliceDb, 'gym_config/main')));
});

test('signed-in user can create and read story comments, but cannot spoof userId', async () => {
  const aliceDb = testEnv.authenticatedContext('alice').firestore();
  await assertFails(setDoc(doc(aliceDb, 'story_comments/c1'), validComment('bob')));
  await assertSucceeds(setDoc(doc(aliceDb, 'story_comments/c1'), validComment('alice')));
  await assertSucceeds(getDocs(collection(aliceDb, 'story_comments')));
});
