package com.example.viewmodel

import android.app.Application
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.GymCloudRepository
import com.example.data.GymCmsRepository
import com.example.data.SupabaseGymClient
import com.example.model.*
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.random.Random

data class BookingModalUiState(
    val isOpen: Boolean = false,
    val genderCategory: String = "قسم الرجال",
    val bookingType: String = "اشتراك باقة",
    val selectedItemName: String = "باقة 3 شهور - 1,250 ج.م (الأكثر طلباً)",
    val confirmedRecord: BookingRecord? = null,
    val errorMessage: String? = null
)

class GymViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = GymCmsRepository(application)
    private val cloudRepository = GymCloudRepository(application)
    val cmsState: StateFlow<CaptainHimaCmsState> = repository.cmsState

    private val _isSplashVisible = MutableStateFlow(true)
    val isSplashVisible: StateFlow<Boolean> = _isSplashVisible.asStateFlow()

    private val _hasEnteredApp = MutableStateFlow(
        !repository.cmsState.value.activeSubscriptionCode.isNullOrBlank()
    )
    val hasEnteredApp: StateFlow<Boolean> = _hasEnteredApp.asStateFlow()

    private val _isCodeEntryModalOpen = MutableStateFlow(false)
    val isCodeEntryModalOpen: StateFlow<Boolean> = _isCodeEntryModalOpen.asStateFlow()

    private val _currentTab = MutableStateFlow(MainTab.HOME)
    val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

    private val _selectedStoryIndex = MutableStateFlow(0)
    val selectedStoryIndex: StateFlow<Int> = _selectedStoryIndex.asStateFlow()

    private val _isAudioMuted = MutableStateFlow(false)
    val isAudioMuted: StateFlow<Boolean> = _isAudioMuted.asStateFlow()

    private val _classFilter = MutableStateFlow(ClassGenderFilter.ALL)
    val classFilter: StateFlow<ClassGenderFilter> = _classFilter.asStateFlow()

    private val _galleryFilter = MutableStateFlow(GalleryCategory.ALL)
    val galleryFilter: StateFlow<GalleryCategory> = _galleryFilter.asStateFlow()

    private val _bookingModalState = MutableStateFlow(BookingModalUiState())
    val bookingModalState: StateFlow<BookingModalUiState> = _bookingModalState.asStateFlow()

    private val settingsPrefs = application.getSharedPreferences("captain_hima_user_settings", Application.MODE_PRIVATE)

    private val _userSettings = MutableStateFlow(
        UserSettingsState(
            notificationsEnabled = settingsPrefs.getBoolean("notifications_enabled", true),
            isDarkMode = settingsPrefs.getBoolean("is_dark_mode", true)
        ).also {
            com.example.ui.theme.AppThemeController.isDarkMode = it.isDarkMode
        }
    )
    val userSettings: StateFlow<UserSettingsState> = _userSettings.asStateFlow()

    private var syncJobs: List<Job> = emptyList()
    private var activeSubListenerJob: Job? = null

    fun completeSplash() {
        _isSplashVisible.value = false
    }

    fun enterAsNewMember() {
        _hasEnteredApp.value = true
    }

    fun returnToWelcomePortal() {
        _hasEnteredApp.value = false
    }

    fun openCodeEntryModal() {
        _isCodeEntryModalOpen.value = true
    }

    fun closeCodeEntryModal() {
        _isCodeEntryModalOpen.value = false
    }

    fun updateUserSettings(newSettings: UserSettingsState) {
        _userSettings.value = newSettings
        com.example.ui.theme.AppThemeController.isDarkMode = newSettings.isDarkMode
        settingsPrefs.edit()
            .putBoolean("notifications_enabled", newSettings.notificationsEnabled)
            .putBoolean("is_dark_mode", newSettings.isDarkMode)
            .apply()
    }

    fun markAllNotificationsRead() {
        repository.updateState { current ->
            current.copy(
                notifications = current.notifications.map { it.copy(isRead = true) }
            )
        }
    }

    fun markNotificationRead(id: String) {
        repository.updateState { current ->
            current.copy(
                notifications = current.notifications.map {
                    if (it.id == id) it.copy(isRead = true) else it
                }
            )
        }
    }

    fun verifyAndActivateSubscriptionCode(
        rawCode: String,
        navigateToSubscriptionTab: Boolean = true
    ): Boolean {
        val code = rawCode.trim().uppercase()
        if (code.isEmpty()) return false

        val state = cmsState.value
        val existingSub = state.subscriptions.firstOrNull { it.code.equals(code, ignoreCase = true) }
        if (existingSub != null) {
            repository.updateState { current ->
                current.copy(activeSubscriptionCode = existingSub.code)
            }
            observeActiveSubscriptionFromCloud(existingSub.code)
            _hasEnteredApp.value = true
            _isCodeEntryModalOpen.value = false
            if (navigateToSubscriptionTab) {
                _currentTab.value = MainTab.SUBSCRIPTION
            }
            return true
        }

        // Check if it matches any booking reference code
        val matchingBooking = state.bookings.firstOrNull {
            it.referenceCode.equals(code, ignoreCase = true)
        }
        if (matchingBooking != null) {
            val generatedSub = createSubscriptionFromBooking(matchingBooking, state.packages)
            repository.updateState { current ->
                current.copy(
                    subscriptions = listOf(generatedSub) + current.subscriptions,
                    activeSubscriptionCode = generatedSub.code
                )
            }
            observeActiveSubscriptionFromCloud(generatedSub.code)
            _hasEnteredApp.value = true
            _isCodeEntryModalOpen.value = false
            if (navigateToSubscriptionTab) {
                _currentTab.value = MainTab.SUBSCRIPTION
            }
            return true
        }

        // Also check cloud (Supabase & Firestore) asynchronously for codes generated/approved in Admin Dashboard
        viewModelScope.launch {
            val remoteSub = SupabaseGymClient.fetchSubscriptionByCode(code)
                ?: cloudRepository.fetchSubscriptionByCode(code)
            if (remoteSub != null) {
                repository.updateState { current ->
                    val filtered = current.subscriptions.filterNot { it.code.equals(remoteSub.code, ignoreCase = true) }
                    current.copy(
                        subscriptions = listOf(remoteSub) + filtered,
                        activeSubscriptionCode = remoteSub.code
                    )
                }
                observeActiveSubscriptionFromCloud(remoteSub.code)
                _hasEnteredApp.value = true
                _isCodeEntryModalOpen.value = false
                if (navigateToSubscriptionTab) {
                    _currentTab.value = MainTab.SUBSCRIPTION
                }
            }
        }

        return false
    }

    private fun observeActiveSubscriptionFromCloud(code: String) {
        activeSubListenerJob?.cancel()
        if (code.isBlank()) return
        activeSubListenerJob = viewModelScope.launch {
            cloudRepository.observeSubscriptionByCode(code)
                .catch { e -> Log.e("GymViewModel", "observeSubscriptionByCode error", e) }
                .collect { remoteSub ->
                    if (remoteSub != null) {
                        repository.updateState { current ->
                            val exists = current.subscriptions.any { it.code.equals(remoteSub.code, ignoreCase = true) }
                            val updatedList = if (exists) {
                                current.subscriptions.map {
                                    if (it.code.equals(remoteSub.code, ignoreCase = true)) remoteSub else it
                                }
                            } else {
                                listOf(remoteSub) + current.subscriptions
                            }
                            current.copy(subscriptions = updatedList)
                        }
                    }
                }
        }
    }

    fun clearActiveSubscriptionCode() {
        activeSubListenerJob?.cancel()
        repository.updateState { current ->
            current.copy(activeSubscriptionCode = null)
        }
    }

    fun renewOrUpgradeSubscription(
        subscriptionCode: String,
        selectedPackage: MembershipPackage,
        onRenewed: (MemberSubscription) -> Unit = {}
    ) {
        val addedDays = selectedPackage.durationMonths * 30
        val addedMillis = addedDays * 86_400_000L
        val nowUtc = System.currentTimeMillis()
        val currentSub = cmsState.value.subscriptions.firstOrNull {
            it.code.equals(subscriptionCode, ignoreCase = true)
        } ?: return

        val existingExpiry = currentSub.expiresAtUtcMillis ?: 0L
        val baseExpiry = if (existingExpiry > nowUtc) {
            existingExpiry
        } else {
            nowUtc
        }
        val newExpiresUtc = baseExpiry + addedMillis
        val newRemainingDays = currentSub.computeRealTimeRemainingDays(nowUtc) + addedDays
        val newTotalDays = currentSub.totalDays + addedDays

        val cairoFormat = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).apply {
            timeZone = TimeZone.getTimeZone("Africa/Cairo")
        }
        val newEndDate = cairoFormat.format(Date(newExpiresUtc))

        val updatedSub = currentSub.copy(
            packageId = selectedPackage.id,
            packageTitle = "${selectedPackage.title} - ${selectedPackage.discountedPriceEgp} ج.م (طلب تجديد)",
            pricePaidEgp = selectedPackage.discountedPriceEgp,
            durationMonths = selectedPackage.durationMonths,
            totalDays = newTotalDays,
            remainingDays = newRemainingDays,
            endDate = newEndDate,
            expiresAtUtcMillis = newExpiresUtc,
            statusCode = if (currentSub.statusCode == "ACTIVE") "ACTIVE" else "PENDING",
            statusAr = if (currentSub.statusCode == "ACTIVE") "نشط وتم تمديد الاشتراك ✅" else "في انتظار تأكيد الإدارة ⏳",
            freezeDaysAvailable = currentSub.freezeDaysAvailable + (selectedPackage.durationMonths * 3),
            freeInvitationsLeft = currentSub.freeInvitationsLeft + selectedPackage.durationMonths,
            perks = selectedPackage.perks
        )

        repository.updateState { state ->
            val updatedList = state.subscriptions.map {
                if (it.code.equals(subscriptionCode, ignoreCase = true)) updatedSub else it
            }
            state.copy(
                subscriptions = updatedList,
                activeSubscriptionCode = updatedSub.code
            )
        }

        viewModelScope.launch {
            runCatching {
                cloudRepository.submitPendingSubscriptionOrder(updatedSub)
            }
        }

        onRenewed(updatedSub)
    }

    fun buildWhatsAppRenewalUrl(sub: MemberSubscription, pkg: MembershipPackage): String {
        val whatsappIntl = cmsState.value.brandInfo.whatsappIntl
        val message = buildString {
            appendLine("⚡ *طلب تجديد / ترقية اشتراك - CAPTAIN HIMA FITNESS GYM* ⚡")
            appendLine("━━━━━━━━━━━━━━━━━━")
            appendLine("🧾 *رقم الطلب:* ${sub.orderNumber}")
            appendLine("🔑 *كود الاشتراك:* ${sub.code}")
            appendLine("👤 *اسم العميل:* ${sub.fullName}")
            appendLine("📱 *رقم الهاتف:* ${sub.phone}")
            appendLine("🏋️ *القسم:* ${sub.genderCategory}")
            appendLine("🏆 *الباقة المختارة للتجديد:* ${pkg.title}")
            appendLine("💰 *السعر:* ${pkg.discountedPriceEgp} ج.م (بدلاً من ${pkg.originalPriceEgp} ج.م)")
            appendLine("⏳ *الأيام المتبقية بعد التجديد:* ${sub.computeRealTimeRemainingDays()} يوم")
            appendLine("━━━━━━━━━━━━━━━━━━")
            append("📍 ${cmsState.value.brandInfo.addressAr}")
        }
        return "https://wa.me/$whatsappIntl?text=${Uri.encode(message)}"
    }

    fun startCloudSync() {
        stopCloudSync()

        cmsState.value.activeSubscriptionCode?.let { code ->
            if (code.isNotBlank()) {
                observeActiveSubscriptionFromCloud(code)
            }
        }

        // Sync Stories, News/Notifications, Settings, and Active Subscription from Supabase if configured
        viewModelScope.launch {
            if (SupabaseGymClient.isConfigured) {
                SupabaseGymClient.fetchGymConfig()?.let { sbConfig ->
                    repository.updateState { state ->
                        val parsePrice = { str: String, fallback: Int ->
                            str.replace(",", "").trim().toIntOrNull() ?: fallback
                        }
                        val updatedPackages = state.packages.map { pkg ->
                            when (pkg.id) {
                                "pkg_1m" -> pkg.copy(discountedPriceEgp = parsePrice(sbConfig.pkg1mPrice, pkg.discountedPriceEgp), originalPriceEgp = parsePrice(sbConfig.pkg1mPrice, pkg.discountedPriceEgp) * 2)
                                "pkg_3m" -> pkg.copy(discountedPriceEgp = parsePrice(sbConfig.pkg3mPrice, pkg.discountedPriceEgp), originalPriceEgp = parsePrice(sbConfig.pkg3mPrice, pkg.discountedPriceEgp) * 2)
                                "pkg_6m" -> pkg.copy(discountedPriceEgp = parsePrice(sbConfig.pkg6mPrice, pkg.discountedPriceEgp), originalPriceEgp = parsePrice(sbConfig.pkg6mPrice, pkg.discountedPriceEgp) * 2)
                                "pkg_12m" -> pkg.copy(discountedPriceEgp = parsePrice(sbConfig.pkg12mPrice, pkg.discountedPriceEgp), originalPriceEgp = parsePrice(sbConfig.pkg12mPrice, pkg.discountedPriceEgp) * 2)
                                else -> pkg
                            }
                        }
                        state.copy(
                            brandInfo = state.brandInfo.copy(
                                phoneDisplay = sbConfig.phoneDisplay.ifBlank { state.brandInfo.phoneDisplay },
                                whatsappIntl = sbConfig.whatsappIntl.ifBlank { state.brandInfo.whatsappIntl },
                                addressAr = sbConfig.addressAr.ifBlank { state.brandInfo.addressAr },
                                workingHours = sbConfig.workingHours.ifBlank { state.brandInfo.workingHours },
                                tiktokUrl = sbConfig.tiktokUrl.ifBlank { state.brandInfo.tiktokUrl },
                                facebookPageUrl = sbConfig.facebookPageUrl.ifBlank { state.brandInfo.facebookPageUrl },
                                instagramUrl = sbConfig.instagramUrl.ifBlank { state.brandInfo.instagramUrl },
                                googleMapsUrl = sbConfig.googleMapsUrl.ifBlank { state.brandInfo.googleMapsUrl }
                            ),
                            packages = updatedPackages
                        )
                    }
                }

                SupabaseGymClient.fetchStories(cmsState.value.stories)?.let { sbStories ->
                    if (sbStories.isNotEmpty()) {
                        repository.updateState { state ->
                            state.copy(stories = sbStories)
                        }
                    }
                }

                SupabaseGymClient.fetchNotifications(cmsState.value.activeSubscriptionCode)?.let { sbNotifs ->
                    if (sbNotifs.isNotEmpty()) {
                        repository.updateState { state ->
                            val existingIds = sbNotifs.map { it.id }.toSet()
                            state.copy(notifications = sbNotifs + state.notifications.filterNot { it.id in existingIds })
                        }
                    }
                }

                cmsState.value.activeSubscriptionCode?.takeIf { it.isNotBlank() }?.let { activeCode ->
                    SupabaseGymClient.fetchSubscriptionByCode(activeCode)?.let { sbSub ->
                        repository.updateState { state ->
                            val filtered = state.subscriptions.filterNot { it.code.equals(sbSub.code, ignoreCase = true) }
                            state.copy(subscriptions = listOf(sbSub) + filtered)
                        }
                    }
                }
            }
        }

        val configJob = viewModelScope.launch {
            cloudRepository.observeGymConfig()
                .catch { e -> Log.e("GymViewModel", "observeGymConfig error", e) }
                .collect { cloudConfig ->
                    if (cloudConfig != null) {
                        repository.updateState { state ->
                            val parsePrice = { str: String, fallback: Int ->
                                str.replace(",", "").trim().toIntOrNull() ?: fallback
                            }
                            val updatedPackages = state.packages.map { pkg ->
                                when (pkg.id) {
                                    "pkg_1m" -> {
                                        val p = parsePrice(cloudConfig.pkg1mPrice, pkg.discountedPriceEgp)
                                        pkg.copy(discountedPriceEgp = p, originalPriceEgp = p * 2)
                                    }
                                    "pkg_3m" -> {
                                        val p = parsePrice(cloudConfig.pkg3mPrice, pkg.discountedPriceEgp)
                                        pkg.copy(discountedPriceEgp = p, originalPriceEgp = p * 2)
                                    }
                                    "pkg_6m" -> {
                                        val p = parsePrice(cloudConfig.pkg6mPrice, pkg.discountedPriceEgp)
                                        pkg.copy(discountedPriceEgp = p, originalPriceEgp = p * 2)
                                    }
                                    "pkg_12m" -> {
                                        val p = parsePrice(cloudConfig.pkg12mPrice, pkg.discountedPriceEgp)
                                        pkg.copy(discountedPriceEgp = p, originalPriceEgp = p * 2)
                                    }
                                    else -> pkg
                                }
                            }
                            state.copy(
                                brandInfo = state.brandInfo.copy(
                                    phoneDisplay = cloudConfig.phoneDisplay.ifBlank { state.brandInfo.phoneDisplay },
                                    addressAr = cloudConfig.addressAr.ifBlank { state.brandInfo.addressAr },
                                    workingHours = cloudConfig.workingHours.ifBlank { state.brandInfo.workingHours },
                                    tiktokUrl = cloudConfig.tiktokUrl.ifBlank { state.brandInfo.tiktokUrl },
                                    facebookPageUrl = cloudConfig.facebookPageUrl.ifBlank { state.brandInfo.facebookPageUrl },
                                    instagramUrl = cloudConfig.instagramUrl.ifBlank { state.brandInfo.instagramUrl },
                                    googleMapsUrl = cloudConfig.googleMapsUrl.ifBlank { state.brandInfo.googleMapsUrl }
                                ),
                                packages = updatedPackages
                            )
                        }
                    }
                }
        }

        val notifJob = viewModelScope.launch {
            cloudRepository.observeNotifications(cmsState.value.activeSubscriptionCode)
                .catch { e -> Log.e("GymViewModel", "observeNotifications error", e) }
                .collect { remoteNotifications ->
                    if (remoteNotifications.isNotEmpty()) {
                        repository.updateState { state ->
                            val existingIds = remoteNotifications.map { it.id }.toSet()
                            val merged = remoteNotifications + state.notifications.filterNot { it.id in existingIds }
                            state.copy(notifications = merged)
                        }
                    }
                }
        }

        if (Firebase.auth.currentUser == null) {
            syncJobs = listOf(configJob, notifJob)
            return
        }

        val bookingsJob = viewModelScope.launch {
            cloudRepository.observeMyBookings()
                .catch { e -> Log.e("GymViewModel", "observeMyBookings error", e) }
                .collect { cloudBookings ->
                    repository.updateState { state ->
                        state.copy(bookings = cloudBookings)
                    }
                }
        }

        val commentsJob = viewModelScope.launch {
            cloudRepository.observeStoryComments()
                .catch { e -> Log.e("GymViewModel", "observeStoryComments error", e) }
                .collect { cloudCommentsByStory ->
                    if (cloudCommentsByStory.isNotEmpty()) {
                        repository.updateState { state ->
                            val updatedStories = state.stories.map { story ->
                                val remoteList = cloudCommentsByStory[story.id].orEmpty()
                                val existingIds = remoteList.map { it.id }.toSet()
                                val merged = remoteList + story.comments.filterNot { it.id in existingIds }
                                story.copy(comments = merged)
                            }
                            state.copy(stories = updatedStories)
                        }
                    }
                }
        }

        syncJobs = listOf(bookingsJob, configJob, notifJob, commentsJob)
    }

    fun stopCloudSync() {
        syncJobs.forEach { it.cancel() }
        syncJobs = emptyList()
    }

    fun selectTab(tab: MainTab) {
        _currentTab.value = tab
    }

    fun openStoryAtIndex(index: Int) {
        _selectedStoryIndex.value = index
        markStoryViewed(index)
        _currentTab.value = MainTab.STORIES
    }

    fun onStoryPageChanged(index: Int) {
        _selectedStoryIndex.value = index
        markStoryViewed(index)
    }

    private fun markStoryViewed(index: Int) {
        repository.updateState { state ->
            val updatedStories = state.stories.mapIndexed { idx, s ->
                if (idx == index) s.copy(isViewed = true) else s
            }
            state.copy(stories = updatedStories)
        }
    }

    fun toggleAudioMute() {
        _isAudioMuted.value = !_isAudioMuted.value
    }

    fun toggleFollowGym() {
        repository.updateState { state ->
            state.copy(isFollowingGym = !state.isFollowingGym)
        }
    }

    fun toggleStoryLike(storyId: String) {
        repository.updateState { state ->
            val updated = state.stories.map { story ->
                if (story.id == storyId) {
                    val nextLiked = !story.isLiked
                    val nextCount = if (nextLiked) story.likesCount + 1 else (story.likesCount - 1).coerceAtLeast(0)
                    story.copy(isLiked = nextLiked, likesCount = nextCount)
                } else story
            }
            state.copy(stories = updated)
        }
    }

    fun likeStoryOnDoubleTap(storyId: String) {
        repository.updateState { state ->
            val updated = state.stories.map { story ->
                if (story.id == storyId) {
                    val nextCount = if (!story.isLiked) story.likesCount + 1 else story.likesCount + 1
                    story.copy(isLiked = true, likesCount = nextCount)
                } else story
            }
            state.copy(stories = updated)
        }
    }

    fun addStoryComment(storyId: String, authorName: String, commentText: String) {
        val defaultName = Firebase.auth.currentUser?.displayName ?: "بطل كابتن هيما جيم 💪"
        val cleanAuthor = authorName.trim().ifEmpty { defaultName }
        val cleanText = commentText.trim()
        if (cleanText.isEmpty()) return

        val commentId = "c_${System.currentTimeMillis()}"
        val newComment = StoryComment(
            id = commentId,
            authorName = cleanAuthor,
            text = cleanText,
            timestamp = "الآن"
        )

        repository.updateState { state ->
            val updated = state.stories.map { story ->
                if (story.id == storyId) {
                    story.copy(comments = listOf(newComment) + story.comments)
                } else story
            }
            state.copy(stories = updated)
        }

        if (Firebase.auth.currentUser != null) {
            viewModelScope.launch {
                runCatching {
                    cloudRepository.addStoryComment(
                        commentId = commentId,
                        storyId = storyId,
                        authorName = cleanAuthor,
                        text = cleanText
                    )
                }.onFailure { e ->
                    Log.e("GymViewModel", "Failed to sync story comment to Firestore", e)
                }
            }
        }
    }

    fun incrementStoryShare(storyId: String) {
        repository.updateState { state ->
            val updated = state.stories.map { story ->
                if (story.id == storyId) {
                    story.copy(sharesCount = story.sharesCount + 1)
                } else story
            }
            state.copy(stories = updated)
        }
    }

    fun setClassGenderFilter(filter: ClassGenderFilter) {
        _classFilter.value = filter
    }

    fun setGalleryCategoryFilter(category: GalleryCategory) {
        _galleryFilter.value = category
    }

    fun openBookingModal(
        bookingType: String = "اشتراك باقة",
        selectedItemName: String = "باقة 3 شهور - 1,250 ج.م (الأكثر طلباً)",
        genderCategory: String = "قسم الرجال"
    ) {
        _bookingModalState.value = BookingModalUiState(
            isOpen = true,
            genderCategory = genderCategory,
            bookingType = bookingType,
            selectedItemName = selectedItemName,
            confirmedRecord = null,
            errorMessage = null
        )
    }

    fun closeBookingModal() {
        _bookingModalState.value = _bookingModalState.value.copy(
            isOpen = false,
            confirmedRecord = null,
            errorMessage = null
        )
    }

    private fun generateUniqueSubscriptionCode(existingCodes: Set<String>): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        repeat(20) {
            val randomPart = (1..5).map { chars[Random.nextInt(chars.length)] }.joinToString("")
            val candidate = "KH$randomPart"
            if (candidate !in existingCodes) {
                return candidate
            }
        }
        return "KH${System.currentTimeMillis().toString().takeLast(5)}"
    }

    fun submitBooking(
        fullName: String,
        phone: String,
        genderCategory: String,
        bookingType: String,
        selectedItemName: String,
        preferredDateTime: String,
        notes: String,
        onSubmitted: (BookingRecord) -> Unit = {}
    ) {
        val state = cmsState.value
        val existingUsedCodes = (state.subscriptions.map { it.code.uppercase() } +
            state.bookings.map { it.referenceCode.uppercase() }).toSet()

        val refCode = generateUniqueSubscriptionCode(existingUsedCodes)

        val orderNumber = "ORD-${System.currentTimeMillis().toString().takeLast(6)}"
        val nowUtcMillis = System.currentTimeMillis()
        val cairoFormat = SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale("ar", "EG")).apply {
            timeZone = TimeZone.getTimeZone("Africa/Cairo")
        }
        val bookingId = "bk_$nowUtcMillis"
        val cleanName = fullName.trim().ifEmpty {
            Firebase.auth.currentUser?.displayName ?: "مشترك جديد"
        }
        val cleanPhone = phone.trim().ifEmpty { "01039157200" }
        val cleanDate = preferredDateTime.trim().ifEmpty { "اليوم - في أقرب موعد" }
        val cleanNotes = notes.trim()

        val matchedPkg = state.packages.firstOrNull { pkg ->
            selectedItemName.contains(pkg.title)
        } ?: state.packages.getOrElse(1) { state.packages.first() }
        val priceEgp = if (bookingType == "اشتراك باقة") matchedPkg.discountedPriceEgp else 150

        val record = BookingRecord(
            id = bookingId,
            orderNumber = orderNumber,
            referenceCode = refCode,
            fullName = cleanName,
            phone = cleanPhone,
            genderCategory = genderCategory,
            bookingType = bookingType,
            selectedItemName = selectedItemName,
            priceEgp = priceEgp,
            preferredDateTime = cleanDate,
            notes = cleanNotes,
            status = "PENDING",
            createdAt = cairoFormat.format(Date(nowUtcMillis)),
            createdAtUtcMillis = nowUtcMillis
        )

        val generatedSub = createSubscriptionFromBooking(record, state.packages)

        // STEP 1: Save order & PENDING subscription to local & cloud database BEFORE opening WhatsApp
        val pendingNotification = GymNotificationItem(
            id = "notif_order_$nowUtcMillis",
            title = "تم تسجيل طلب اشتراكك (${record.orderNumber})",
            message = "تم تسجيل طلبك بنجاح بكود #$refCode، اشتراكك في انتظار تأكيد الإدارة.",
            type = "SUBSCRIPTION",
            targetCode = refCode,
            createdAtUtcMillis = nowUtcMillis,
            isRead = false
        )

        repository.updateState { current ->
            current.copy(
                bookings = listOf(record) + current.bookings,
                subscriptions = listOf(generatedSub) + current.subscriptions,
                notifications = listOf(pendingNotification) + current.notifications
            )
        }

        viewModelScope.launch {
            runCatching {
                SupabaseGymClient.submitPendingSubscriptionAndBooking(generatedSub, record)
            }
            runCatching {
                cloudRepository.submitPendingSubscriptionOrder(generatedSub)
            }.onFailure { e ->
                Log.e("GymViewModel", "Failed to save pending subscription to Firestore", e)
            }

            if (Firebase.auth.currentUser != null) {
                runCatching {
                    cloudRepository.createBooking(
                        bookingId = bookingId,
                        referenceCode = refCode,
                        fullName = cleanName,
                        phone = cleanPhone,
                        genderCategory = genderCategory,
                        bookingType = bookingType,
                        selectedItemName = selectedItemName,
                        preferredDateTime = cleanDate,
                        notes = cleanNotes
                    )
                }.onFailure { e ->
                    Log.e("GymViewModel", "Failed to sync booking to Firestore", e)
                }
            }
        }

        _bookingModalState.value = _bookingModalState.value.copy(
            confirmedRecord = record,
            errorMessage = null
        )
        onSubmitted(record)
    }

    private fun createSubscriptionFromBooking(
        record: BookingRecord,
        packages: List<MembershipPackage>
    ): MemberSubscription {
        val matchedPkg = packages.firstOrNull { pkg ->
            record.selectedItemName.contains(pkg.title)
        } ?: packages.getOrElse(1) { packages.first() }

        val durationMonths = matchedPkg.durationMonths
        val totalDays = durationMonths * 30
        val nowUtc = record.createdAtUtcMillis.takeIf { it > 0L } ?: System.currentTimeMillis()
        val expiresUtc = nowUtc + (totalDays * 86_400_000L)

        val dayFormat = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).apply {
            timeZone = TimeZone.getTimeZone("Africa/Cairo")
        }
        val startDate = dayFormat.format(Date(nowUtc))
        val endDate = dayFormat.format(Date(expiresUtc))

        return MemberSubscription(
            code = record.referenceCode.uppercase(),
            orderNumber = record.orderNumber,
            fullName = record.fullName,
            phone = record.phone,
            genderCategory = record.genderCategory,
            packageId = matchedPkg.id,
            packageTitle = record.selectedItemName,
            pricePaidEgp = record.priceEgp,
            durationMonths = durationMonths,
            totalDays = totalDays,
            remainingDays = totalDays,
            startDate = startDate,
            endDate = endDate,
            statusCode = "PENDING",
            statusAr = "في انتظار تأكيد الإدارة ⏳",
            createdAtUtcMillis = nowUtc,
            activatedAtUtcMillis = 0L,
            expiresAtUtcMillis = expiresUtc,
            freezeDaysAvailable = durationMonths * 4,
            freeInvitationsLeft = durationMonths.coerceAtLeast(1),
            trainerNotes = record.notes.ifBlank { "متابعة شاملة مع كباتن الجيم + جدول تمرين وتغذية" },
            perks = matchedPkg.perks
        )
    }

    fun buildWhatsAppBookingUrl(record: BookingRecord): String {
        val whatsappIntl = cmsState.value.brandInfo.whatsappIntl
        val message = buildString {
            appendLine("🔥 *طلب اشتراك وحجز جديد - CAPTAIN HIMA FITNESS GYM* 🔥")
            appendLine("━━━━━━━━━━━━━━━━━━")
            appendLine("🧾 *رقم الطلب:* ${record.orderNumber}")
            appendLine("👤 *اسم العميل:* ${record.fullName}")
            appendLine("📱 *رقم الهاتف:* ${record.phone}")
            appendLine("🔑 *كود الاشتراك:* ${record.referenceCode}")
            appendLine("🏆 *الباقة المختارة:* ${record.selectedItemName}")
            appendLine("💰 *السعر:* ${record.priceEgp} ج.م")
            appendLine("🕒 *وقت الحجز:* ${record.createdAt}")
            appendLine("🏋️ *القسم:* ${record.genderCategory}")
            if (record.notes.isNotBlank()) {
                appendLine("📝 *ملاحظات:* ${record.notes}")
            }
            appendLine("━━━━━━━━━━━━━━━━━━")
            append("📍 ${cmsState.value.brandInfo.addressAr}")
        }
        return "https://wa.me/$whatsappIntl?text=${Uri.encode(message)}"
    }
}
