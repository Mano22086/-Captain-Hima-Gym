package com.example.model

import androidx.annotation.DrawableRes
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.ceil

enum class MainTab(val titleAr: String, val testTag: String, val showInBottomBar: Boolean = true) {
    HOME("الرئيسية", "tab_home", true),
    STORIES("القصص", "tab_stories", true),
    PACKAGES("الاشتراكات", "tab_packages", true),
    SUBSCRIPTION("بطاقة VIP", "tab_subscription", true),
    GALLERY("المعرض", "tab_gallery", true),
    BOOK("احجز", "tab_book", true),
    ACCOUNT("حسابي", "tab_account", false),
    NOTIFICATIONS("الإشعارات", "tab_notifications", false)
}

enum class SubscriptionStatus(val code: String, val labelAr: String) {
    PENDING("PENDING", "في انتظار تأكيد الإدارة ⏳"),
    ACTIVE("ACTIVE", "نشط ومفعل ✅"),
    FROZEN("FROZEN", "مجمد مؤقتاً ❄️"),
    EXPIRED("EXPIRED", "منتهي الصلاحية ⚠️"),
    REJECTED("REJECTED", "تم رفض الطلب ❌"),
    CANCELLED("CANCELLED", "عضوية ملغاة 🚫");

    companion object {
        fun fromCode(raw: String?): SubscriptionStatus {
            return entries.firstOrNull { it.code.equals(raw, ignoreCase = true) } ?: PENDING
        }
    }
}

enum class ClassGenderFilter(val labelAr: String) {
    ALL("الكل"),
    MEN("قسم الرجال 💪"),
    LADIES("قسم السيدات 💃")
}

enum class GalleryCategory(val labelAr: String) {
    ALL("الكل"),
    WEIGHTS("صالة الحديد Cybex"),
    SPA("السبا والجاكوزي"),
    CLASSES("الحصص الجماعية"),
    OFFERS("بوسترات العروض")
}

data class GymBrandInfo(
    val nameAr: String = "كابتن هيما جيم",
    val nameEn: String = "CAPTAIN HIMA FITNESS GYM",
    val taglineAr: String = "أقوى جيم في المنشية",
    val taglineEn: String = "BUILD YOUR BEST VERSION",
    val officialLogoUrl: String = "https://lh3.googleusercontent.com/gps-cs-s/ANWiy9TxE18nVjffUHGRDfNnpljKI30Ao2_jZCmTHnE8F-2aQ32PUjkcWpe_w54-P-9upFYS1KRdJNNrrf51b0qReHirgDlzbfAl-Pse_t3jVwHVAxMcCvupSJo2qoPSbH7jsd5kVh3sm80431L_",
    val facebookPageUrl: String = "https://www.facebook.com/CaptainHimaGym",
    val facebookCoverPhotoUrl: String = "https://www.facebook.com/photo?fbid=122124538407384387&set=pb.61591531637010.-2207520000",
    val facebookProfilePhotoUrl: String = "https://www.facebook.com/photo?fbid=122124538263384387&set=pb.61591531637010.-2207520000",
    val offersPosterUrl: String = "https://www.facebook.com/photo/?fbid=122148567543384387&set=pb.61591531637010.-2207520000",
    val classesSchedulePosterUrl: String = "https://www.facebook.com/photo/?fbid=122148460221384387&set=pb.61591531637010.-2207520000",
    val instagramUrl: String = "https://www.instagram.com/captain_hima_gym",
    val tiktokUrl: String = "https://www.tiktok.com/@captain_hima_gym",
    val googleMapsUrl: String = "https://www.google.com/maps/place/CAPTAIN+HIMA+GYM/@30.0103345,31.1520416,17z/data=!3m1!4b1!4m6!3m5!1s0x145845d9c1f49dbb:0x5df219b46c0b3411!8m2!3d30.0103345!4d31.1520416!16s%2Fg%2F11nvgwdwkx",
    val addressAr: String = "المنشية سيتي، الدور الثاني، شارع المنشية متفرع من شارع الملك فيصل، أعلى كشري المدينة - بجوار توكيل التوكيلات التعليمي، المنشية الطوابق، محافظة الجيزة 12814",
    val plusCode: String = "2562+4R الهرم، مصر",
    val phoneDisplay: String = "01039157200",
    val whatsappIntl: String = "201039157200",
    val workingHours: String = "مفتوح 24 ساعة يومياً (7 أيام في الأسبوع) + فترات مخصصة للسيدات فقط بخصوصية تامة",
    val ratingScore: String = "5.0"
)

data class StoryComment(
    val id: String,
    val authorName: String,
    val text: String,
    val timestamp: String
)

data class GymStory(
    val id: String,
    val title: String,
    val subtitle: String,
    val badgeText: String,
    val categoryTag: String,
    val programToBook: String,
    val bookingTypePreset: String,
    val genderPreset: String,
    @param:DrawableRes val drawableRes: Int,
    val videoUrl: String? = null,
    val likesCount: Int,
    val isLiked: Boolean,
    val sharesCount: Int,
    val comments: List<StoryComment>,
    val isViewed: Boolean = false,
    val audioTrackTitle: String
)

data class FacilityDepartment(
    val id: String,
    val title: String,
    val subtitle: String,
    val description: String,
    val features: List<String>,
    @param:DrawableRes val drawableRes: Int,
    val badge: String,
    val defaultBookingProgram: String
)

data class MembershipPackage(
    val id: String,
    val title: String,
    val subtitle: String,
    val durationMonths: Int,
    val discountedPriceEgp: Int,
    val originalPriceEgp: Int,
    val discountPercent: Int = 50,
    val badgeText: String,
    val isPopular: Boolean = false,
    val isVip: Boolean = false,
    val perks: List<String>
)

data class GroupClassItem(
    val id: String,
    val nameEn: String,
    val nameAr: String,
    val category: ClassGenderFilter,
    val daysAr: String,
    val timeSlotAr: String,
    val trainerName: String,
    val caloriesBurn: String,
    val intensityAr: String,
    @param:DrawableRes val drawableRes: Int
)

data class GalleryMediaItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val category: GalleryCategory,
    val description: String,
    @param:DrawableRes val drawableRes: Int,
    val imageUrl: String? = null,
    val externalReferenceUrl: String? = null,
    val badgeText: String
)

data class GymReview(
    val id: String,
    val reviewerName: String,
    val rating: Int = 5,
    val roleBadge: String,
    val dateText: String,
    val commentText: String
)

data class BookingRecord(
    val id: String,
    val orderNumber: String = "",
    val referenceCode: String,
    val fullName: String,
    val phone: String,
    val genderCategory: String,
    val bookingType: String,
    val selectedItemName: String,
    val priceEgp: Int = 1250,
    val preferredDateTime: String,
    val notes: String,
    val status: String = "PENDING",
    val createdAt: String,
    val createdAtUtcMillis: Long = System.currentTimeMillis()
)

data class SubscriptionCodeRecord(
    val code: String,
    val isUsed: Boolean = false,
    val packageId: String = "pkg_3m",
    val packageTitle: String = "باقة 3 شهور",
    val durationMonths: Int = 3,
    val priceEgp: Int = 1250,
    val createdAtUtcMillis: Long = System.currentTimeMillis(),
    val assignedMemberName: String = "",
    val assignedMemberPhone: String = "",
    val orderNumber: String = ""
)

data class MemberSubscription(
    val code: String,
    val orderNumber: String = "",
    val fullName: String,
    val phone: String,
    val genderCategory: String,
    val packageId: String,
    val packageTitle: String,
    val pricePaidEgp: Int,
    val durationMonths: Int,
    val totalDays: Int,
    val remainingDays: Int,
    val startDate: String,
    val endDate: String,
    val statusCode: String = "PENDING", // PENDING, ACTIVE, FROZEN, EXPIRED, REJECTED, CANCELLED
    val statusAr: String = "في انتظار تأكيد الإدارة ⏳",
    val createdAtUtcMillis: Long = System.currentTimeMillis(),
    val activatedAtUtcMillis: Long? = null,
    val expiresAtUtcMillis: Long? = null,
    val frozenAtUtcMillis: Long? = null,
    val accumulatedFreezeMillis: Long = 0L,
    val freezeDaysAvailable: Int = 14,
    val freeInvitationsLeft: Int = 3,
    val trainerNotes: String = "متابعة شاملة لجدول الحديد Cybex + الكارديو + السبا والجاكوزي",
    val perks: List<String> = emptyList()
) {
    companion object {
        private const val MILLIS_PER_DAY = 86_400_000.0

        fun formatCairoDate(utcMillis: Long?): String {
            if (utcMillis == null || utcMillis <= 0L) return "غير مفعل بعد"
            return try {
                val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
                sdf.timeZone = TimeZone.getTimeZone("Africa/Cairo")
                sdf.format(Date(utcMillis))
            } catch (_: Exception) {
                "—"
            }
        }

        fun formatCairoDateTime(utcMillis: Long): String {
            return try {
                val sdf = SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.forLanguageTag("ar"))
                sdf.timeZone = TimeZone.getTimeZone("Africa/Cairo")
                sdf.format(Date(utcMillis))
            } catch (_: Exception) {
                "الآن"
            }
        }
    }

    fun computeEffectiveStatus(nowUtcMillis: Long = System.currentTimeMillis()): SubscriptionStatus {
        val raw = SubscriptionStatus.fromCode(statusCode)
        if (raw == SubscriptionStatus.ACTIVE && expiresAtUtcMillis != null && nowUtcMillis >= expiresAtUtcMillis) {
            return SubscriptionStatus.EXPIRED
        }
        return raw
    }

    fun computeRealTimeRemainingDays(nowUtcMillis: Long = System.currentTimeMillis()): Int {
        val effectiveStatus = computeEffectiveStatus(nowUtcMillis)
        return when (effectiveStatus) {
            SubscriptionStatus.PENDING -> totalDays
            SubscriptionStatus.REJECTED,
            SubscriptionStatus.CANCELLED,
            SubscriptionStatus.EXPIRED -> 0
            SubscriptionStatus.FROZEN -> {
                val exp = expiresAtUtcMillis
                val frz = frozenAtUtcMillis
                if (exp != null && frz != null) {
                    val diff = (exp - frz).coerceAtLeast(0L)
                    ceil(diff / MILLIS_PER_DAY).toInt().coerceIn(0, totalDays.coerceAtLeast(1))
                } else {
                    remainingDays.coerceAtLeast(0)
                }
            }
            SubscriptionStatus.ACTIVE -> {
                val exp = expiresAtUtcMillis
                if (exp != null) {
                    val diff = (exp - nowUtcMillis).coerceAtLeast(0L)
                    ceil(diff / MILLIS_PER_DAY).toInt()
                } else {
                    remainingDays.coerceAtLeast(0)
                }
            }
        }
    }

    fun displayStartDate(): String {
        return if (activatedAtUtcMillis != null && activatedAtUtcMillis > 0L) {
            formatCairoDate(activatedAtUtcMillis)
        } else {
            startDate.ifBlank { "يبدأ فور تأكيد الإدارة" }
        }
    }

    fun displayEndDate(): String {
        return if (expiresAtUtcMillis != null && expiresAtUtcMillis > 0L) {
            formatCairoDate(expiresAtUtcMillis)
        } else {
            endDate.ifBlank { "يُحدد فور التفعيل" }
        }
    }
}

data class GymNotificationItem(
    val id: String,
    val title: String,
    val message: String,
    val type: String = "SUBSCRIPTION", // SUBSCRIPTION, OFFER, ANNOUNCEMENT
    val targetCode: String = "ALL",
    val createdAtUtcMillis: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)

data class UserSettingsState(
    val notificationsEnabled: Boolean = true,
    val isDarkMode: Boolean = true
)

data class CaptainHimaCmsState(
    val brandInfo: GymBrandInfo,
    val stories: List<GymStory>,
    val facilities: List<FacilityDepartment>,
    val packages: List<MembershipPackage>,
    val groupClasses: List<GroupClassItem>,
    val galleryItems: List<GalleryMediaItem>,
    val reviews: List<GymReview>,
    val bookings: List<BookingRecord>,
    val subscriptions: List<MemberSubscription> = emptyList(),
    val subscriptionCodes: List<SubscriptionCodeRecord> = emptyList(),
    val notifications: List<GymNotificationItem> = emptyList(),
    val userSettings: UserSettingsState = UserSettingsState(),
    val activeSubscriptionCode: String? = null,
    val isFollowingGym: Boolean = false
)
