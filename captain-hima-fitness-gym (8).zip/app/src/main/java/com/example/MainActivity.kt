package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.MainTab
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.viewmodel.GymViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val gymViewModel: GymViewModel = viewModel()
            val userSettings by gymViewModel.userSettings.collectAsStateWithLifecycle()
            MyApplicationTheme(isDarkMode = userSettings.isDarkMode) {
                val isSplashVisible by gymViewModel.isSplashVisible.collectAsStateWithLifecycle()
                val hasEnteredApp by gymViewModel.hasEnteredApp.collectAsStateWithLifecycle()
                val cmsState by gymViewModel.cmsState.collectAsStateWithLifecycle()

                LaunchedEffect(Unit) {
                    gymViewModel.startCloudSync()
                }

                Crossfade(
                    targetState = Triple(isSplashVisible, hasEnteredApp, cmsState.brandInfo),
                    animationSpec = tween(500),
                    label = "root_screen_transition"
                ) { (showSplash, entered, brandInfo) ->
                    when {
                        showSplash -> {
                            SplashScreen(
                                onSplashFinished = {
                                    gymViewModel.completeSplash()
                                }
                            )
                        }
                        !entered -> {
                            AuthScreen(
                                brandInfo = brandInfo,
                                onEnterWithCode = { code ->
                                    gymViewModel.verifyAndActivateSubscriptionCode(
                                        rawCode = code,
                                        navigateToSubscriptionTab = true
                                    )
                                },
                                onEnterAsNewMember = {
                                    gymViewModel.enterAsNewMember()
                                }
                            )
                        }
                        else -> {
                            CaptainHimaGymApp(viewModel = gymViewModel)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CaptainHimaGymApp(
    viewModel: GymViewModel = viewModel()
) {
    val context = LocalContext.current
    val cmsState by viewModel.cmsState.collectAsStateWithLifecycle()
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val selectedStoryIndex by viewModel.selectedStoryIndex.collectAsStateWithLifecycle()
    val isAudioMuted by viewModel.isAudioMuted.collectAsStateWithLifecycle()
    val classFilter by viewModel.classFilter.collectAsStateWithLifecycle()
    val galleryFilter by viewModel.galleryFilter.collectAsStateWithLifecycle()
    val bookingModalState by viewModel.bookingModalState.collectAsStateWithLifecycle()
    val isCodeEntryModalOpen by viewModel.isCodeEntryModalOpen.collectAsStateWithLifecycle()
    val userSettings by viewModel.userSettings.collectAsStateWithLifecycle()

    val unreadNotificationsCount = remember(cmsState.notifications) {
        cmsState.notifications.count { !it.isRead }
    }

    LaunchedEffect(Unit) {
        viewModel.startCloudSync()
    }

    BackHandler(enabled = currentTab != MainTab.HOME) {
        viewModel.selectTab(MainTab.HOME)
    }

    LuxuryGymAmbientBackground {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = Color.Transparent,
            topBar = {
                StickyGymTopHeader(
                    brandInfo = cmsState.brandInfo,
                    activeSubscriptionCode = cmsState.activeSubscriptionCode,
                    unreadNotificationsCount = unreadNotificationsCount,
                    onSubscriptionCodeClick = {
                        if (cmsState.activeSubscriptionCode != null) {
                            viewModel.selectTab(MainTab.SUBSCRIPTION)
                        } else {
                            viewModel.openCodeEntryModal()
                        }
                    },
                    onNotificationsClick = {
                        viewModel.selectTab(MainTab.NOTIFICATIONS)
                    },
                    onAccountClick = {
                        viewModel.selectTab(MainTab.ACCOUNT)
                    },
                    onBookNowClick = {
                        viewModel.openBookingModal(
                            bookingType = "اشتراك باقة",
                            selectedItemName = "باقة 3 شهور - 1,250 ج.م بدلاً من 2,500 ج.م",
                            genderCategory = "قسم الرجال"
                        )
                    }
                )
            },
            bottomBar = {
                CaptainHimaFloatingBottomDock(
                    currentTab = currentTab,
                    hasActiveSubscription = !cmsState.activeSubscriptionCode.isNullOrBlank(),
                    onSelectTab = { viewModel.selectTab(it) }
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentTab) {
                    MainTab.HOME -> {
                        HomeScreen(
                            cmsState = cmsState,
                            onStoryClick = { storyIdx -> viewModel.openStoryAtIndex(storyIdx) },
                            onOpenBooking = { type, item, gender ->
                                viewModel.openBookingModal(
                                    bookingType = type,
                                    selectedItemName = item,
                                    genderCategory = gender
                                )
                            },
                            onNavigateToTab = { tab -> viewModel.selectTab(tab) }
                        )
                    }

                    MainTab.STORIES -> {
                        StoriesFeedScreen(
                            cmsState = cmsState,
                            initialStoryIndex = selectedStoryIndex,
                            isAudioMuted = isAudioMuted,
                            onStoryPageChanged = { idx -> viewModel.onStoryPageChanged(idx) },
                            onToggleAudioMute = { viewModel.toggleAudioMute() },
                            onToggleFollowGym = { viewModel.toggleFollowGym() },
                            onToggleLike = { storyId -> viewModel.toggleStoryLike(storyId) },
                            onDoubleTapLike = { storyId -> viewModel.likeStoryOnDoubleTap(storyId) },
                            onAddComment = { storyId, author, text ->
                                viewModel.addStoryComment(storyId, author, text)
                            },
                            onShareStory = { storyId -> viewModel.incrementStoryShare(storyId) },
                            onBookStoryWorkout = { story ->
                                viewModel.openBookingModal(
                                    bookingType = story.bookingTypePreset,
                                    selectedItemName = story.programToBook,
                                    genderCategory = story.genderPreset
                                )
                            }
                        )
                    }

                    MainTab.PACKAGES -> {
                        PackagesAndClassesScreen(
                            cmsState = cmsState,
                            selectedClassFilter = classFilter,
                            onSelectClassFilter = { viewModel.setClassGenderFilter(it) },
                            onOpenBooking = { type, item, gender ->
                                viewModel.openBookingModal(
                                    bookingType = type,
                                    selectedItemName = item,
                                    genderCategory = gender
                                )
                            }
                        )
                    }

                    MainTab.SUBSCRIPTION -> {
                        SubscriptionTrackerScreen(
                            cmsState = cmsState,
                            onActivateCode = { code ->
                                viewModel.verifyAndActivateSubscriptionCode(
                                    rawCode = code,
                                    navigateToSubscriptionTab = true
                                )
                            },
                            onClearActiveCode = {
                                viewModel.clearActiveSubscriptionCode()
                            },
                            onRenewSubscription = { code, pkg ->
                                viewModel.renewOrUpgradeSubscription(code, pkg)
                            },
                            onConfirmRenewalViaWhatsApp = { sub, pkg ->
                                val url = viewModel.buildWhatsAppRenewalUrl(sub, pkg)
                                launchExternalUrl(context, url)
                            },
                            onOpenNewBooking = { type, item, gender ->
                                viewModel.openBookingModal(
                                    bookingType = type,
                                    selectedItemName = item,
                                    genderCategory = gender
                                )
                            }
                        )
                    }

                    MainTab.GALLERY -> {
                        GalleryScreen(
                            cmsState = cmsState,
                            selectedCategory = galleryFilter,
                            onSelectCategory = { viewModel.setGalleryCategoryFilter(it) },
                            onOpenBooking = { type, item, gender ->
                                viewModel.openBookingModal(
                                    bookingType = type,
                                    selectedItemName = item,
                                    genderCategory = gender
                                )
                            }
                        )
                    }

                    MainTab.BOOK -> {
                        BookAndContactScreen(
                            cmsState = cmsState,
                            onSubmitDirectBooking = { fullName, phone, gender, type, item, dateTime, notes, onDone ->
                                viewModel.submitBooking(
                                    fullName = fullName,
                                    phone = phone,
                                    genderCategory = gender,
                                    bookingType = type,
                                    selectedItemName = item,
                                    preferredDateTime = dateTime,
                                    notes = notes,
                                    onSubmitted = onDone
                                )
                            },
                            onConfirmViaWhatsApp = { record ->
                                val url = viewModel.buildWhatsAppBookingUrl(record)
                                launchExternalUrl(context, url)
                            },
                            onActivateBookedCode = { bookedCode ->
                                viewModel.verifyAndActivateSubscriptionCode(
                                    rawCode = bookedCode,
                                    navigateToSubscriptionTab = true
                                )
                            }
                        )
                    }

                    MainTab.ACCOUNT -> {
                        AccountAndSettingsScreen(
                            cmsState = cmsState,
                            userSettings = userSettings,
                            onUpdateSettings = { viewModel.updateUserSettings(it) },
                            onNavigateToTab = { viewModel.selectTab(it) },
                            onOpenCodeDialog = { viewModel.openCodeEntryModal() },
                            onLogoutSubscription = {
                                viewModel.clearActiveSubscriptionCode()
                                viewModel.returnToWelcomePortal()
                            }
                        )
                    }

                    MainTab.NOTIFICATIONS -> {
                        NotificationsScreen(
                            cmsState = cmsState,
                            onMarkAllRead = { viewModel.markAllNotificationsRead() },
                            onNotificationClick = { item ->
                                viewModel.markNotificationRead(item.id)
                                if (item.type == "ACTIVATED" || item.type == "PROMO") {
                                    viewModel.selectTab(MainTab.SUBSCRIPTION)
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    InteractiveBookingModal(
        modalState = bookingModalState,
        packages = cmsState.packages,
        classes = cmsState.groupClasses,
        onDismiss = { viewModel.closeBookingModal() },
        onSubmitBooking = { fullName, phone, gender, type, item, dateTime, notes ->
            viewModel.submitBooking(
                fullName = fullName,
                phone = phone,
                genderCategory = gender,
                bookingType = type,
                selectedItemName = item,
                preferredDateTime = dateTime,
                notes = notes,
                onSubmitted = { record ->
                    // Step 2: Open WhatsApp after saving order to database
                    val url = viewModel.buildWhatsAppBookingUrl(record)
                    launchExternalUrl(context, url)
                }
            )
        },
        onConfirmViaWhatsApp = { record ->
            val url = viewModel.buildWhatsAppBookingUrl(record)
            launchExternalUrl(context, url)
        },
        onActivateBookedCode = { bookedCode ->
            viewModel.closeBookingModal()
            viewModel.verifyAndActivateSubscriptionCode(
                rawCode = bookedCode,
                navigateToSubscriptionTab = true
            )
        }
    )

    SubscriptionCodeEntryDialog(
        isOpen = isCodeEntryModalOpen,
        onDismiss = { viewModel.closeCodeEntryModal() },
        onVerifyCode = { code ->
            viewModel.verifyAndActivateSubscriptionCode(
                rawCode = code,
                navigateToSubscriptionTab = true
            )
        }
    )
}

@Composable
private fun CaptainHimaFloatingBottomDock(
    currentTab: MainTab,
    hasActiveSubscription: Boolean,
    onSelectTab: (MainTab) -> Unit
) {
    val dockTabs = remember {
        listOf(
            MainTab.HOME,
            MainTab.STORIES,
            MainTab.PACKAGES,
            MainTab.SUBSCRIPTION,
            MainTab.GALLERY,
            MainTab.BOOK,
            MainTab.ACCOUNT
        )
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 8.dp, vertical = 8.dp)
    ) {
        Surface(
            color = CardSurfaceDark.copy(alpha = 0.95f),
            tonalElevation = 16.dp,
            shadowElevation = 20.dp,
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    width = 1.2.dp,
                    brush = Glass3DHighlightBrush,
                    shape = RoundedCornerShape(28.dp)
                )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Glass3DSurfaceBrush)
                    .padding(horizontal = 4.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                dockTabs.forEach { tab ->
                    val selected = currentTab == tab
                    val pillPadding by animateDpAsState(
                        targetValue = if (selected) 8.dp else 4.dp,
                        animationSpec = spring(dampingRatio = 0.65f),
                        label = "dock_padding"
                    )
                    val iconTint by animateColorAsState(
                        targetValue = when {
                            selected -> CrispWhite
                            tab == MainTab.SUBSCRIPTION && hasActiveSubscription -> EmeraldSuccess
                            tab == MainTab.SUBSCRIPTION -> FieryOrange
                            else -> MutedZinc
                        },
                        label = "dock_tint"
                    )

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(20.dp))
                            .clickable { onSelectTab(tab) }
                            .padding(vertical = 4.dp)
                            .testTag(tab.testTag)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .then(
                                    if (selected) {
                                        Modifier.background(
                                            brush = Brush.horizontalGradient(
                                                listOf(FieryOrange, WarmGold)
                                            ),
                                            shape = RoundedCornerShape(50)
                                        )
                                    } else {
                                        Modifier.background(Color.Transparent)
                                    }
                                )
                                .padding(horizontal = pillPadding, vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = getTabIcon(tab, selected),
                                contentDescription = tab.titleAr,
                                tint = iconTint,
                                modifier = Modifier.size(19.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(3.dp))

                        Text(
                            text = tab.titleAr,
                            style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.5.sp),
                            fontWeight = if (selected || tab == MainTab.SUBSCRIPTION) FontWeight.ExtraBold else FontWeight.Medium,
                            color = when {
                                selected -> FieryOrange
                                tab == MainTab.SUBSCRIPTION && hasActiveSubscription -> EmeraldSuccess
                                tab == MainTab.SUBSCRIPTION -> FieryOrange
                                else -> MutedZinc
                            },
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

private fun getTabIcon(tab: MainTab, selected: Boolean): ImageVector {
    return when (tab) {
        MainTab.HOME -> if (selected) Icons.Filled.Home else Icons.Outlined.Home
        MainTab.STORIES -> if (selected) Icons.Filled.SlowMotionVideo else Icons.Outlined.SlowMotionVideo
        MainTab.PACKAGES -> if (selected) Icons.Filled.FitnessCenter else Icons.Outlined.FitnessCenter
        MainTab.SUBSCRIPTION -> if (selected) Icons.Filled.CardMembership else Icons.Outlined.CardMembership
        MainTab.GALLERY -> if (selected) Icons.Filled.PhotoLibrary else Icons.Outlined.PhotoLibrary
        MainTab.BOOK -> if (selected) Icons.Filled.EventAvailable else Icons.Outlined.EventAvailable
        MainTab.ACCOUNT -> if (selected) Icons.Filled.Person else Icons.Outlined.Person
        MainTab.NOTIFICATIONS -> if (selected) Icons.Filled.Notifications else Icons.Outlined.Notifications
    }
}
