package com.example.data

import android.util.Log
import com.example.BuildConfig
import com.example.R
import com.example.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

object SupabaseGymClient {

    private val rawUrl: String
        get() = runCatching { BuildConfig.SUPABASE_URL.trim().trimEnd('/') }.getOrDefault("")

    private val rawAnonKey: String
        get() = runCatching { BuildConfig.SUPABASE_ANON_KEY.trim() }.getOrDefault("")

    val isConfigured: Boolean
        get() = rawUrl.startsWith("https://") &&
            !rawUrl.contains("DEFAULT_VALUE") &&
            rawAnonKey.length > 20 &&
            !rawAnonKey.contains("DEFAULT_VALUE")

    suspend fun fetchGymConfig(): CloudGymConfig? = withContext(Dispatchers.IO) {
        if (!isConfigured) return@withContext null
        try {
            val arr = getJsonArray("/rest/v1/gym_config?id=eq.main&select=*") ?: return@withContext null
            if (arr.length() == 0) return@withContext null
            val obj = arr.getJSONObject(0)
            CloudGymConfig(
                phoneDisplay = obj.optString("phone_display", "01039157200"),
                whatsappIntl = obj.optString("whatsapp_intl", "201039157200"),
                addressAr = obj.optString("address_ar", ""),
                workingHours = obj.optString("working_hours", ""),
                pkg1mPrice = obj.optString("pkg_1m_price", "600"),
                pkg3mPrice = obj.optString("pkg_3m_price", "1,250"),
                pkg6mPrice = obj.optString("pkg_6m_price", "2,000"),
                pkg12mPrice = obj.optString("pkg_12m_price", "2,750"),
                tiktokUrl = obj.optString("tiktok_url", "https://www.tiktok.com/@captain_hima_gym"),
                facebookPageUrl = obj.optString("facebook_page_url", "https://www.facebook.com/CaptainHimaGym"),
                instagramUrl = obj.optString("instagram_url", "https://www.instagram.com/captain_hima_gym"),
                googleMapsUrl = obj.optString("google_maps_url", "")
            )
        } catch (e: Exception) {
            Log.w("SupabaseGymClient", "fetchGymConfig failed: ${e.message}")
            null
        }
    }

    suspend fun fetchStories(existingStories: List<GymStory>): List<GymStory>? = withContext(Dispatchers.IO) {
        if (!isConfigured) return@withContext null
        try {
            val arr = getJsonArray("/rest/v1/stories?is_active=eq.true&order=sort_order.asc,created_at.desc&select=*")
                ?: return@withContext null
            if (arr.length() == 0) return@withContext null
            val fallbackDrawables = listOf(
                R.drawable.img_gym_weights_1794007816793,
                R.drawable.img_gym_kickboxing_1794007819773,
                R.drawable.img_gym_spa_1794007818150,
                R.drawable.img_gym_zumba_1794007817343
            )
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val id = obj.optString("id", "story_sb_$i")
                    val existing = existingStories.firstOrNull { it.id == id }
                    add(
                        GymStory(
                            id = id,
                            title = obj.optString("title", "كابتن هيما جيم"),
                            subtitle = obj.optString("subtitle", ""),
                            badgeText = obj.optString("badge_text", "تدريب احترافي • CAPTAIN HIMA"),
                            categoryTag = obj.optString("category_tag", "صالة الحديد"),
                            programToBook = obj.optString("program_to_book", "باقة 3 شهور - 1,250 ج.م"),
                            bookingTypePreset = obj.optString("booking_type_preset", "اشتراك باقة"),
                            genderPreset = obj.optString("gender_preset", "قسم الرجال"),
                            drawableRes = existing?.drawableRes ?: fallbackDrawables[i % fallbackDrawables.size],
                            videoUrl = obj.optString("video_url").takeIf { it.isNotBlank() },
                            likesCount = obj.optInt("likes_count", existing?.likesCount ?: 120),
                            isLiked = existing?.isLiked ?: false,
                            sharesCount = obj.optInt("shares_count", existing?.sharesCount ?: 25),
                            comments = existing?.comments ?: emptyList(),
                            isViewed = existing?.isViewed ?: false,
                            audioTrackTitle = obj.optString("audio_track_title", "Captain Hima Gym Official Audio 🔥")
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Log.w("SupabaseGymClient", "fetchStories failed: ${e.message}")
            null
        }
    }

    suspend fun fetchNotifications(activeCode: String?): List<GymNotificationItem>? = withContext(Dispatchers.IO) {
        if (!isConfigured) return@withContext null
        try {
            val arr = getJsonArray("/rest/v1/notifications?order=created_at_utc_millis.desc&limit=40&select=*")
                ?: return@withContext null
            val codeUpper = activeCode?.trim()?.uppercase()
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val target = obj.optString("target_code", "ALL").uppercase()
                    if (target == "ALL" || (codeUpper != null && target == codeUpper)) {
                        add(
                            GymNotificationItem(
                                id = obj.optString("id", "notif_sb_$i"),
                                title = obj.optString("title", "أخبار وإشعارات كابتن هيما جيم"),
                                message = obj.optString("message", ""),
                                type = obj.optString("type", "ANNOUNCEMENT"),
                                targetCode = target,
                                createdAtUtcMillis = obj.optLong("created_at_utc_millis", System.currentTimeMillis()),
                                isRead = obj.optBoolean("is_read", false)
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("SupabaseGymClient", "fetchNotifications failed: ${e.message}")
            null
        }
    }

    suspend fun fetchSubscriptionByCode(code: String): MemberSubscription? = withContext(Dispatchers.IO) {
        if (!isConfigured) return@withContext null
        val normalized = code.trim().uppercase()
        if (normalized.isEmpty()) return@withContext null
        try {
            val arr = getJsonArray("/rest/v1/subscriptions?code=eq.$normalized&select=*")
                ?: return@withContext null
            if (arr.length() == 0) return@withContext null
            val obj = arr.getJSONObject(0)
            val statusCode = obj.optString("status_code", "PENDING")
            val statusEnum = SubscriptionStatus.fromCode(statusCode)
            val totalDays = obj.optInt("total_days", 90)
            val activatedMillis = obj.optLong("activated_at_utc_millis", 0L).takeIf { it > 0L }
            val expiresMillis = obj.optLong("expires_at_utc_millis", 0L).takeIf { it > 0L }
            val frozenMillis = obj.optLong("frozen_at_utc_millis", 0L).takeIf { it > 0L }

            val sub = MemberSubscription(
                code = obj.optString("code", normalized),
                orderNumber = obj.optString("order_number", ""),
                fullName = obj.optString("full_name", "مشترك كابتن هيما جيم"),
                phone = obj.optString("phone", ""),
                genderCategory = obj.optString("gender_category", "قسم الرجال"),
                packageId = obj.optString("package_id", "pkg_3m"),
                packageTitle = obj.optString("package_title", "باقة 3 شهور"),
                pricePaidEgp = obj.optInt("price_paid_egp", 1250),
                durationMonths = obj.optInt("duration_months", 3),
                totalDays = totalDays,
                remainingDays = obj.optInt("remaining_days", totalDays),
                startDate = MemberSubscription.formatCairoDate(activatedMillis),
                endDate = MemberSubscription.formatCairoDate(expiresMillis),
                statusCode = statusEnum.code,
                statusAr = obj.optString("status_ar", statusEnum.labelAr),
                createdAtUtcMillis = obj.optLong("created_at_utc_millis", System.currentTimeMillis()),
                activatedAtUtcMillis = activatedMillis,
                expiresAtUtcMillis = expiresMillis,
                frozenAtUtcMillis = frozenMillis,
                accumulatedFreezeMillis = obj.optLong("accumulated_freeze_millis", 0L),
                freezeDaysAvailable = obj.optInt("freeze_days_available", 14),
                freeInvitationsLeft = obj.optInt("free_invitations_left", 3)
            )
            sub.copy(
                remainingDays = sub.computeRealTimeRemainingDays(),
                statusCode = sub.computeEffectiveStatus().code,
                statusAr = sub.computeEffectiveStatus().labelAr
            )
        } catch (e: Exception) {
            Log.w("SupabaseGymClient", "fetchSubscriptionByCode failed: ${e.message}")
            null
        }
    }

    suspend fun submitPendingSubscriptionAndBooking(
        subscription: MemberSubscription,
        booking: BookingRecord
    ) = withContext(Dispatchers.IO) {
        if (!isConfigured) return@withContext
        try {
            val subJson = JSONObject().apply {
                put("code", subscription.code.trim().uppercase())
                put("order_number", subscription.orderNumber)
                put("full_name", subscription.fullName)
                put("phone", subscription.phone)
                put("gender_category", subscription.genderCategory)
                put("package_id", subscription.packageId)
                put("package_title", subscription.packageTitle)
                put("price_paid_egp", subscription.pricePaidEgp)
                put("duration_months", subscription.durationMonths)
                put("total_days", subscription.totalDays)
                put("remaining_days", subscription.totalDays)
                put("status_code", "PENDING")
                put("status_ar", SubscriptionStatus.PENDING.labelAr)
                put("created_at_utc_millis", subscription.createdAtUtcMillis)
                put("activated_at_utc_millis", 0L)
                put("expires_at_utc_millis", 0L)
                put("frozen_at_utc_millis", 0L)
            }
            postJson("/rest/v1/subscriptions", subJson.toString())

            val bookingJson = JSONObject().apply {
                put("id", booking.id)
                put("order_number", booking.orderNumber)
                put("reference_code", booking.referenceCode)
                put("full_name", booking.fullName)
                put("phone", booking.phone)
                put("gender_category", booking.genderCategory)
                put("booking_type", booking.bookingType)
                put("selected_item_name", booking.selectedItemName)
                put("price_egp", booking.priceEgp)
                put("preferred_date_time", booking.preferredDateTime)
                put("notes", booking.notes)
                put("status", "PENDING")
                put("created_at_utc_millis", booking.createdAtUtcMillis)
            }
            postJson("/rest/v1/bookings", bookingJson.toString())
        } catch (e: Exception) {
            Log.w("SupabaseGymClient", "submitPendingSubscriptionAndBooking warning: ${e.message}")
        }
    }

    private fun getJsonArray(endpointPath: String): JSONArray? {
        val conn = (URL("$rawUrl$endpointPath").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8000
            readTimeout = 8000
            setRequestProperty("apikey", rawAnonKey)
            setRequestProperty("Authorization", "Bearer $rawAnonKey")
            setRequestProperty("Accept", "application/json")
        }
        return try {
            if (conn.responseCode in 200..299) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                JSONArray(body)
            } else null
        } finally {
            conn.disconnect()
        }
    }

    private fun postJson(endpointPath: String, jsonBody: String): Boolean {
        val conn = (URL("$rawUrl$endpointPath").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 8000
            readTimeout = 8000
            setRequestProperty("apikey", rawAnonKey)
            setRequestProperty("Authorization", "Bearer $rawAnonKey")
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Prefer", "resolution=merge-duplicates,return=minimal")
        }
        return try {
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                writer.write(jsonBody)
                writer.flush()
            }
            conn.responseCode in 200..299
        } finally {
            conn.disconnect()
        }
    }
}
