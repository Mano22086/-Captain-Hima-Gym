package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.R
import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

class GymCmsRepository(context: Context) {

    companion object {
        const val PREFS_NAME = "CAPTAIN_HIMA_CMS_STORAGE"
        const val KEY_CMS_STATE = "CAPTAIN_HIMA_CMS_STATE"
        const val KEY_BOOKINGS_DATA = "captain_hima_gym_data"
    }

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _cmsState = MutableStateFlow(loadOrSeedState())
    val cmsState: StateFlow<CaptainHimaCmsState> = _cmsState.asStateFlow()

    private val preferenceChangeListener =
        SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == KEY_CMS_STATE || key == KEY_BOOKINGS_DATA) {
                _cmsState.value = loadOrSeedState()
            }
        }

    init {
        prefs.registerOnSharedPreferenceChangeListener(preferenceChangeListener)
    }

    fun updateState(transform: (CaptainHimaCmsState) -> CaptainHimaCmsState) {
        val updated = transform(_cmsState.value)
        _cmsState.value = updated
        persistState(updated)
    }

    fun resetToDefault() {
        prefs.edit().clear().apply()
        val seeded = createDefaultSeedState()
        _cmsState.value = seeded
        persistState(seeded)
    }

    private fun loadOrSeedState(): CaptainHimaCmsState {
        val base = createDefaultSeedState()
        val rawJson = prefs.getString(KEY_CMS_STATE, null) ?: return base
        return try {
            val root = JSONObject(rawJson)
            val phone = root.optString("phoneDisplay", base.brandInfo.phoneDisplay)
            val address = root.optString("addressAr", base.brandInfo.addressAr)
            val workingHours = root.optString("workingHours", base.brandInfo.workingHours)
            val tiktokUrl = root.optString("tiktokUrl", base.brandInfo.tiktokUrl)
            val isFollowing = root.optBoolean("isFollowingGym", false)

            // Restore dynamic story likes, views, and comments
            val storiesJson = root.optJSONObject("storiesMap")
            val restoredStories = base.stories.map { story ->
                val sObj = storiesJson?.optJSONObject(story.id)
                if (sObj != null) {
                    val likes = sObj.optInt("likesCount", story.likesCount)
                    val isLiked = sObj.optBoolean("isLiked", story.isLiked)
                    val shares = sObj.optInt("sharesCount", story.sharesCount)
                    val isViewed = sObj.optBoolean("isViewed", story.isViewed)
                    val commentsArr = sObj.optJSONArray("comments")
                    val commentsList = if (commentsArr != null) {
                        buildList {
                            for (i in 0 until commentsArr.length()) {
                                val cObj = commentsArr.getJSONObject(i)
                                add(
                                    StoryComment(
                                        id = cObj.optString("id"),
                                        authorName = cObj.optString("authorName"),
                                        text = cObj.optString("text"),
                                        timestamp = cObj.optString("timestamp")
                                    )
                                )
                            }
                        }
                    } else story.comments

                    story.copy(
                        likesCount = likes,
                        isLiked = isLiked,
                        sharesCount = shares,
                        isViewed = isViewed,
                        comments = commentsList
                    )
                } else {
                    story
                }
            }

            // Restore package price overrides if edited in Admin CMS
            val pkgPricesJson = root.optJSONObject("packagePrices")
            val restoredPackages = base.packages.map { pkg ->
                val pObj = pkgPricesJson?.optJSONObject(pkg.id)
                if (pObj != null) {
                    val disc = pObj.optInt("discountedPriceEgp", pkg.discountedPriceEgp)
                    val orig = pObj.optInt("originalPriceEgp", pkg.originalPriceEgp)
                    pkg.copy(discountedPriceEgp = disc, originalPriceEgp = orig)
                } else pkg
            }

            // Restore bookings
            val bookingsArr = root.optJSONArray("bookings")
            val restoredBookings = if (bookingsArr != null) {
                buildList {
                    for (i in 0 until bookingsArr.length()) {
                        val bObj = bookingsArr.getJSONObject(i)
                        add(
                            BookingRecord(
                                id = bObj.optString("id"),
                                referenceCode = bObj.optString("referenceCode"),
                                fullName = bObj.optString("fullName"),
                                phone = bObj.optString("phone"),
                                genderCategory = bObj.optString("genderCategory"),
                                bookingType = bObj.optString("bookingType"),
                                selectedItemName = bObj.optString("selectedItemName"),
                                preferredDateTime = bObj.optString("preferredDateTime"),
                                notes = bObj.optString("notes"),
                                createdAt = bObj.optString("createdAt")
                            )
                        )
                    }
                }
            } else base.bookings

            // Restore subscriptions
            val subsArr = root.optJSONArray("subscriptions")
            val restoredSubsFromJson = if (subsArr != null) {
                buildList {
                    for (i in 0 until subsArr.length()) {
                        val sObj = subsArr.getJSONObject(i)
                        val perksArr = sObj.optJSONArray("perks")
                        val perksList = if (perksArr != null) {
                            buildList {
                                for (j in 0 until perksArr.length()) {
                                    add(perksArr.optString(j))
                                }
                            }
                        } else emptyList()
                        add(
                            MemberSubscription(
                                code = sObj.optString("code"),
                                orderNumber = sObj.optString("orderNumber", ""),
                                fullName = sObj.optString("fullName"),
                                phone = sObj.optString("phone"),
                                genderCategory = sObj.optString("genderCategory"),
                                packageId = sObj.optString("packageId"),
                                packageTitle = sObj.optString("packageTitle"),
                                pricePaidEgp = sObj.optInt("pricePaidEgp", 1250),
                                durationMonths = sObj.optInt("durationMonths", 3),
                                totalDays = sObj.optInt("totalDays", 90),
                                remainingDays = sObj.optInt("remainingDays", 90),
                                startDate = sObj.optString("startDate"),
                                endDate = sObj.optString("endDate"),
                                statusCode = sObj.optString("statusCode", "PENDING"),
                                statusAr = sObj.optString("statusAr", "في انتظار تأكيد الإدارة ⏳"),
                                createdAtUtcMillis = sObj.optLong("createdAtUtcMillis", System.currentTimeMillis()),
                                activatedAtUtcMillis = sObj.optLong("activatedAtUtcMillis", 0L).takeIf { it > 0L },
                                expiresAtUtcMillis = sObj.optLong("expiresAtUtcMillis", 0L).takeIf { it > 0L },
                                frozenAtUtcMillis = sObj.optLong("frozenAtUtcMillis", 0L).takeIf { it > 0L },
                                accumulatedFreezeMillis = sObj.optLong("accumulatedFreezeMillis", 0L),
                                freezeDaysAvailable = sObj.optInt("freezeDaysAvailable", 14),
                                freeInvitationsLeft = sObj.optInt("freeInvitationsLeft", 3),
                                trainerNotes = sObj.optString("trainerNotes"),
                                perks = perksList
                            )
                        )
                    }
                }
            } else emptyList()

            val notifsArr = root.optJSONArray("notifications")
            val restoredNotifications = if (notifsArr != null) {
                buildList {
                    for (i in 0 until notifsArr.length()) {
                        val nObj = notifsArr.getJSONObject(i)
                        add(
                            GymNotificationItem(
                                id = nObj.optString("id"),
                                title = nObj.optString("title"),
                                message = nObj.optString("message"),
                                type = nObj.optString("type", "SUBSCRIPTION"),
                                targetCode = nObj.optString("targetCode", "ALL"),
                                createdAtUtcMillis = nObj.optLong("createdAtUtcMillis", System.currentTimeMillis()),
                                isRead = nObj.optBoolean("isRead", false)
                            )
                        )
                    }
                }
            } else base.notifications

            val activeCode = root.optString("activeSubscriptionCode", "").takeIf {
                it.isNotBlank() && !it.equals("KH37JMD", ignoreCase = true)
            }

            val filteredSubs = restoredSubsFromJson.filterNot {
                it.code.equals("KH37JMD", ignoreCase = true)
            }

            base.copy(
                brandInfo = base.brandInfo.copy(
                    phoneDisplay = phone,
                    addressAr = address,
                    workingHours = workingHours,
                    tiktokUrl = tiktokUrl
                ),
                stories = restoredStories,
                packages = restoredPackages,
                bookings = restoredBookings,
                subscriptions = filteredSubs,
                notifications = restoredNotifications,
                activeSubscriptionCode = activeCode,
                isFollowingGym = isFollowing
            )
        } catch (e: Exception) {
            base
        }
    }

    private fun persistState(state: CaptainHimaCmsState) {
        try {
            val root = JSONObject()
            root.put("phoneDisplay", state.brandInfo.phoneDisplay)
            root.put("addressAr", state.brandInfo.addressAr)
            root.put("workingHours", state.brandInfo.workingHours)
            root.put("tiktokUrl", state.brandInfo.tiktokUrl)
            root.put("isFollowingGym", state.isFollowingGym)

            val storiesMap = JSONObject()
            state.stories.forEach { story ->
                val sObj = JSONObject()
                sObj.put("likesCount", story.likesCount)
                sObj.put("isLiked", story.isLiked)
                sObj.put("sharesCount", story.sharesCount)
                sObj.put("isViewed", story.isViewed)
                val commentsArr = JSONArray()
                story.comments.forEach { comment ->
                    val cObj = JSONObject()
                    cObj.put("id", comment.id)
                    cObj.put("authorName", comment.authorName)
                    cObj.put("text", comment.text)
                    cObj.put("timestamp", comment.timestamp)
                    commentsArr.put(cObj)
                }
                sObj.put("comments", commentsArr)
                storiesMap.put(story.id, sObj)
            }
            root.put("storiesMap", storiesMap)

            val pkgPrices = JSONObject()
            state.packages.forEach { pkg ->
                val pObj = JSONObject()
                pObj.put("discountedPriceEgp", pkg.discountedPriceEgp)
                pObj.put("originalPriceEgp", pkg.originalPriceEgp)
                pkgPrices.put(pkg.id, pObj)
            }
            root.put("packagePrices", pkgPrices)

            val bookingsArr = JSONArray()
            state.bookings.forEach { b ->
                val bObj = JSONObject()
                bObj.put("id", b.id)
                bObj.put("referenceCode", b.referenceCode)
                bObj.put("fullName", b.fullName)
                bObj.put("phone", b.phone)
                bObj.put("genderCategory", b.genderCategory)
                bObj.put("bookingType", b.bookingType)
                bObj.put("selectedItemName", b.selectedItemName)
                bObj.put("preferredDateTime", b.preferredDateTime)
                bObj.put("notes", b.notes)
                bObj.put("createdAt", b.createdAt)
                bookingsArr.put(bObj)
            }
            val subsArr = JSONArray()
            state.subscriptions.forEach { s ->
                val sObj = JSONObject()
                sObj.put("code", s.code)
                sObj.put("orderNumber", s.orderNumber)
                sObj.put("fullName", s.fullName)
                sObj.put("phone", s.phone)
                sObj.put("genderCategory", s.genderCategory)
                sObj.put("packageId", s.packageId)
                sObj.put("packageTitle", s.packageTitle)
                sObj.put("pricePaidEgp", s.pricePaidEgp)
                sObj.put("durationMonths", s.durationMonths)
                sObj.put("totalDays", s.totalDays)
                sObj.put("remainingDays", s.remainingDays)
                sObj.put("startDate", s.startDate)
                sObj.put("endDate", s.endDate)
                sObj.put("statusCode", s.statusCode)
                sObj.put("statusAr", s.statusAr)
                sObj.put("createdAtUtcMillis", s.createdAtUtcMillis)
                sObj.put("activatedAtUtcMillis", s.activatedAtUtcMillis ?: 0L)
                sObj.put("expiresAtUtcMillis", s.expiresAtUtcMillis ?: 0L)
                sObj.put("frozenAtUtcMillis", s.frozenAtUtcMillis ?: 0L)
                sObj.put("accumulatedFreezeMillis", s.accumulatedFreezeMillis)
                sObj.put("freezeDaysAvailable", s.freezeDaysAvailable)
                sObj.put("freeInvitationsLeft", s.freeInvitationsLeft)
                sObj.put("trainerNotes", s.trainerNotes)
                val perksArr = JSONArray()
                s.perks.forEach { perksArr.put(it) }
                sObj.put("perks", perksArr)
                subsArr.put(sObj)
            }
            root.put("subscriptions", subsArr)

            val notifsArr = JSONArray()
            state.notifications.forEach { n ->
                val nObj = JSONObject()
                nObj.put("id", n.id)
                nObj.put("title", n.title)
                nObj.put("message", n.message)
                nObj.put("type", n.type)
                nObj.put("targetCode", n.targetCode)
                nObj.put("createdAtUtcMillis", n.createdAtUtcMillis)
                nObj.put("isRead", n.isRead)
                notifsArr.put(nObj)
            }
            root.put("notifications", notifsArr)
            root.put("activeSubscriptionCode", state.activeSubscriptionCode ?: "")

            prefs.edit()
                .putString(KEY_CMS_STATE, root.toString())
                .putString(KEY_BOOKINGS_DATA, bookingsArr.toString())
                .apply()
        } catch (_: Exception) {
        }
    }

    private fun createDefaultSeedState(): CaptainHimaCmsState {
        val stories = listOf(
            GymStory(
                id = "story_weights_cybex",
                title = "جولة داخل صالة الحديد وأحدث أجهزة Cybex 💪",
                subtitle = "أجهزة سميث، كابل كروس، ومالتي جيم احترافية لبناء العضلات بأعلى كفاءة في المنشية",
                badgeText = "صالة الحديد • Cybex",
                categoryTag = "#كابتن_هيما_جيم #بناء_عضلات #Cybex",
                programToBook = "باقة 3 شهور - 1,250 ج.م (الأكثر طلباً)",
                bookingTypePreset = "اشتراك باقة",
                genderPreset = "قسم الرجال",
                drawableRes = R.drawable.img_gym_weights_1794007816793,
                likesCount = 1420,
                isLiked = false,
                sharesCount = 318,
                audioTrackTitle = "Captain Hima Gym • Heavy Iron Phonk Beat 🎵",
                comments = listOf(
                    StoryComment("c1", "محمود نعيم", "جيم ممتاز وأجهزة Cybex على أعلى مستوى فعلاً 🔥💪", "منذ ساعتين"),
                    StoryComment("c2", "أحمد عادل", "الدمبلز وأجهزة العزل للظهر والرجلين عالمية يا كابتن هيما!", "منذ 4 ساعات"),
                    StoryComment("c3", "كريم طارق", "مفتوح 24 ساعة وده أحسن حاجة عشان تمرين بعد الشغل 👏", "منذ يوم")
                )
            ),
            GymStory(
                id = "story_spa_jacuzzi",
                title = "استرخاء كامل في الجاكوزي وحمام السباحة المغطى والساونا 🌊",
                subtitle = "منطقة سبا واستشفاء متكاملة مع جاكوزي دافئ بشلالات جدارية وساونا ومساج بعد التمرين",
                badgeText = "السبا والجاكوزي • Recovery",
                categoryTag = "#جاكوزي #سبا #استشفاء_عضلي #ساونا",
                programToBook = "جلسة السبا والجاكوزي والساونا",
                bookingTypePreset = "حجز حصة جماعية",
                genderPreset = "قسم الرجال",
                drawableRes = R.drawable.img_gym_spa_1794007818150,
                likesCount = 2150,
                isLiked = false,
                sharesCount = 540,
                audioTrackTitle = "Luxury Spa & Waterfall Ambient Chill 🌊",
                comments = listOf(
                    StoryComment("c4", "محمد مصطفى", "الجاكوزي والشلالات بعد تمرين الرجلين حاجة خرافية والله 🌟", "منذ ساعة"),
                    StoryComment("c5", "عمر الشناوي", "أول جيم في المنشية وفيصل يكون فيه سبا وحمام سباحة بالمستوى ده!", "منذ 5 ساعات")
                )
            ),
            GymStory(
                id = "story_kickboxing_hiit",
                title = "أقوى حصة Kickboxing & HIIT لحرق الدهون 🔥",
                subtitle = "تمارين عالية الشدة، مواي تاي، وكيك بوكس مع كباتن محترفين لرفع اللياقة البدنية",
                badgeText = "حرق دهون • قوة",
                categoryTag = "#Kickboxing #HIIT #MuayThai #حرق_الدهون",
                programToBook = "Kickboxing & Muay Thai (كيك بوكس ومواي تاي)",
                bookingTypePreset = "حجز حصة جماعية",
                genderPreset = "قسم الرجال",
                drawableRes = R.drawable.img_gym_kickboxing_1794007819773,
                likesCount = 1890,
                isLiked = false,
                sharesCount = 412,
                audioTrackTitle = "High Octane HIIT & Kickboxing Cardio Mix ⚡",
                comments = listOf(
                    StoryComment("c6", "يوسف هاني", "حصة الكيك بوكس بتحرق فوق 800 سعرة، الكباتن قمة في الاحترام 💪", "منذ 3 ساعات"),
                    StoryComment("c7", "زياد محمود", "مواعيد الحصص من السبت للخميس ممتازة جداً", "منذ يوم")
                )
            ),
            GymStory(
                id = "story_black_friday_50",
                title = "عروض البلاك فرايدي خصم 50% على جميع الاشتراكات ⚡",
                subtitle = "اشترك الآن: شهر 600 ج.م | 3 شهور 1,250 ج.م | 6 شهور 2,000 ج.م | سنة VIP بـ 2,750 ج.م فقط!",
                badgeText = "خصم 50% لفترة محدودة",
                categoryTag = "#عروض_الجيم #خصم_50 #باقات_الاشتراك",
                programToBook = "باقة سنة كاملة (VIP) - 2,750 ج.م",
                bookingTypePreset = "اشتراك باقة",
                genderPreset = "قسم الرجال",
                drawableRes = R.drawable.img_launcher_icon_1794007815888,
                likesCount = 3240,
                isLiked = false,
                sharesCount = 890,
                audioTrackTitle = "Captain Hima Official Promo Anthem 🔥",
                comments = listOf(
                    StoryComment("c8", "مصطفى كامل", "عرض السنة بـ 2750 بدل 5500 لقطة بصراحة، تم الحجز! 🎉", "منذ 30 دقيقة"),
                    StoryComment("c9", "إبراهيم سعيد", "هل العرض شامل السبا والكارديو؟ -> نعم شامل كل الأقسام!", "منذ ساعتين")
                )
            ),
            GymStory(
                id = "story_ladies_zumba",
                title = "مواعيد خاصة للسيدات بخصوصية كاملة وحصص زومبا 💃",
                subtitle = "خصوصية تامة 100% مع مدربات محترفات لحصص Zumba, Aerobics, Yoga & Dance Fitness",
                badgeText = "قسم السيدات • خصوصية تامة",
                categoryTag = "#زومبا_للسيدات #خصوصية_تامة #رشاقة #Zumba",
                programToBook = "Zumba (زومبا للسيدات)",
                bookingTypePreset = "حجز حصة جماعية",
                genderPreset = "قسم السيدات",
                drawableRes = R.drawable.img_gym_zumba_1794007817343,
                likesCount = 2680,
                isLiked = false,
                sharesCount = 675,
                audioTrackTitle = "Latin Zumba & Dance Fitness Energy Rhythm 💃",
                comments = listOf(
                    StoryComment("c10", "سارة أحمد", "أخيراً جيم في المنشية بيوفر خصوصية كاملة للسيدات وأجهزة نضيفة جداً 💖", "منذ ساعة"),
                    StoryComment("c11", "نورهان علي", "حصة الزومبا والايروبكس تحفة والمدربات قمة في الذوق 🌸", "منذ 6 ساعات")
                )
            )
        )

        val facilities = listOf(
            FacilityDepartment(
                id = "fac_weights",
                title = "صالة الحديد وبناء العضلات",
                subtitle = "Pro Strength & Bodybuilding Arena",
                description = "مجهزة بالكامل بأحدث أجهزة القوة والعزل العضلي لبناء الكتلة العضلية بأمان واحترافية عالية.",
                features = listOf(
                    "أجهزة سميث (Smith Machine) وأوزان حرة متكاملة",
                    "كابل كروس ومالتي جيم (Cable Crossover)",
                    "أجهزة سحب عالي وسفلي للظهر والذراعين",
                    "أجهزة عزل متخصصة لعضلات الأرجل والظهر"
                ),
                drawableRes = R.drawable.img_gym_weights_1794007816793,
                badge = "أجهزة Cybex العالمية",
                defaultBookingProgram = "باقة 3 شهور - 1,250 ج.م (الأكثر طلباً)"
            ),
            FacilityDepartment(
                id = "fac_cardio",
                title = "قسم الكارديو واللياقة",
                subtitle = "Cybex Cardio & Endurance Zone",
                description = "صالة كارديو واسعة ومكيفة بالكامل لحرق الدهون ورفع كفاءة القلب والرئتين.",
                features = listOf(
                    "مشايات كهربائية احترافية (Treadmills)",
                    "أجهزة كارديو أصلية ماركة Cybex",
                    "أجهزة إليبتيكال (Elliptical) ودراجات ثابتة",
                    "برامج حرق دهون مخصصة لكل مستوى"
                ),
                drawableRes = R.drawable.img_gym_zumba_1794007817343,
                badge = "حرق دهون فائق",
                defaultBookingProgram = "HIIT (تمارين عالية الشدة لحرق الدهون)"
            ),
            FacilityDepartment(
                id = "fac_spa",
                title = "منطقة السبا والاستشفاء (Spa & Recovery)",
                subtitle = "Indoor Pool, Jacuzzi, Sauna & Massage",
                description = "استمتع بتجربة فندقية للاستشفاء العضلي وإزالة التوتر بعد التمرين مباشرة.",
                features = listOf(
                    "حمام سباحة مغطى ومجهز بالكامل",
                    "جاكوزي دافئ مع شلالات جدارية مريحة للأعصاب",
                    "غرفة ساونا خشبية لتنقية الجسم من السموم",
                    "جلسات مساج واستشفاء عضلي (Recovery)"
                ),
                drawableRes = R.drawable.img_gym_spa_1794007818150,
                badge = "حمام سباحة وجاكوزي",
                defaultBookingProgram = "جلسة السبا والجاكوزي والساونا"
            ),
            FacilityDepartment(
                id = "fac_pt",
                title = "التدريب الشخصي والتغذية",
                subtitle = "Personal Training & Nutrition Guide",
                description = "خطة متكاملة مفصلة على هدفك سواء التنشيف وحرق الدهون أو الضخامة العضلية.",
                features = listOf(
                    "متابعة مستمرة مع كباتن محترفين ومعتمدين",
                    "برامج تخسيس، نحت القوام، وزيادة عضلية",
                    "إرشاد غذائي متكامل (Nutrition Guide)",
                    "قياسات دورية لمتابعة تطور نسبة العضلات والدهون"
                ),
                drawableRes = R.drawable.img_gym_kickboxing_1794007819773,
                badge = "متابعة فردية VIP",
                defaultBookingProgram = "التدريب الشخصي والتغذية (Personal Training)"
            )
        )

        val packages = listOf(
            MembershipPackage(
                id = "pkg_1m",
                title = "باقة شهر واحد",
                subtitle = "بداية قوية لتجربة مستوى كابتن هيما جيم",
                durationMonths = 1,
                discountedPriceEgp = 600,
                originalPriceEgp = 1200,
                discountPercent = 50,
                badgeText = "خصم 50%",
                isPopular = false,
                isVip = false,
                perks = listOf(
                    "دخول مفتوح لصالة الحديد وأجهزة Cybex",
                    "استخدام قسم الكارديو والمشايات بالكامل",
                    "إرشاد مبدئي لجدول التمرين",
                    "متاح لقسم الرجال أو فترات السيدات"
                )
            ),
            MembershipPackage(
                id = "pkg_3m",
                title = "باقة 3 شهور",
                subtitle = "الاختيار الأول لتحقيق تغيير واضح في شكل جسمك",
                durationMonths = 3,
                discountedPriceEgp = 1250,
                originalPriceEgp = 2500,
                discountPercent = 50,
                badgeText = "الأكثر طلباً 🔥 • خصم 50%",
                isPopular = true,
                isVip = false,
                perks = listOf(
                    "توفير 1,250 ج.م (الشهر يقف بـ 416 ج.م فقط)",
                    "شامل صالة الحديد + قسم الكارديو Cybex",
                    "برنامج تدريبي + نظام غذائي (Nutrition Guide)",
                    "حصص جماعية ودخول منطقة الاستشفاء"
                )
            ),
            MembershipPackage(
                id = "pkg_6m",
                title = "باقة 6 شهور",
                subtitle = "التزام نصف سنوي لنتائج احترافية مستدامة",
                durationMonths = 6,
                discountedPriceEgp = 2000,
                originalPriceEgp = 4000,
                discountPercent = 50,
                badgeText = "خصم 50% • توفير ضخم",
                isPopular = false,
                isVip = false,
                perks = listOf(
                    "توفير 2,000 ج.م (الشهر يقف بـ 333 ج.م فقط)",
                    "دخول شامل للحديد والكارديو والحصص الجماعية",
                    "متابعة دورية وتحديث جدول التمرين والتغذية",
                    "جلسات سبا وجاكوزي وساونا مميزة"
                )
            ),
            MembershipPackage(
                id = "pkg_12m",
                title = "باقة سنة كاملة (VIP)",
                subtitle = "أفضل قيمة على الإطلاق لعضوية سنوية شاملة",
                durationMonths = 12,
                discountedPriceEgp = 2750,
                originalPriceEgp = 5500,
                discountPercent = 50,
                badgeText = "أفضل قيمة 👑 VIP • خصم 50%",
                isPopular = false,
                isVip = true,
                perks = listOf(
                    "توفير 2,750 ج.م (الشهر يقف بـ 229 ج.م فقط!)",
                    "عضوية VIP شاملة الحديد، الكارديو، والسبا والجاكوزي",
                    "أولوية في الحصص الجماعية والمتابعة مع الكباتن",
                    "إمكانية تجميد الاشتراك (Freeze) ودعوات مجانية لأصدقائك"
                )
            )
        )

        val groupClasses = listOf(
            GroupClassItem(
                id = "cls_zumba",
                nameEn = "Zumba",
                nameAr = "زومبا للسيدات (Zumba)",
                category = ClassGenderFilter.LADIES,
                daysAr = "السبت - الإثنين - الأربعاء",
                timeSlotAr = "4:00 م - 5:30 م (خصوصية تامة)",
                trainerName = "كابتن سارة (مدربة زومبا معتمدة)",
                caloriesBurn = "650 - 800 سعرة",
                intensityAr = "متوسطة إلى عالية",
                drawableRes = R.drawable.img_gym_zumba_1794007817343
            ),
            GroupClassItem(
                id = "cls_aerobics",
                nameEn = "Aerobics",
                nameAr = "إيروبكس ولياقة بدنية (Aerobics)",
                category = ClassGenderFilter.LADIES,
                daysAr = "الأحد - الثلاثاء - الخميس",
                timeSlotAr = "3:00 م - 4:30 م (قسم السيدات)",
                trainerName = "كابتن نورهان",
                caloriesBurn = "550 - 700 سعرة",
                intensityAr = "متوسطة",
                drawableRes = R.drawable.img_gym_zumba_1794007817343
            ),
            GroupClassItem(
                id = "cls_hiit",
                nameEn = "HIIT",
                nameAr = "تمارين عالية الشدة لحرق الدهون (HIIT)",
                category = ClassGenderFilter.ALL,
                daysAr = "السبت إلى الخميس (يومياً)",
                timeSlotAr = "7:00 م للسيدات | 9:30 م للرجال",
                trainerName = "فريق كابتن هيما المحترف",
                caloriesBurn = "750 - 950 سعرة",
                intensityAr = "عالية جداً 🔥",
                drawableRes = R.drawable.img_gym_kickboxing_1794007819773
            ),
            GroupClassItem(
                id = "cls_kickboxing",
                nameEn = "Kickboxing & Muay Thai",
                nameAr = "كيك بوكس ومواي تاي (Kickboxing & Muay Thai)",
                category = ClassGenderFilter.MEN,
                daysAr = "السبت - الإثنين - الأربعاء",
                timeSlotAr = "8:00 م - 9:30 م",
                trainerName = "كابتن هيما وفريق القتال",
                caloriesBurn = "800 - 1,000 سعرة",
                intensityAr = "قوة وتحمل عالي 🥊",
                drawableRes = R.drawable.img_gym_kickboxing_1794007819773
            ),
            GroupClassItem(
                id = "cls_abs",
                nameEn = "Abs & Core",
                nameAr = "تمارين البطن والجذع (Abs & Core)",
                category = ClassGenderFilter.ALL,
                daysAr = "الأحد - الثلاثاء - الخميس",
                timeSlotAr = "6:00 م للسيدات | 10:00 م للرجال",
                trainerName = "كابتن أحمد & كابتن مريم",
                caloriesBurn = "450 - 600 سعرة",
                intensityAr = "تركيز عضلي عميق",
                drawableRes = R.drawable.img_gym_weights_1794007816793
            ),
            GroupClassItem(
                id = "cls_yoga",
                nameEn = "Yoga & Dance Fitness",
                nameAr = "يوجا ودانس فيتنس (Yoga & Dance Fitness)",
                category = ClassGenderFilter.LADIES,
                daysAr = "السبت - الثلاثاء - الخميس",
                timeSlotAr = "5:00 م - 6:00 م (خصوصية تامة)",
                trainerName = "كابتن دينا",
                caloriesBurn = "400 - 550 سعرة",
                intensityAr = "مرونة واسترخاء",
                drawableRes = R.drawable.img_gym_spa_1794007818150
            )
        )

        val galleryItems = listOf(
            GalleryMediaItem(
                id = "gal_weights_1",
                title = "صالة الحديد وأجهزة Cybex الاحترافية",
                subtitle = "Smith Machine & Cable Crossover",
                category = GalleryCategory.WEIGHTS,
                description = "صالة حديد متكاملة بأحدث أجهزة Cybex العالمية، أجهزة سميث، كابل كروس، وأوزان حرة لجميع الزوايا العضلية.",
                drawableRes = R.drawable.img_gym_weights_1794007816793,
                externalReferenceUrl = "https://www.facebook.com/photo?fbid=122124538407384387&set=pb.61591531637010.-2207520000",
                badgeText = "صالة الحديد"
            ),
            GalleryMediaItem(
                id = "gal_spa_1",
                title = "حمام السباحة المغطى والجاكوزي بالشلالات",
                subtitle = "Luxury Indoor Pool, Jacuzzi & Sauna",
                category = GalleryCategory.SPA,
                description = "منطقة السبا والاستشفاء في كابتن هيما جيم: حمام سباحة مغطى، جاكوزي دافئ مع شلالات جدارية، وغرفة ساونا ومساج.",
                drawableRes = R.drawable.img_gym_spa_1794007818150,
                externalReferenceUrl = "https://www.facebook.com/CaptainHimaGym",
                badgeText = "السبا والجاكوزي"
            ),
            GalleryMediaItem(
                id = "gal_classes_kickboxing",
                title = "استوديو Kickboxing & Muay Thai & HIIT",
                subtitle = "High Intensity Functional Studio",
                category = GalleryCategory.CLASSES,
                description = "استوديو مجهز بالكامل لحصص الكيك بوكس، المواي تاي، وتمارين HIIT عالية الشدة لحرق الدهون.",
                drawableRes = R.drawable.img_gym_kickboxing_1794007819773,
                externalReferenceUrl = "https://www.facebook.com/photo/?fbid=122148460221384387&set=pb.61591531637010.-2207520000",
                badgeText = "الحصص الجماعية"
            ),
            GalleryMediaItem(
                id = "gal_classes_zumba",
                title = "استوديو السيدات الخاص وحصص Zumba",
                subtitle = "100% Ladies Privacy & Dance Fitness",
                category = GalleryCategory.CLASSES,
                description = "فترات وقاعات مخصصة للسيدات بخصوصية تامة 100% لحصص الزومبا، الإيروبكس، واليوجا مع مدربات محترفات.",
                drawableRes = R.drawable.img_gym_zumba_1794007817343,
                externalReferenceUrl = "https://www.facebook.com/photo/?fbid=122148460221384387&set=pb.61591531637010.-2207520000",
                badgeText = "قسم السيدات"
            ),
            GalleryMediaItem(
                id = "gal_poster_offers",
                title = "بوستر عروض خصم 50% الرسمي",
                subtitle = "Official 50% OFF Membership Packages Poster",
                category = GalleryCategory.OFFERS,
                description = "عروض كابتن هيما جيم الرسمية: شهر 600 ج.م | 3 شهور 1,250 ج.م | 6 شهور 2,000 ج.م | سنة كاملة 2,750 ج.م.",
                drawableRes = R.drawable.img_launcher_icon_1794007815888,
                externalReferenceUrl = "https://www.facebook.com/photo/?fbid=122148567543384387&set=pb.61591531637010.-2207520000",
                badgeText = "بوستر العروض الرسمي"
            ),
            GalleryMediaItem(
                id = "gal_poster_schedule",
                title = "جدول الحصص الجماعية الأسبوعي الرسمي",
                subtitle = "Saturday to Thursday Group Classes Schedule",
                category = GalleryCategory.OFFERS,
                description = "جدول حصص الزومبا، الإيروبكس، HIIT، الكيك بوكس، والبطن من السبت إلى الخميس على صفحة فيسبوك الرسمية.",
                drawableRes = R.drawable.img_gym_kickboxing_1794007819773,
                externalReferenceUrl = "https://www.facebook.com/photo/?fbid=122148460221384387&set=pb.61591531637010.-2207520000",
                badgeText = "جدول الحصص"
            )
        )

        val reviews = listOf(
            GymReview(
                id = "rev_mahmoud",
                reviewerName = "Mahmoud Naeem",
                rating = 5,
                roleBadge = "مرشد محلي • تقييم موثق على خرائط جوجل",
                dateText = "5.0 ★ Google Maps",
                commentText = "\"جيم ممتاز اجهزه علي اعلي مستوي اداره محترمه وكباتن ممتازين احسن جيم علي مستوى المناطق المجاوره عن أكثر من تجربه\""
            ),
            GymReview(
                id = "rev_mohamed",
                reviewerName = "Mohamed Mustafa",
                rating = 5,
                roleBadge = "عضو بالجيم • تقييم موثق على خرائط جوجل",
                dateText = "5.0 ★ Google Maps",
                commentText = "\"تقييم 5 نجوم كامل - مكان متكامل ومفتوح 24 ساعة، نظافة ممتازة وأجهزة حديثة ومنطقة سبا وجاكوزي على أعلى مستوى في المنشية وفيصل.\""
            )
        )

        val initialNotifications = listOf(
            GymNotificationItem(
                id = "notif_offer_50",
                title = "خصم 50% على جميع باقات الاشتراك 🔥",
                message = "اشترك الآن في كابتن هيما جيم واحصل على خصم 50% على باقات الشهر و3 شهور و6 شهور وسنة VIP.",
                type = "OFFER",
                targetCode = "ALL",
                createdAtUtcMillis = System.currentTimeMillis() - 3_600_000L
            ),
            GymNotificationItem(
                id = "notif_24h",
                title = "النادي مفتوح 24 ساعة يومياً ⚡",
                message = "نرحب بأبطال كابتن هيما جيم على مدار 24 ساعة طوال أيام الأسبوع مع مواعيد خاصة للسيدات بخصوصية تامة.",
                type = "ANNOUNCEMENT",
                targetCode = "ALL",
                createdAtUtcMillis = System.currentTimeMillis() - 86_400_000L
            )
        )

        return CaptainHimaCmsState(
            brandInfo = GymBrandInfo(),
            stories = stories,
            facilities = facilities,
            packages = packages,
            groupClasses = groupClasses,
            galleryItems = galleryItems,
            reviews = reviews,
            bookings = emptyList(),
            subscriptions = emptyList(),
            notifications = initialNotifications,
            activeSubscriptionCode = null,
            isFollowingGym = false
        )
    }
}
