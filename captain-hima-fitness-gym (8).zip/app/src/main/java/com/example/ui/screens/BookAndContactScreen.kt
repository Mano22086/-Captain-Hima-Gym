package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun BookAndContactScreen(
    cmsState: CaptainHimaCmsState,
    onSubmitDirectBooking: (
        fullName: String,
        phone: String,
        genderCategory: String,
        bookingType: String,
        selectedItemName: String,
        preferredDateTime: String,
        notes: String,
        onDone: (BookingRecord) -> Unit
    ) -> Unit,
    onConfirmViaWhatsApp: (BookingRecord) -> Unit,
    onActivateBookedCode: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val brand = cmsState.brandInfo

    var fullName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var genderCategory by remember { mutableStateOf("قسم الرجال") }
    var bookingType by remember { mutableStateOf("اشتراك باقة") }

    val packageOptions = remember(cmsState.packages) {
        cmsState.packages.map { "${it.title} - ${it.discountedPriceEgp} ج.م بدلاً من ${it.originalPriceEgp} ج.م" }
    }
    val classOptions = remember(cmsState.groupClasses) {
        cmsState.groupClasses.map { "${it.nameAr} (${it.daysAr})" } + listOf(
            "جلسة السبا والجاكوزي والساونا",
            "التدريب الشخصي والتغذية (Personal Training)"
        )
    }
    val currentPool = if (bookingType == "اشتراك باقة") packageOptions else classOptions

    var selectedItemName by remember(bookingType) {
        mutableStateOf(currentPool.getOrElse(1) { currentPool.firstOrNull() ?: "" })
    }
    var preferredDateTime by remember { mutableStateOf("اليوم - الساعة 8:00 مساءً") }
    var notes by remember { mutableStateOf("") }
    var validationError by remember { mutableStateOf(false) }
    var submittedRecord by remember { mutableStateOf<BookingRecord?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("book_contact_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // 1. Luxury 3D Glass Order & Subscription Center
        item {
            Surface(
                color = CardSurfaceDark,
                shape = RoundedCornerShape(30.dp),
                shadowElevation = 22.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.8.dp, LuxuryGoldBorderBrush, RoundedCornerShape(30.dp))
            ) {
                val record = submittedRecord
                if (record != null) {
                    Column(
                        modifier = Modifier
                            .background(Glass3DSurfaceBrush)
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(80.dp)
                                .clip(CircleShape)
                                .background(FieryOrange.copy(alpha = 0.18f))
                                .border(2.dp, LuxuryGoldBorderBrush, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.WorkspacePremium,
                                contentDescription = null,
                                tint = WarmGold,
                                modifier = Modifier.size(42.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "تم تسجيل طلبك بنجاح، اشتراكك في انتظار تأكيد الإدارة.",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = CrispWhite,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "تم إصدار كود اشتراكك العشوائي الفريد وحفظ الطلب في قاعدة البيانات ولوحة التحكم",
                            style = MaterialTheme.typography.bodySmall,
                            color = MutedZinc,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Luxury 3D Glass Pass Summary Card
                        Surface(
                            color = CardSurfaceElevated,
                            shape = RoundedCornerShape(24.dp),
                            border = BorderStroke(1.5.dp, LuxuryGoldBorderBrush),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .background(Glass3DSurfaceBrush)
                                    .padding(18.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "كود الاشتراك العشوائي الفريد الخاص بك",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = WarmGold,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "#${record.referenceCode}",
                                    style = MaterialTheme.typography.headlineLarge.copy(letterSpacing = 2.sp),
                                    fontWeight = FontWeight.Black,
                                    color = FieryOrange
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Surface(
                                    color = WarmGold.copy(alpha = 0.16f),
                                    shape = RoundedCornerShape(50),
                                    border = BorderStroke(1.dp, WarmGold.copy(alpha = 0.5f))
                                ) {
                                    Text(
                                        text = "رقم الطلب: ${record.orderNumber} • الحالة: PENDING",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = WarmGold,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                                    )
                                }
                                HorizontalDivider(
                                    modifier = Modifier.padding(vertical = 12.dp),
                                    color = GlassBorderWhite
                                )
                                Text(
                                    text = "المشترك: ${record.fullName} | الموبايل: ${record.phone}\n${record.genderCategory} • ${record.selectedItemName} (${record.priceEgp} ج.م)",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = CrispWhite,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = { onConfirmViaWhatsApp(record) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("direct_booking_whatsapp_button"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "إرسال رسالة الطلب عبر واتساب 💬",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = CrispWhite
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Button(
                            onClick = { onActivateBookedCode(record.referenceCode) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("direct_booking_activate_code_button"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = FieryOrange,
                                contentColor = CrispWhite
                            )
                        ) {
                            Icon(Icons.Default.Key, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "فتح بطاقة العضوية ومتابعة الطلب (${record.referenceCode}) 🔑",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Black
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        TextButton(onClick = { submittedRecord = null }) {
                            Text("تسجيل طلب اشتراك آخر جديد", color = WarmGold, fontWeight = FontWeight.Bold)
                        }
                    }
                } else {
                    Column(
                        modifier = Modifier
                            .background(Glass3DSurfaceBrush)
                            .padding(20.dp)
                    ) {
                        // Top Luxury Hero Banner inside the Order Card
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(24.dp))
                                .border(1.2.dp, LuxuryGoldBorderBrush, RoundedCornerShape(24.dp))
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.img_gym_weights_1794007816793),
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                alpha = 0.52f,
                                modifier = Modifier
                                    .matchParentSize()
                            )
                            val bookBannerTopAlpha = if (AppThemeController.isDarkMode) 0.35f else 0.18f
                            val bookBannerBottomAlpha = if (AppThemeController.isDarkMode) 0.65f else 0.42f
                            Box(
                                modifier = Modifier
                                    .matchParentSize()
                                    .background(
                                        Brush.verticalGradient(
                                            colors = listOf(
                                                ObsidianBlack.copy(alpha = bookBannerTopAlpha),
                                                ObsidianBlack.copy(alpha = bookBannerBottomAlpha)
                                            )
                                        )
                                    )
                            )

                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(18.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Image(
                                        painter = painterResource(id = R.drawable.img_official_logo),
                                        contentDescription = "CAPTAIN HIMA FITNESS GYM",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(54.dp)
                                            .clip(CircleShape)
                                            .border(2.dp, LuxuryGoldBorderBrush, CircleShape)
                                    )
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.WorkspacePremium,
                                                contentDescription = null,
                                                tint = WarmGold,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Text(
                                                text = "VIP MEMBERSHIP REGISTRATION",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Black,
                                                color = WarmGold,
                                                letterSpacing = 1.1.sp
                                            )
                                        }
                                        Text(
                                            text = "بوابة طلب الاشتراك والعضوية الملكية",
                                            style = MaterialTheme.typography.titleLarge,
                                            fontWeight = FontWeight.Black,
                                            color = CrispWhite
                                        )
                                        Text(
                                            text = "سجل بياناتك واختر باقتك ليصدر لك كود اشتراكك العشوائي الفريد فوراً",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MutedZinc
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                // 3-Step Visual Progress Bar
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OrderStepPill(
                                        stepNumber = "1",
                                        title = "بيانات المشترك",
                                        active = true,
                                        modifier = Modifier.weight(1f)
                                    )
                                    OrderStepPill(
                                        stepNumber = "2",
                                        title = "اختيار الباقة",
                                        active = true,
                                        modifier = Modifier.weight(1f)
                                    )
                                    OrderStepPill(
                                        stepNumber = "3",
                                        title = "إصدار الكود الفوري",
                                        active = fullName.isNotBlank() && phone.isNotBlank(),
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        // Section 1: Member Identity Data Entry Pods
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Badge,
                                contentDescription = null,
                                tint = WarmGold,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "1. بيانات صاحب العضوية",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = CrispWhite
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        LuxuryGlassDataField(
                            value = fullName,
                            onValueChange = {
                                fullName = it
                                validationError = false
                            },
                            label = "الاسم الثلاثي للمشترك",
                            placeholder = "اكتب اسمك الكامل كما سيظهر على بطاقة العضوية VIP",
                            icon = Icons.Default.Person,
                            accentColor = FieryOrange,
                            badgeText = "مطلوب *",
                            testTag = "direct_name_input"
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        LuxuryGlassDataField(
                            value = phone,
                            onValueChange = {
                                phone = it
                                validationError = false
                            },
                            label = "رقم الموبايل / واتساب لتأكيد التفعيل",
                            placeholder = "010XXXXXXXX",
                            icon = Icons.Default.PhoneAndroid,
                            accentColor = WarmGold,
                            badgeText = "مطلوب *",
                            testTag = "direct_phone_input"
                        )

                        if (validationError) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Surface(
                                color = LikeCrimson.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, LikeCrimson),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "⚠️ يرجى إدخال الاسم الثلاثي ورقم الهاتف لإتمام طلب الاشتراك",
                                    color = CrispWhite,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Section 2: Department & Membership Type 3D Glass Switchers
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Category,
                                contentDescription = null,
                                tint = WarmGold,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "2. اختر القسم ونوع الحجز",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = CrispWhite
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            listOf("قسم الرجال", "قسم السيدات").forEach { g ->
                                val selected = genderCategory == g
                                Surface(
                                    onClick = { genderCategory = g },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(16.dp),
                                    color = if (selected) FieryOrange else CardSurfaceElevated,
                                    border = BorderStroke(
                                        width = if (selected) 1.8.dp else 1.dp,
                                        color = if (selected) WarmGold else GlassBorderWhite
                                    )
                                ) {
                                    Box(
                                        modifier = Modifier.padding(vertical = 12.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = if (g == "قسم الرجال") "💪 قسم الرجال" else "💃 قسم السيدات",
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = if (selected) CrispWhite else MutedZinc
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            listOf("اشتراك باقة", "حجز حصة جماعية").forEach { t ->
                                val selected = bookingType == t
                                Surface(
                                    onClick = { bookingType = t },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(16.dp),
                                    color = if (selected) WarmGold.copy(alpha = 0.22f) else CardSurfaceElevated,
                                    border = BorderStroke(
                                        width = if (selected) 1.8.dp else 1.dp,
                                        color = if (selected) WarmGold else GlassBorderWhite
                                    )
                                ) {
                                    Box(
                                        modifier = Modifier.padding(vertical = 12.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = if (t == "اشتراك باقة") "👑 باقات العضوية VIP" else "⚡ الحصص والسبا",
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = if (selected) WarmGold else MutedZinc
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        // Section 3: Luxury 3D Glass Package Selection Cards
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.WorkspacePremium,
                                    contentDescription = null,
                                    tint = WarmGold,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = if (bookingType == "اشتراك باقة") "3. اختر باقة العضوية" else "3. اختر الحصة أو الخدمة",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = CrispWhite
                                )
                            }
                            Surface(
                                color = FieryOrange.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(50),
                                border = BorderStroke(1.dp, FieryOrange.copy(alpha = 0.6f))
                            ) {
                                Text(
                                    text = "خصم 50% حصري 🔥",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = FieryOrange,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        if (bookingType == "اشتراك باقة") {
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                cmsState.packages.forEach { pkg ->
                                    val optionString = "${pkg.title} - ${pkg.discountedPriceEgp} ج.م بدلاً من ${pkg.originalPriceEgp} ج.م"
                                    val isSelected = selectedItemName == optionString || selectedItemName.contains(pkg.title)
                                    Selectable3DGlassPackageCard(
                                        pkg = pkg,
                                        isSelected = isSelected,
                                        onSelect = { selectedItemName = optionString }
                                    )
                                }
                            }
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                classOptions.forEach { option ->
                                    val isSelected = selectedItemName == option
                                    Selectable3DGlassServiceCard(
                                        title = option.substringBefore("(").trim(),
                                        subtitle = option.substringAfter("(", "حصة تدريبية متكاملة").removeSuffix(")"),
                                        isSelected = isSelected,
                                        onSelect = { selectedItemName = option }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Section 4: Schedule & Notes Glass Pods
                        LuxuryGlassDataField(
                            value = preferredDateTime,
                            onValueChange = { preferredDateTime = it },
                            label = "تاريخ وموعد بدء الاشتراك المفضل",
                            placeholder = "مثال: اليوم - الساعة 8:00 مساءً",
                            icon = Icons.Default.Schedule,
                            accentColor = WarmGold,
                            badgeText = "الموعد"
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        LuxuryGlassDataField(
                            value = notes,
                            onValueChange = { notes = it },
                            label = "ملاحظات إضافية للكابتن (اختياري)",
                            placeholder = "مثال: أرغب في جدول تمرين وتغذية خاص",
                            icon = Icons.Default.EditNote,
                            accentColor = FieryOrange,
                            singleLine = false,
                            maxLines = 3
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Automatic Random Code Notice
                        Surface(
                            color = FieryOrange.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, FieryOrange.copy(alpha = 0.45f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Key,
                                    contentDescription = null,
                                    tint = WarmGold,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "سيتم إصدار كود اشتراك عشوائي وفريد لك تلقائياً فور إرسال الطلب",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = CrispWhite,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        Button(
                            onClick = {
                                if (fullName.isBlank() || phone.isBlank()) {
                                    validationError = true
                                } else {
                                    onSubmitDirectBooking(
                                        fullName,
                                        phone,
                                        genderCategory,
                                        bookingType,
                                        selectedItemName,
                                        preferredDateTime,
                                        notes
                                    ) { record ->
                                        submittedRecord = record
                                        onConfirmViaWhatsApp(record)
                                    }
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .testTag("direct_booking_submit_button"),
                            shape = RoundedCornerShape(18.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = FieryOrange)
                        ) {
                            Icon(Icons.Default.LocalFireDepartment, contentDescription = null, tint = WarmGold)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "إرسال الطلب وإصدار كود الاشتراك العشوائي 🔥",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = CrispWhite
                            )
                        }
                    }
                }
            }
        }

        // 2. Interactive Map & Verified Address Card
        item {
            Surface(
                color = CardSurfaceDark,
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, GlassBorderWhite),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .background(Glass3DSurfaceBrush)
                        .padding(18.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Map,
                            contentDescription = null,
                            tint = WarmGold,
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "موقع الجيم على خرائط جوجل 🗺️",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = CrispWhite
                            )
                            Text(
                                text = "Plus Code: ${brand.plusCode} • تقييم 5.0 ★",
                                style = MaterialTheme.typography.labelMedium,
                                color = WarmGold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Surface(
                        color = CardSurfaceElevated,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, FieryOrange.copy(alpha = 0.35f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "📍 العنوان بالتفصيل:",
                                style = MaterialTheme.typography.labelLarge,
                                color = FieryOrange
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = brand.addressAr,
                                style = MaterialTheme.typography.bodyLarge,
                                color = CrispWhite
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "🕒 مواعيد العمل: ${brand.workingHours}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = EmeraldSuccess
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { launchExternalUrl(context, brand.googleMapsUrl) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = WarmGold)
                    ) {
                        GoogleBrandBadgeIcon(size = 22.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "افتح الاتجاهات في Google Maps",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = CrispWhite
                        )
                    }
                }
            }
        }

        // 3. Direct Phone, WhatsApp & Social Channels Card
        item {
            Surface(
                color = CardSurfaceDark,
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, GlassBorderWhite),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .background(Glass3DSurfaceBrush)
                        .padding(18.dp)
                ) {
                    Text(
                        text = "قنوات التواصل والصفحات الرسمية 📞",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = CrispWhite
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { launchPhoneDialer(context, brand.phoneDisplay) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = FieryOrange)
                    ) {
                        Icon(Icons.Default.Call, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "اتصال مباشر: ${brand.phoneDisplay}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            val waUrl = "https://wa.me/${brand.whatsappIntl}?text=" +
                                android.net.Uri.encode("السلام عليكم كابتن هيما جيم، أريد الاستفسار عن الاشتراكات ومواعيد التمرين 💪")
                            launchExternalUrl(context, waUrl)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "تواصل عبر واتساب (+${brand.whatsappIntl})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { launchExternalUrl(context, brand.googleMapsUrl) },
                            border = BorderStroke(1.dp, WarmGold),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("contact_google_button")
                        ) {
                            GoogleBrandBadgeIcon(size = 20.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("جوجل مابس", color = WarmGold, fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = { launchExternalUrl(context, brand.facebookPageUrl) },
                            border = BorderStroke(1.dp, FacebookBlue),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("contact_facebook_button")
                        ) {
                            FacebookBrandBadgeIcon(size = 20.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("فيسبوك", color = FacebookBlue, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { launchExternalUrl(context, brand.instagramUrl) },
                            border = BorderStroke(1.dp, InstagramPink),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("contact_instagram_button")
                        ) {
                            InstagramBrandBadgeIcon(size = 20.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("إنستجرام", color = InstagramPink, fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = { launchExternalUrl(context, brand.tiktokUrl) },
                            border = BorderStroke(1.dp, Color(0xFF00F2FE)),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("contact_tiktok_button")
                        ) {
                            TikTokBrandBadgeIcon(size = 20.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("تيك توك", color = CrispWhite, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun OrderStepPill(
    stepNumber: String,
    title: String,
    active: Boolean,
    modifier: Modifier = Modifier
) {
    Surface(
        color = if (active) FieryOrange.copy(alpha = 0.18f) else CardSurfaceElevated.copy(alpha = 0.6f),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(
            1.dp,
            if (active) WarmGold.copy(alpha = 0.7f) else GlassBorderWhite
        ),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(18.dp)
                    .clip(CircleShape)
                    .background(if (active) WarmGold else MutedZinc),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stepNumber,
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                    fontWeight = FontWeight.Black,
                    color = CrispWhite
                )
            }
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                fontWeight = FontWeight.Bold,
                color = if (active) CrispWhite else MutedZinc,
                maxLines = 1
            )
        }
    }
}
