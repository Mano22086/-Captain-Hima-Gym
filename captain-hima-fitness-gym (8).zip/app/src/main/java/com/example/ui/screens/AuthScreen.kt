package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.GymBrandInfo
import com.example.ui.components.*
import com.example.ui.theme.*
import kotlin.math.abs

@Composable
fun AuthScreen(
    brandInfo: GymBrandInfo = GymBrandInfo(),
    onEnterWithCode: (String) -> Boolean,
    onEnterAsNewMember: () -> Unit
) {
    val context = LocalContext.current
    var subscriptionCode by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    LuxuryGymAmbientBackground {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                color = CardSurfaceDark.copy(alpha = 0.94f),
                shape = RoundedCornerShape(32.dp),
                tonalElevation = 20.dp,
                shadowElevation = 28.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 480.dp)
                    .border(
                        width = 1.5.dp,
                        brush = LuxuryGoldBorderBrush,
                        shape = RoundedCornerShape(32.dp)
                    )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Glass3DSurfaceBrush)
                        .padding(horizontal = 20.dp, vertical = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Official CAPTAIN HIMA FITNESS GYM Logo (Unaltered)
                    Box(
                        modifier = Modifier
                            .size(112.dp)
                            .clip(CircleShape)
                            .background(Color.Black)
                            .border(
                                width = 2.5.dp,
                                brush = Brush.linearGradient(
                                    listOf(FieryOrange, CrispWhite, FieryOrange)
                                ),
                                shape = CircleShape
                            )
                            .padding(6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_official_logo),
                            contentDescription = "CAPTAIN HIMA FITNESS GYM Official Logo",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // VIP MEMBERSHIP • 5.0 Google Maps Badge
                    Surface(
                        color = ObsidianBlack.copy(alpha = 0.85f),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, FieryOrange.copy(alpha = 0.7f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "VIP",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = FieryOrange
                            )
                            Column(horizontalAlignment = Alignment.Start) {
                                Text(
                                    text = "MEMBERSHIP",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = CrispWhite
                                )
                                Text(
                                    text = "5.0 ★ Google Maps",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ChampagneGold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "ابنِ أفضل نسخة منك",
                        style = MaterialTheme.typography.headlineSmall,
                        color = CrispWhite,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "BUILD YOUR BEST VERSION",
                        style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 2.sp),
                        color = FieryOrange,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Interactive 3D Glass VIP Pass Preview Card
                    Surface(
                        shape = RoundedCornerShape(24.dp),
                        color = Color.Transparent,
                        border = BorderStroke(1.5.dp, LuxuryGoldBorderBrush),
                        shadowElevation = 18.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(
                                            FieryOrange.copy(alpha = 0.24f),
                                            CardSurfaceElevated.copy(alpha = 0.95f),
                                            CardSurfaceDark
                                        )
                                    )
                                )
                                .padding(18.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "VIP PASS",
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.Black,
                                    color = FieryOrange
                                )
                                Surface(
                                    color = ObsidianBlack.copy(alpha = 0.8f),
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, GlassBorderWhite)
                                ) {
                                    Text(
                                        text = "بوابة المشتركين",
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = CrispWhite,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                                Text(
                                    text = "CAPTAIN HIMA GYM",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MutedZinc,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = subscriptionCode.ifBlank { "أدخل رمز اشتراكك" },
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = CrispWhite
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            // Dynamic QR Matrix Preview inside Corner Brackets
                            Box(
                                modifier = Modifier
                                    .size(96.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(ObsidianBlack.copy(alpha = 0.85f))
                                    .border(1.5.dp, FieryOrange.copy(alpha = 0.8f), RoundedCornerShape(14.dp))
                                    .padding(8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                DynamicQrMatrixCanvas(
                                    payload = "CAPTAIN_HIMA_VIP:${subscriptionCode.ifBlank { "PORTAL" }}",
                                    size = 76.dp,
                                    foregroundColor = CrispWhite
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Subscription Code Input Field (No hardcoded demo code example)
                    OutlinedTextField(
                        value = subscriptionCode,
                        onValueChange = {
                            subscriptionCode = it
                            errorMessage = null
                        },
                        label = { Text("رمز الاشتراك لمتابعة عضويتك") },
                        placeholder = { Text("اكتب كود الاشتراك الخاص بك") },
                        leadingIcon = {
                            Icon(Icons.Default.QrCode2, contentDescription = null, tint = FieryOrange)
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("portal_subscription_code_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = FieryOrange,
                            unfocusedBorderColor = GlassBorderWhite,
                            focusedTextColor = CrispWhite,
                            unfocusedTextColor = CrispWhite,
                            focusedContainerColor = ObsidianBlack.copy(alpha = 0.7f),
                            unfocusedContainerColor = ObsidianBlack.copy(alpha = 0.55f)
                        )
                    )

                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.error.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(
                                1.dp,
                                MaterialTheme.colorScheme.error.copy(alpha = 0.45f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = errorMessage ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                color = CrispWhite,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Enter with Subscription Code Button (3D Glass Button)
                    Button(
                        onClick = {
                            val ok = onEnterWithCode(subscriptionCode)
                            if (!ok) {
                                errorMessage = "رمز الاشتراك غير مسجل بعد. إذا كنت مشتركاً جديداً اضغط على زر (مشترك جديد) بالأسفل لحجز باقتك واستلام كودك الفريد."
                            }
                        },
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = FieryOrange,
                            contentColor = CrispWhite
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("portal_enter_with_code_button")
                    ) {
                        Icon(Icons.Default.LocalFireDepartment, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "دخول بوابة الأعضاء ومتابعة الاشتراك 🔥",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // New Member Glass Button
                    OutlinedButton(
                        onClick = onEnterAsNewMember,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.5.dp, LuxuryGoldBorderBrush),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = GlassFillWhite,
                            contentColor = CrispWhite
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("portal_new_member_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PersonAddAlt1,
                            contentDescription = null,
                            tint = FieryOrange
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "مشترك جديد • تصفح الباقات واحجز الآن",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = CrispWhite
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))
                    HorizontalDivider(color = GlassBorderWhite)
                    Spacer(modifier = Modifier.height(14.dp))

                    // Bottom Footer: Social Brand Icons + Real Club Location & Phone
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = { launchExternalUrl(context, brandInfo.googleMapsUrl) },
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .border(1.dp, FieryOrange.copy(alpha = 0.6f), CircleShape)
                            ) {
                                GoogleBrandBadgeIcon(size = 20.dp)
                            }
                            IconButton(
                                onClick = { launchExternalUrl(context, brandInfo.facebookPageUrl) },
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .border(1.dp, FacebookBlue.copy(alpha = 0.6f), CircleShape)
                            ) {
                                FacebookBrandBadgeIcon(size = 20.dp)
                            }
                            IconButton(
                                onClick = { launchExternalUrl(context, brandInfo.instagramUrl) },
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .border(1.dp, InstagramPink.copy(alpha = 0.6f), CircleShape)
                            ) {
                                InstagramBrandBadgeIcon(size = 20.dp)
                            }
                            IconButton(
                                onClick = { launchExternalUrl(context, brandInfo.tiktokUrl) },
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .border(1.dp, Color(0xFF00F2FE).copy(alpha = 0.6f), CircleShape)
                            ) {
                                TikTokBrandBadgeIcon(size = 20.dp)
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "📍 المنشية - فيصل، الجيزة",
                                style = MaterialTheme.typography.labelSmall,
                                color = CrispWhite,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "➕ ${brandInfo.plusCode}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MutedZinc
                            )
                            Text(
                                text = "📞 ${brandInfo.phoneDisplay}",
                                style = MaterialTheme.typography.labelMedium,
                                color = FieryOrange,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Deterministic crisp QR Code Matrix renderer for VIP Glass Pass & Server Verification
 */
@Composable
fun DynamicQrMatrixCanvas(
    payload: String,
    size: Dp = 110.dp,
    foregroundColor: Color = CrispWhite
) {
    Canvas(modifier = Modifier.size(size)) {
        val gridCount = 21
        val cellSize = this.size.width / gridCount
        val seed = abs(payload.hashCode())

        fun isFinderPattern(r: Int, c: Int): Boolean {
            val topLeft = r in 0..6 && c in 0..6
            val topRight = r in 0..6 && c in (gridCount - 7) until gridCount
            val bottomLeft = r in (gridCount - 7) until gridCount && c in 0..6
            return topLeft || topRight || bottomLeft
        }

        fun drawFinder(startR: Int, startC: Int) {
            for (dr in 0..6) {
                for (dc in 0..6) {
                    val isBorder = dr == 0 || dr == 6 || dc == 0 || dc == 6
                    val isCenter = dr in 2..4 && dc in 2..4
                    if (isBorder || isCenter) {
                        drawRect(
                            color = foregroundColor,
                            topLeft = Offset((startC + dc) * cellSize, (startR + dr) * cellSize),
                            size = Size(cellSize * 0.95f, cellSize * 0.95f)
                        )
                    }
                }
            }
        }

        drawFinder(0, 0)
        drawFinder(0, gridCount - 7)
        drawFinder(gridCount - 7, 0)

        for (r in 0 until gridCount) {
            for (c in 0 until gridCount) {
                if (!isFinderPattern(r, c)) {
                    val bitHash = abs((seed xor (r * 37 + c * 101) xor payload.length * 17))
                    if (bitHash % 11 < 5) {
                        drawRect(
                            color = foregroundColor,
                            topLeft = Offset(c * cellSize, r * cellSize),
                            size = Size(cellSize * 0.92f, cellSize * 0.92f)
                        )
                    }
                }
            }
        }
    }
}
