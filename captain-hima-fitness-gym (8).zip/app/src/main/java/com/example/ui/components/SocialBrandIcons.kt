package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

object SocialBrandVectors {

    /**
     * Authentic filled Google "G" logo vector (24x24 viewport)
     */
    val GoogleFilled: ImageVector by lazy {
        ImageVector.Builder(
            name = "GoogleFilled",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(
                fill = SolidColor(Color.White),
                pathFillType = PathFillType.NonZero
            ) {
                moveTo(21.35f, 11.1f)
                horizontalLineTo(12.18f)
                verticalLineTo(13.83f)
                horizontalLineTo(18.69f)
                curveTo(18.36f, 17.64f, 15.19f, 19.27f, 12.19f, 19.27f)
                curveTo(8.36f, 19.27f, 5.0f, 16.25f, 5.0f, 12.0f)
                curveTo(5.0f, 7.9f, 8.2f, 4.73f, 12.2f, 4.73f)
                curveTo(15.29f, 4.73f, 17.1f, 6.7f, 17.1f, 6.7f)
                lineTo(19.0f, 4.72f)
                curveTo(19.0f, 4.72f, 16.56f, 2.0f, 12.1f, 2.0f)
                curveTo(6.42f, 2.0f, 2.03f, 6.8f, 2.03f, 12.0f)
                curveTo(2.03f, 17.05f, 6.16f, 22.0f, 12.25f, 22.0f)
                curveTo(17.6f, 22.0f, 21.5f, 18.33f, 21.5f, 12.91f)
                curveTo(21.5f, 11.76f, 21.35f, 11.1f, 21.35f, 11.1f)
                close()
            }
        }.build()
    }

    /**
     * Authentic filled Facebook logo vector (24x24 viewport)
     */
    val FacebookFilled: ImageVector by lazy {
        ImageVector.Builder(
            name = "FacebookFilled",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(
                fill = SolidColor(Color.White),
                pathFillType = PathFillType.NonZero
            ) {
                moveTo(22.0f, 12.0f)
                curveTo(22.0f, 6.48f, 17.52f, 2.0f, 12.0f, 2.0f)
                reflectiveCurveTo(2.0f, 6.48f, 2.0f, 12.0f)
                curveTo(2.0f, 16.84f, 5.44f, 20.87f, 10.0f, 21.8f)
                verticalLineTo(15.0f)
                horizontalLineTo(8.0f)
                verticalLineTo(12.0f)
                horizontalLineTo(10.0f)
                verticalLineTo(9.5f)
                curveTo(10.0f, 7.57f, 11.57f, 6.0f, 13.5f, 6.0f)
                horizontalLineTo(16.0f)
                verticalLineTo(9.0f)
                horizontalLineTo(14.0f)
                curveTo(13.45f, 9.0f, 13.0f, 9.45f, 13.0f, 10.0f)
                verticalLineTo(12.0f)
                horizontalLineTo(16.0f)
                verticalLineTo(15.0f)
                horizontalLineTo(13.0f)
                verticalLineTo(21.95f)
                curveTo(18.05f, 21.45f, 22.0f, 17.19f, 22.0f, 12.0f)
                close()
            }
        }.build()
    }

    /**
     * Authentic filled Instagram camera logo vector (24x24 viewport)
     */
    val InstagramFilled: ImageVector by lazy {
        ImageVector.Builder(
            name = "InstagramFilled",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(
                fill = SolidColor(Color.White),
                pathFillType = PathFillType.EvenOdd
            ) {
                // Outer rounded square
                moveTo(7.8f, 2.0f)
                horizontalLineTo(16.2f)
                curveTo(19.4f, 2.0f, 22.0f, 4.6f, 22.0f, 7.8f)
                verticalLineTo(16.2f)
                curveTo(22.0f, 19.4f, 19.4f, 22.0f, 16.2f, 22.0f)
                horizontalLineTo(7.8f)
                curveTo(4.6f, 22.0f, 2.0f, 19.4f, 2.0f, 16.2f)
                verticalLineTo(7.8f)
                curveTo(2.0f, 4.6f, 4.6f, 2.0f, 7.8f, 2.0f)
                close()
                // Center lens ring cutout
                moveTo(12.0f, 7.0f)
                curveTo(9.24f, 7.0f, 7.0f, 9.24f, 7.0f, 12.0f)
                reflectiveCurveTo(9.24f, 17.0f, 12.0f, 17.0f)
                reflectiveCurveTo(17.0f, 14.76f, 17.0f, 12.0f)
                reflectiveCurveTo(14.76f, 7.0f, 12.0f, 7.0f)
                close()
                // Inner filled lens circle
                moveTo(12.0f, 9.0f)
                curveTo(13.66f, 9.0f, 15.0f, 10.34f, 15.0f, 12.0f)
                reflectiveCurveTo(13.66f, 15.0f, 12.0f, 15.0f)
                reflectiveCurveTo(9.0f, 13.66f, 9.0f, 12.0f)
                reflectiveCurveTo(10.34f, 9.0f, 12.0f, 9.0f)
                close()
                // Top-right flash dot cutout
                moveTo(17.5f, 5.25f)
                curveTo(16.81f, 5.25f, 16.25f, 5.81f, 16.25f, 6.5f)
                reflectiveCurveTo(16.81f, 7.75f, 17.5f, 7.75f)
                reflectiveCurveTo(18.75f, 7.19f, 18.75f, 6.5f)
                reflectiveCurveTo(18.19f, 5.25f, 17.5f, 5.25f)
                close()
            }
        }.build()
    }

    /**
     * Authentic filled TikTok musical note logo vector (24x24 viewport)
     */
    val TikTokFilled: ImageVector by lazy {
        ImageVector.Builder(
            name = "TikTokFilled",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(
                fill = SolidColor(Color.White),
                pathFillType = PathFillType.NonZero
            ) {
                moveTo(16.6f, 5.82f)
                curveTo(15.9f, 5.03f, 15.5f, 4.02f, 15.5f, 2.9f)
                horizontalLineTo(12.4f)
                verticalLineTo(15.3f)
                curveTo(12.38f, 16.67f, 11.27f, 17.78f, 9.9f, 17.78f)
                curveTo(8.52f, 17.78f, 7.4f, 16.66f, 7.4f, 15.28f)
                curveTo(7.4f, 13.9f, 8.52f, 12.78f, 9.9f, 12.78f)
                curveTo(10.18f, 12.78f, 10.45f, 12.83f, 10.7f, 12.92f)
                verticalLineTo(9.75f)
                curveTo(10.44f, 9.71f, 10.17f, 9.69f, 9.9f, 9.69f)
                curveTo(6.81f, 9.69f, 4.3f, 12.2f, 4.3f, 15.29f)
                curveTo(4.3f, 18.38f, 6.81f, 20.89f, 9.9f, 20.89f)
                curveTo(12.99f, 20.89f, 15.5f, 18.38f, 15.5f, 15.29f)
                verticalLineTo(9.01f)
                curveTo(16.75f, 9.91f, 18.28f, 10.44f, 19.93f, 10.44f)
                verticalLineTo(7.35f)
                curveTo(18.63f, 7.35f, 17.43f, 6.77f, 16.6f, 5.82f)
                close()
            }
        }.build()
    }
}

@Composable
fun GoogleBrandBadgeIcon(
    size: Dp = 22.dp,
    tint: Color = Color(0xFFEA4335)
) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(Color.White),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = SocialBrandVectors.GoogleFilled,
            contentDescription = "Google",
            tint = tint,
            modifier = Modifier.size(size * 0.76f)
        )
    }
}

@Composable
fun FacebookBrandBadgeIcon(
    size: Dp = 22.dp
) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(Color(0xFF1877F2)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = SocialBrandVectors.FacebookFilled,
            contentDescription = "Facebook",
            tint = Color.White,
            modifier = Modifier.size(size * 0.88f)
        )
    }
}

@Composable
fun InstagramBrandBadgeIcon(
    size: Dp = 22.dp
) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color(0xFFFEDA75),
                        Color(0xFFFA7E1E),
                        Color(0xFFD62976),
                        Color(0xFF962FBF)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = SocialBrandVectors.InstagramFilled,
            contentDescription = "Instagram",
            tint = Color.White,
            modifier = Modifier.size(size * 0.76f)
        )
    }
}

@Composable
fun TikTokBrandBadgeIcon(
    size: Dp = 22.dp
) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF00F2FE),
                        Color(0xFF111115),
                        Color(0xFFFF0050)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = SocialBrandVectors.TikTokFilled,
            contentDescription = "TikTok",
            tint = Color.White,
            modifier = Modifier.size(size * 0.78f)
        )
    }
}
