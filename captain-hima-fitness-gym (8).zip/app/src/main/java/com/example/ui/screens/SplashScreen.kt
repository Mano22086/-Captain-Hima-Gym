package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
    onSplashFinished: () -> Unit
) {
    var startAnimation by remember { mutableStateOf(false) }

    val logoAlpha by animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0f,
        animationSpec = tween(durationMillis = 1100, easing = FastOutSlowInEasing),
        label = "splash_logo_alpha"
    )
    val logoScale by animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0.82f,
        animationSpec = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
        label = "splash_logo_scale"
    )
    val progress by animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0.05f,
        animationSpec = tween(durationMillis = 2200, easing = FastOutSlowInEasing),
        label = "splash_progress"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "splash_plates")
    val plateRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 9000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "plate_rotation"
    )
    val orangeGlowPulse by infiniteTransition.animateFloat(
        initialValue = 0.22f,
        targetValue = 0.52f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "orange_glow_pulse"
    )

    LaunchedEffect(Unit) {
        startAnimation = true
        delay(2400L)
        onSplashFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF000000))
            .testTag("cinematic_splash_screen"),
        contentAlignment = Alignment.Center
    ) {
        // Ambient Fiery Orange Glow & Animated Barbell Weight Plates Around Logo
        Canvas(modifier = Modifier.fillMaxSize()) {
            val centerOffset = Offset(size.width / 2f, size.height * 0.43f)
            val glowRadius = size.minDimension * 0.52f

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        FieryOrange.copy(alpha = orangeGlowPulse),
                        FieryOrange.copy(alpha = 0.08f),
                        Color.Transparent
                    ),
                    center = centerOffset,
                    radius = glowRadius
                ),
                center = centerOffset,
                radius = glowRadius
            )

            // Outer & Inner Animated Barbell Weight Plate Notches Around the Official Logo
            val outerPlateRadius = size.minDimension * 0.34f
            val innerPlateRadius = size.minDimension * 0.29f

            rotate(degrees = plateRotation, pivot = centerOffset) {
                for (angle in listOf(0f, 90f, 180f, 270f)) {
                    drawArc(
                        color = FieryOrange.copy(alpha = 0.65f),
                        startAngle = angle,
                        sweepAngle = 52f,
                        useCenter = false,
                        topLeft = Offset(
                            centerOffset.x - outerPlateRadius,
                            centerOffset.y - outerPlateRadius
                        ),
                        size = androidx.compose.ui.geometry.Size(
                            outerPlateRadius * 2f,
                            outerPlateRadius * 2f
                        ),
                        style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }

            rotate(degrees = -plateRotation * 0.7f, pivot = centerOffset) {
                for (angle in listOf(45f, 135f, 225f, 315f)) {
                    drawArc(
                        color = CrispWhite.copy(alpha = 0.22f),
                        startAngle = angle,
                        sweepAngle = 40f,
                        useCenter = false,
                        topLeft = Offset(
                            centerOffset.x - innerPlateRadius,
                            centerOffset.y - innerPlateRadius
                        ),
                        size = androidx.compose.ui.geometry.Size(
                            innerPlateRadius * 2f,
                            innerPlateRadius * 2f
                        ),
                        style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 32.dp)
                .alpha(logoAlpha)
                .scale(logoScale),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Official Unaltered CAPTAIN HIMA FITNESS GYM Logo
            Box(
                modifier = Modifier
                    .size(210.dp)
                    .clip(CircleShape)
                    .background(Color.Black)
                    .border(
                        width = 2.dp,
                        brush = Brush.linearGradient(
                            listOf(
                                FieryOrange,
                                CrispWhite.copy(alpha = 0.6f),
                                FieryOrange
                            )
                        ),
                        shape = CircleShape
                    )
                    .padding(10.dp),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_official_logo),
                    contentDescription = "CAPTAIN HIMA FITNESS GYM Official Logo",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(CircleShape)
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            Text(
                text = "CAPTAIN HIMA FITNESS GYM",
                style = MaterialTheme.typography.titleLarge.copy(letterSpacing = 2.sp),
                fontWeight = FontWeight.Black,
                color = CrispWhite,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "BUILD YOUR BEST VERSION",
                style = MaterialTheme.typography.labelLarge.copy(
                    letterSpacing = 3.5.sp,
                    fontSize = 13.sp
                ),
                fontWeight = FontWeight.ExtraBold,
                color = FieryOrange,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(36.dp))

            // Professional 3D Glass Loading Progress Bar
            Column(
                modifier = Modifier.width(220.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                LinearProgressIndicator(
                    progress = { progress },
                    color = FieryOrange,
                    trackColor = CrispWhite.copy(alpha = 0.12f),
                    strokeCap = StrokeCap.Round,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(50))
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "جاري التحميل ...",
                    style = MaterialTheme.typography.labelMedium,
                    color = MutedZinc
                )
            }
        }
    }
}
