package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.model.*
import com.example.ui.theme.*
import com.example.viewmodel.BookingModalUiState

fun launchExternalUrl(context: Context, url: String) {
    try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    } catch (_: Exception) {
    }
}

fun launchPhoneDialer(context: Context, phone: String) {
    try {
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    } catch (_: Exception) {
    }
}

fun shareTextContent(context: Context, title: String, text: String) {
    try {
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_TEXT, text)
        }
        val chooser = Intent.createChooser(sendIntent, "مشاركة عبر").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    } catch (_: Exception) {
    }
}

@Composable
fun LuxuryGymAmbientBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBlack)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            // Top-right fiery ambient glow orb
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        FieryOrange.copy(alpha = 0.16f),
                        Color.Transparent
                    ),
                    center = Offset(size.width * 0.85f, size.height * 0.08f),
                    radius = size.width * 0.65f
                ),
                center = Offset(size.width * 0.85f, size.height * 0.08f),
                radius = size.width * 0.65f
            )
            // Mid-left royal gold ambient glow orb
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        WarmGold.copy(alpha = 0.10f),
                        Color.Transparent
                    ),
                    center = Offset(size.width * 0.12f, size.height * 0.45f),
                    radius = size.width * 0.6f
                ),
                center = Offset(size.width * 0.12f, size.height * 0.45f),
                radius = size.width * 0.6f
            )
        }
        content()
    }
}

@Composable
fun CaptainHimaLogoAvatar(
    logoUrl: String,
    size: Dp = 48.dp,
    borderWidth: Dp = 2.dp
) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(ObsidianBlack)
            .border(
                width = borderWidth,
                brush = Brush.linearGradient(listOf(FieryOrange, WarmGold, FieryOrange)),
                shape = CircleShape
            )
            .padding(2.dp),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_official_logo),
            contentDescription = "CAPTAIN HIMA FITNESS GYM Official Logo",
            modifier = Modifier
                .fillMaxSize()
                .clip(CircleShape),
            contentScale = ContentScale.Crop
        )
    }
}

@Composable
fun PulsingBookNowButton(
    text: String = "احجز الآن 🔥",
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = "pulsing_book_now_button"
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_cta")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale_pulse"
    )

    Surface(
        onClick = onClick,
        modifier = modifier
            .scale(scale)
            .heightIn(min = 48.dp)
            .testTag(testTag),
        shape = RoundedCornerShape(50),
        color = Color.Transparent,
        shadowElevation = 10.dp
    ) {
        Row(
            modifier = Modifier
                .background(
                    brush = Brush.horizontalGradient(
                        colors = listOf(FieryOrange, Color(0xFFFF8800))
                    ),
                    shape = RoundedCornerShape(50)
                )
                .border(
                    width = 1.dp,
                    brush = Brush.horizontalGradient(
                        colors = listOf(ChampagneGold.copy(alpha = 0.8f), Color.Transparent)
                    ),
                    shape = RoundedCornerShape(50)
                )
                .padding(horizontal = 18.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.LocalFireDepartment,
                contentDescription = null,
                tint = ChampagneGold,
                modifier = Modifier.size(19.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.ExtraBold,
                color = CrispWhite
            )
        }
    }
}

@Composable
fun StickyGymTopHeader(
    brandInfo: GymBrandInfo,
    activeSubscriptionCode: String? = null,
    unreadNotificationsCount: Int = 0,
    onSubscriptionCodeClick: () -> Unit = {},
    onNotificationsClick: () -> Unit = {},
    onAccountClick: () -> Unit = {},
    onBookNowClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Surface(
            color = CardSurfaceDark.copy(alpha = 0.94f),
            tonalElevation = 12.dp,
            shadowElevation = 16.dp,
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    width = 1.2.dp,
                    brush = Glass3DHighlightBrush,
                    shape = RoundedCornerShape(24.dp)
                )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Glass3DSurfaceBrush)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    CaptainHimaLogoAvatar(
                        logoUrl = brandInfo.officialLogoUrl,
                        size = 44.dp,
                        borderWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = brandInfo.nameAr,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = CrispWhite,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Surface(
                                color = FieryOrange.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(50),
                                border = BorderStroke(1.dp, FieryOrange.copy(alpha = 0.65f))
                            ) {
                                Text(
                                    text = "★ ${brandInfo.ratingScore}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = FieryOrange,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(if (activeSubscriptionCode != null) EmeraldSuccess else FieryOrange)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (activeSubscriptionCode != null) {
                                    "VIP PASS: #$activeSubscriptionCode"
                                } else {
                                    "CAPTAIN HIMA FITNESS GYM"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = if (activeSubscriptionCode != null) EmeraldSuccess else MutedZinc,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(6.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Notification Bell with unread badge
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(CardSurfaceElevated)
                            .border(1.dp, GlassBorderWhite, CircleShape)
                            .clickable { onNotificationsClick() }
                            .testTag("header_notifications_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "الإشعارات",
                            tint = if (unreadNotificationsCount > 0) FieryOrange else CrispWhite,
                            modifier = Modifier.size(20.dp)
                        )
                        if (unreadNotificationsCount > 0) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(6.dp)
                                    .size(9.dp)
                                    .clip(CircleShape)
                                    .background(FieryOrange)
                            )
                        }
                    }

                    // Account / Settings button
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(CardSurfaceElevated)
                            .border(1.dp, GlassBorderWhite, CircleShape)
                            .clickable { onAccountClick() }
                            .testTag("header_account_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "حسابي والإعدادات",
                            tint = CrispWhite,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Surface(
                        onClick = onSubscriptionCodeClick,
                        shape = RoundedCornerShape(50),
                        color = if (activeSubscriptionCode != null) {
                            EmeraldSuccess.copy(alpha = 0.16f)
                        } else {
                            FieryOrange.copy(alpha = 0.16f)
                        },
                        border = BorderStroke(
                            width = 1.dp,
                            color = if (activeSubscriptionCode != null) EmeraldSuccess else FieryOrange
                        ),
                        modifier = Modifier
                            .heightIn(min = 40.dp)
                            .testTag("header_subscription_code_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = if (activeSubscriptionCode != null) Icons.Default.Verified else Icons.Default.Key,
                                contentDescription = "كود الاشتراك",
                                tint = if (activeSubscriptionCode != null) EmeraldSuccess else FieryOrange,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = activeSubscriptionCode ?: "كود الاشتراك",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (activeSubscriptionCode != null) EmeraldSuccess else CrispWhite
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StoryRingsSection(
    stories: List<GymStory>,
    onStoryClick: (Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp, bottom = 10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(FieryOrange.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Whatshot,
                        contentDescription = null,
                        tint = FieryOrange,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "استوري الجيم المباشر (Reels)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = CrispWhite
                    )
                }
            }
            Surface(
                color = WarmGold.copy(alpha = 0.14f),
                shape = RoundedCornerShape(50),
                border = BorderStroke(1.dp, WarmGold.copy(alpha = 0.4f))
            ) {
                Text(
                    text = "تيك توك الجيم 🔥",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = WarmGold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Modern Vertical Reel Preview Cards instead of basic flat circles
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.testTag("home_story_rings_row")
        ) {
            itemsIndexed(stories) { index, story ->
                val ringBrush = if (story.isViewed) {
                    Brush.linearGradient(listOf(GlassBorderWhite, SubtleZinc))
                } else {
                    Brush.linearGradient(listOf(FieryOrange, WarmGold, LikeCrimson))
                }

                Box(
                    modifier = Modifier
                        .width(114.dp)
                        .height(162.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .border(2.dp, ringBrush, RoundedCornerShape(20.dp))
                        .clickable { onStoryClick(index) }
                        .testTag("story_ring_$index")
                ) {
                    Image(
                        painter = painterResource(id = story.drawableRes),
                        contentDescription = story.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                    val storyRingScrimAlpha = if (AppThemeController.isDarkMode) 0.45f else 0.16f
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Transparent,
                                        Color.Transparent,
                                        ObsidianBlack.copy(alpha = storyRingScrimAlpha)
                                    )
                                )
                            )
                    )

                    // Top LIVE + Likes Pill
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.TopCenter)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = FieryOrange,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "REEL",
                                style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.sp),
                                fontWeight = FontWeight.ExtraBold,
                                color = CrispWhite,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(ObsidianBlack.copy(alpha = 0.65f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = null,
                                tint = LikeCrimson,
                                modifier = Modifier.size(10.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "${story.likesCount}",
                                style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.sp),
                                color = CrispWhite,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Center Play Circle
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .align(Alignment.Center)
                            .clip(CircleShape)
                            .background(ObsidianBlack.copy(alpha = 0.55f))
                            .border(1.dp, WarmGold.copy(alpha = 0.8f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = CrispWhite,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    // Bottom Title
                    Text(
                        text = story.badgeText.substringBefore("•").trim(),
                        style = MaterialTheme.typography.labelLarge.copy(fontSize = 12.sp),
                        fontWeight = FontWeight.ExtraBold,
                        color = CrispWhite,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                            .padding(horizontal = 8.dp, vertical = 10.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun LuxuryGlassDataField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    accentColor: Color = FieryOrange,
    singleLine: Boolean = true,
    maxLines: Int = 1,
    badgeText: String? = null,
    testTag: String? = null
) {
    val isFilled = value.isNotBlank()
    Surface(
        color = CardSurfaceElevated.copy(alpha = 0.88f),
        shape = RoundedCornerShape(20.dp),
        shadowElevation = if (isFilled) 12.dp else 4.dp,
        modifier = modifier
            .fillMaxWidth()
            .border(
                width = if (isFilled) 1.5.dp else 1.dp,
                brush = if (isFilled) LuxuryGoldBorderBrush else SubtleGlassBorderBrush,
                shape = RoundedCornerShape(20.dp)
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Glass3DSurfaceBrush)
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(RoundedCornerShape(9.dp))
                            .background(accentColor.copy(alpha = 0.18f))
                            .border(1.dp, accentColor.copy(alpha = 0.55f), RoundedCornerShape(9.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = accentColor,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (isFilled) WarmGold else CrispWhite
                    )
                }

                if (badgeText != null) {
                    Surface(
                        color = if (isFilled) EmeraldSuccess.copy(alpha = 0.16f) else accentColor.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(
                            0.8.dp,
                            if (isFilled) EmeraldSuccess.copy(alpha = 0.6f) else accentColor.copy(alpha = 0.45f)
                        )
                    ) {
                        Text(
                            text = if (isFilled) "مكتمل ✓" else badgeText,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isFilled) EmeraldSuccess else accentColor,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = value,
                onValueChange = onValueChange,
                placeholder = {
                    Text(
                        text = placeholder,
                        color = MutedZinc.copy(alpha = 0.7f),
                        style = MaterialTheme.typography.bodyMedium
                    )
                },
                singleLine = singleLine,
                maxLines = maxLines,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .then(if (testTag != null) Modifier.testTag(testTag) else Modifier),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = ObsidianBlack.copy(alpha = 0.65f),
                    unfocusedContainerColor = ObsidianBlack.copy(alpha = 0.45f),
                    focusedBorderColor = accentColor,
                    unfocusedBorderColor = GlassBorderWhite.copy(alpha = 0.6f),
                    focusedTextColor = CrispWhite,
                    unfocusedTextColor = CrispWhite,
                    cursorColor = accentColor
                )
            )
        }
    }
}

@Composable
fun Selectable3DGlassPackageCard(
    pkg: MembershipPackage,
    isSelected: Boolean,
    onSelect: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bgDrawable = remember(pkg.durationMonths) {
        when (pkg.durationMonths) {
            1 -> R.drawable.img_gym_weights_1794007816793
            3 -> R.drawable.img_gym_kickboxing_1794007819773
            6 -> R.drawable.img_gym_spa_1794007818150
            else -> R.drawable.img_gym_zumba_1794007817343
        }
    }
    val durationUnitAr = if (pkg.durationMonths == 1) "شهر" else "شهور"

    Surface(
        onClick = onSelect,
        color = CardSurfaceDark,
        shape = RoundedCornerShape(24.dp),
        shadowElevation = if (isSelected) 20.dp else 8.dp,
        modifier = modifier
            .fillMaxWidth()
            .border(
                width = if (isSelected) 2.2.dp else 1.dp,
                brush = if (isSelected) {
                    Brush.linearGradient(listOf(FieryOrange, WarmGold, FieryOrange))
                } else {
                    SubtleGlassBorderBrush
                },
                shape = RoundedCornerShape(24.dp)
            )
            .testTag("selectable_package_card_${pkg.id}")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 152.dp)
        ) {
            // Clear athletic gym photo on the card without heavy haze
            Image(
                painter = painterResource(id = bgDrawable),
                contentDescription = pkg.title,
                contentScale = ContentScale.Crop,
                alpha = if (isSelected) 0.62f else 0.48f,
                modifier = Modifier.matchParentSize()
            )

            // Light gradient overlay (minimal haze in Dark Mode, ultra-clean in Light Mode)
            val overlayStartAlpha = if (AppThemeController.isDarkMode) 0.66f else 0.48f
            val overlayMidAlpha = if (AppThemeController.isDarkMode) 0.50f else 0.32f
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                ObsidianBlack.copy(alpha = overlayStartAlpha),
                                CardSurfaceDark.copy(alpha = overlayMidAlpha),
                                Color.Transparent
                            )
                        )
                    )
            )

            // Glowing top-right radial highlight when selected
            if (isSelected) {
                Canvas(modifier = Modifier.matchParentSize()) {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                FieryOrange.copy(alpha = 0.25f),
                                Color.Transparent
                            ),
                            center = Offset(size.width * 0.85f, size.height * 0.2f),
                            radius = size.width * 0.55f
                        )
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                // Top Row: Badge + Selection Indicator Pill
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            color = if (pkg.isVip) WarmGold else FieryOrange,
                            shape = RoundedCornerShape(50)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = if (pkg.isVip) Icons.Default.WorkspacePremium else Icons.Default.LocalFireDepartment,
                                    contentDescription = null,
                                    tint = CrispWhite,
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = pkg.badgeText,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Black,
                                    color = CrispWhite
                                )
                            }
                        }

                        Surface(
                            color = EmeraldSuccess.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(50),
                            border = BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.55f))
                        ) {
                            Text(
                                text = "خصم ${pkg.discountPercent}%",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = EmeraldSuccess,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    // Selection Pill
                    Surface(
                        color = if (isSelected) FieryOrange else CardSurfaceElevated.copy(alpha = 0.85f),
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(
                            1.dp,
                            if (isSelected) WarmGold else GlassBorderWhite
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = if (isSelected) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                contentDescription = null,
                                tint = if (isSelected) CrispWhite else MutedZinc,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = if (isSelected) "الباقة المختارة" else "اختر الباقة",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (isSelected) CrispWhite else MutedZinc
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Main Content Row: Duration + Perks + Price Capsule (Matching Reference Image)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Right/Start side: Giant Duration Badge + Title
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            color = ObsidianBlack.copy(alpha = 0.78f),
                            shape = RoundedCornerShape(18.dp),
                            border = BorderStroke(
                                1.5.dp,
                                if (isSelected) WarmGold else FieryOrange.copy(alpha = 0.55f)
                            ),
                            modifier = Modifier.size(width = 70.dp, height = 78.dp)
                        ) {
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = "${pkg.durationMonths}",
                                    style = MaterialTheme.typography.headlineLarge.copy(fontSize = 28.sp),
                                    fontWeight = FontWeight.Black,
                                    color = if (isSelected) WarmGold else CrispWhite
                                )
                                Text(
                                    text = durationUnitAr,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = FieryOrange
                                )
                            }
                        }

                        // Perks List with glowing checkmarks
                        Column(
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = pkg.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = CrispWhite
                            )
                            pkg.perks.take(3).forEach { perk ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Done,
                                        contentDescription = null,
                                        tint = WarmGold,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = perk,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MutedZinc,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Price Capsule Pill (Matching the glowing gold/orange price pill in the reference image)
                    Column(
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(
                            text = "${pkg.originalPriceEgp} ج.م",
                            style = MaterialTheme.typography.labelSmall.copy(
                                textDecoration = TextDecoration.LineThrough
                            ),
                            color = MutedZinc
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Surface(
                            color = Color.Transparent,
                            shape = RoundedCornerShape(50),
                            modifier = Modifier
                                .background(
                                    brush = if (isSelected) {
                                        Brush.horizontalGradient(listOf(FieryOrange, WarmGold))
                                    } else {
                                        Brush.horizontalGradient(
                                            listOf(
                                                FieryOrange.copy(alpha = 0.25f),
                                                WarmGold.copy(alpha = 0.20f)
                                            )
                                        )
                                    },
                                    shape = RoundedCornerShape(50)
                                )
                                .border(
                                    width = 1.dp,
                                    color = if (isSelected) CrispWhite.copy(alpha = 0.6f) else WarmGold.copy(alpha = 0.6f),
                                    shape = RoundedCornerShape(50)
                                )
                        ) {
                            Text(
                                text = "${pkg.discountedPriceEgp} ج.م",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = if (isSelected) CrispWhite else WarmGold,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Selectable3DGlassServiceCard(
    title: String,
    subtitle: String,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    Surface(
        onClick = onSelect,
        color = CardSurfaceDark,
        shape = RoundedCornerShape(20.dp),
        shadowElevation = if (isSelected) 14.dp else 4.dp,
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                brush = if (isSelected) LuxuryGoldBorderBrush else SubtleGlassBorderBrush,
                shape = RoundedCornerShape(20.dp)
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Glass3DSurfaceBrush)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) FieryOrange else FieryOrange.copy(alpha = 0.16f))
                        .border(1.dp, if (isSelected) WarmGold else FieryOrange.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.FitnessCenter,
                        contentDescription = null,
                        tint = if (isSelected) CrispWhite else FieryOrange,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = CrispWhite
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSelected) WarmGold else MutedZinc
                    )
                }
            }

            Icon(
                imageVector = if (isSelected) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                contentDescription = null,
                tint = if (isSelected) FieryOrange else MutedZinc,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InteractiveBookingModal(
    modalState: BookingModalUiState,
    packages: List<MembershipPackage>,
    classes: List<GroupClassItem>,
    onDismiss: () -> Unit,
    onSubmitBooking: (
        fullName: String,
        phone: String,
        genderCategory: String,
        bookingType: String,
        selectedItemName: String,
        preferredDateTime: String,
        notes: String
    ) -> Unit,
    onConfirmViaWhatsApp: (BookingRecord) -> Unit,
    onActivateBookedCode: (String) -> Unit = {}
) {
    if (!modalState.isOpen) return

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .heightIn(max = 760.dp)
                .border(1.8.dp, LuxuryGoldBorderBrush, RoundedCornerShape(30.dp)),
            shape = RoundedCornerShape(30.dp),
            color = ObsidianBlack,
            shadowElevation = 28.dp
        ) {
            val confirmed = modalState.confirmedRecord
            if (confirmed != null) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Glass3DSurfaceBrush)
                        .verticalScroll(rememberScrollState())
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(82.dp)
                            .clip(CircleShape)
                            .background(FieryOrange.copy(alpha = 0.18f))
                            .border(2.dp, LuxuryGoldBorderBrush, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.WorkspacePremium,
                            contentDescription = null,
                            tint = WarmGold,
                            modifier = Modifier.size(44.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "تم تسجيل طلبك بنجاح، اشتراكك في انتظار تأكيد الإدارة.",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = CrispWhite,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "تم إصدار كود اشتراكك العشوائي الفريد وحفظ الطلب برقم (${confirmed.orderNumber}) بحالة PENDING.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MutedZinc,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Surface(
                        color = CardSurfaceElevated,
                        shape = RoundedCornerShape(24.dp),
                        border = BorderStroke(1.5.dp, LuxuryGoldBorderBrush),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .background(Glass3DSurfaceBrush)
                                .padding(18.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "كود الاشتراك العشوائي الفريد الخاص بك",
                                style = MaterialTheme.typography.labelMedium,
                                color = WarmGold,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "#${confirmed.referenceCode}",
                                style = MaterialTheme.typography.headlineLarge.copy(letterSpacing = 2.sp),
                                fontWeight = FontWeight.Black,
                                color = FieryOrange
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Surface(
                                color = WarmGold.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(50),
                                border = BorderStroke(1.dp, WarmGold.copy(alpha = 0.5f))
                            ) {
                                Text(
                                    text = "الحالة: PENDING (بانتظار تفعيل الإدارة)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = WarmGold,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                                )
                            }
                            HorizontalDivider(
                                modifier = Modifier.padding(vertical = 12.dp),
                                color = GlassBorderWhite
                            )
                            BookingSummaryRow("رقم الطلب:", confirmed.orderNumber)
                            BookingSummaryRow("الاسم:", confirmed.fullName)
                            BookingSummaryRow("الهاتف:", confirmed.phone)
                            BookingSummaryRow("القسم:", confirmed.genderCategory)
                            BookingSummaryRow("الباقة:", confirmed.selectedItemName)
                            BookingSummaryRow("السعر:", "${confirmed.priceEgp} ج.م")
                            BookingSummaryRow("وقت الحجز:", confirmed.createdAt)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { onConfirmViaWhatsApp(confirmed) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("modal_confirm_whatsapp_button"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = WhatsAppGreen,
                            contentColor = CrispWhite
                        )
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "إرسال رسالة الطلب عبر واتساب 💬",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = { onActivateBookedCode(confirmed.referenceCode) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("modal_activate_code_button"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = FieryOrange,
                            contentColor = CrispWhite
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Key,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "فتح بطاقة العضوية ومتابعة الطلب (${confirmed.referenceCode}) 🔑",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("إغلاق والعودة للتطبيق", color = MutedZinc)
                    }
                }
            } else {
                var fullName by remember { mutableStateOf("") }
                var phone by remember { mutableStateOf("") }
                var genderCategory by remember(modalState.genderCategory) {
                    mutableStateOf(modalState.genderCategory)
                }
                var bookingType by remember(modalState.bookingType) {
                    mutableStateOf(modalState.bookingType)
                }

                val packageOptions = remember(packages) {
                    packages.map { "${it.title} - ${it.discountedPriceEgp} ج.م بدلاً من ${it.originalPriceEgp} ج.م" }
                }
                val classOptions = remember(classes) {
                    classes.map { "${it.nameAr} (${it.daysAr})" } + listOf(
                        "جلسة السبا والجاكوزي والساونا",
                        "التدريب الشخصي والتغذية (Personal Training)"
                    )
                }

                val currentOptions = if (bookingType == "اشتراك باقة") packageOptions else classOptions
                var selectedItemName by remember(modalState.selectedItemName, bookingType) {
                    mutableStateOf(
                        currentOptions.firstOrNull { it.contains(modalState.selectedItemName.take(10)) }
                            ?: currentOptions.firstOrNull()
                            ?: modalState.selectedItemName
                    )
                }
                var preferredDateTime by remember { mutableStateOf("اليوم - الساعة 7:00 مساءً") }
                var notes by remember { mutableStateOf("") }
                var showError by remember { mutableStateOf(false) }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Glass3DSurfaceBrush)
                        .verticalScroll(rememberScrollState())
                        .padding(20.dp)
                ) {
                    // Luxury 3D Glass Header Banner
                    Surface(
                        color = CardSurfaceElevated.copy(alpha = 0.9f),
                        shape = RoundedCornerShape(22.dp),
                        border = BorderStroke(1.dp, LuxuryGoldBorderBrush),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.img_official_logo),
                                    contentDescription = "CAPTAIN HIMA FITNESS GYM",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .border(1.5.dp, FieryOrange, CircleShape)
                                )
                                Column {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.WorkspacePremium,
                                            contentDescription = null,
                                            tint = WarmGold,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            text = "بوابة الاشتراك والحجز الملكي VIP",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Black,
                                            color = CrispWhite
                                        )
                                    }
                                    Text(
                                        text = "إصدار كود اشتراك عشوائي فوري + خصم 50% حصري",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = FieryOrange,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            IconButton(onClick = onDismiss) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "إغلاق",
                                    tint = MutedZinc
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Step 1: Member Data Entry Pods
                    Text(
                        text = "أولاً: بيانات المشترك الأساسية",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = WarmGold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    LuxuryGlassDataField(
                        value = fullName,
                        onValueChange = {
                            fullName = it
                            showError = false
                        },
                        label = "الاسم الثلاثي للمشترك",
                        placeholder = "اكتب اسمك الكامل كما سيظهر على بطاقة VIP",
                        icon = Icons.Default.Person,
                        accentColor = FieryOrange,
                        badgeText = "مطلوب *",
                        testTag = "booking_name_input"
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    LuxuryGlassDataField(
                        value = phone,
                        onValueChange = {
                            phone = it
                            showError = false
                        },
                        label = "رقم الموبايل / واتساب لتأكيد التفعيل",
                        placeholder = "010XXXXXXXX",
                        icon = Icons.Default.PhoneAndroid,
                        accentColor = WarmGold,
                        badgeText = "مطلوب *",
                        testTag = "booking_phone_input"
                    )

                    if (showError) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            color = LikeCrimson.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, LikeCrimson),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "⚠️ يرجى إدخال الاسم الثلاثي ورقم الهاتف لإصدار كود الاشتراك",
                                color = CrispWhite,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Step 2: Department & Booking Type 3D Glass Switchers
                    Text(
                        text = "ثانياً: القسم ونوع العضوية",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = WarmGold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        listOf("قسم الرجال", "قسم السيدات").forEach { cat ->
                            val selected = genderCategory == cat
                            Surface(
                                onClick = { genderCategory = cat },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(16.dp),
                                color = if (selected) FieryOrange else CardSurfaceElevated,
                                border = BorderStroke(
                                    width = if (selected) 1.8.dp else 1.dp,
                                    color = if (selected) WarmGold else GlassBorderWhite
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 12.dp, horizontal = 10.dp),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (cat == "قسم الرجال") "💪 قسم الرجال" else "💃 قسم السيدات",
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (selected) CrispWhite else MutedZinc
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        listOf("اشتراك باقة", "حجز حصة جماعية").forEach { type ->
                            val selected = bookingType == type
                            Surface(
                                onClick = {
                                    bookingType = type
                                    val newPool = if (type == "اشتراك باقة") packageOptions else classOptions
                                    selectedItemName = newPool.firstOrNull() ?: ""
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(16.dp),
                                color = if (selected) WarmGold.copy(alpha = 0.22f) else CardSurfaceElevated,
                                border = BorderStroke(
                                    width = if (selected) 1.8.dp else 1.dp,
                                    color = if (selected) WarmGold else GlassBorderWhite
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 12.dp, horizontal = 10.dp),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (type == "اشتراك باقة") "👑 باقات العضوية VIP" else "⚡ الحصص والسبا",
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (selected) WarmGold else MutedZinc
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Step 3: Redesigned 3D Glass Package Selection Cards
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (bookingType == "اشتراك باقة") "ثالثاً: اختر باقة العضوية (بطاقات 3D Glass)" else "ثالثاً: اختر الحصة أو الخدمة",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = WarmGold
                        )
                        Surface(
                            color = FieryOrange.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(50),
                            border = BorderStroke(1.dp, FieryOrange.copy(alpha = 0.5f))
                        ) {
                            Text(
                                text = "خصم 50% 🔥",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = FieryOrange,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (bookingType == "اشتراك باقة") {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            packages.forEach { pkg ->
                                val optionString = "${pkg.title} - ${pkg.discountedPriceEgp} ج.م بدلاً من ${pkg.originalPriceEgp} ج.م"
                                val isSelected = selectedItemName == optionString || selectedItemName.contains(pkg.title)
                                Selectable3DGlassPackageCard(
                                    pkg = pkg,
                                    isSelected = isSelected,
                                    onSelect = { selectedItemName = optionString }
                                )
                            }
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            classOptions.forEach { option ->
                                val isSelected = selectedItemName == option
                                Selectable3DGlassServiceCard(
                                    title = option.substringBefore("(").trim(),
                                    subtitle = option.substringAfter("(", "حصة تدريبية متكاملة").removeSuffix(")"),
                                    isSelected = isSelected,
                                    onSelect = { selectedItemName = option }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Step 4: Schedule & Notes Glass Pods
                    LuxuryGlassDataField(
                        value = preferredDateTime,
                        onValueChange = { preferredDateTime = it },
                        label = "موعد بدء الاشتراك أو الحضور المفضل",
                        placeholder = "مثال: اليوم - الساعة 7:00 مساءً",
                        icon = Icons.Default.CalendarMonth,
                        accentColor = WarmGold,
                        badgeText = "الموعد"
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    LuxuryGlassDataField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = "ملاحظات إضافية للكابتن (اختياري)",
                        placeholder = "مثال: أرغب في برنامج تدريبي وغذائي خاص",
                        icon = Icons.Default.EditNote,
                        accentColor = FieryOrange,
                        singleLine = false,
                        maxLines = 3
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Auto-generated Code Guarantee Pill
                    Surface(
                        color = FieryOrange.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, FieryOrange.copy(alpha = 0.45f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Key,
                                contentDescription = null,
                                tint = WarmGold,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "سيصدر لك النظام كود اشتراك عشوائي وفريد فوراً بعد الضغط على إرسال الطلب",
                                style = MaterialTheme.typography.labelSmall,
                                color = CrispWhite,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    PulsingBookNowButton(
                        text = "إرسال الطلب وإصدار كود الاشتراك العشوائي 🔥",
                        onClick = {
                            if (fullName.isBlank() || phone.isBlank()) {
                                showError = true
                            } else {
                                onSubmitBooking(
                                    fullName,
                                    phone,
                                    genderCategory,
                                    bookingType,
                                    selectedItemName,
                                    preferredDateTime,
                                    notes
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "booking_submit_button"
                    )
                }
            }
        }
    }
}

@Composable
private fun BookingSummaryRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = MutedZinc)
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = CrispWhite,
            modifier = Modifier.padding(start = 12.dp)
        )
    }
}

@Composable
fun SubscriptionCodeEntryDialog(
    isOpen: Boolean,
    onDismiss: () -> Unit,
    onVerifyCode: (String) -> Boolean
) {
    if (!isOpen) return

    var codeInput by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf<String?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .border(1.5.dp, LuxuryGoldBorderBrush, RoundedCornerShape(28.dp)),
            shape = RoundedCornerShape(28.dp),
            color = CardSurfaceDark,
            shadowElevation = 24.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Glass3DSurfaceBrush)
                    .padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Key,
                            contentDescription = null,
                            tint = FieryOrange,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = "إدخال كود الاشتراك 🔑",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = CrispWhite
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = MutedZinc)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "أدخل كود الاشتراك الفريد الصادر من الإدارة أو من استمارة الحجز لعرض بطاقة العضوية الثلاثية الأبعاد وحالة الاشتراك والأيام المتبقية.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MutedZinc,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = codeInput,
                    onValueChange = {
                        codeInput = it.uppercase()
                        errorText = null
                    },
                    label = { Text("اكتب كود الاشتراك") },
                    placeholder = { Text("أدخل الكود الفريد الخاص بك") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = FieryOrange,
                        unfocusedBorderColor = GlassBorderWhite,
                        focusedTextColor = CrispWhite,
                        unfocusedTextColor = CrispWhite
                    )
                )

                if (errorText != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = errorText ?: "",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.error,
                        textAlign = TextAlign.Center
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val ok = onVerifyCode(codeInput)
                        if (!ok) {
                            errorText = "كود الاشتراك غير موجود. تأكد من كتابة الكود الصحيح أو سجل طلب اشتراك جديد."
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = FieryOrange,
                        contentColor = CrispWhite
                    )
                ) {
                    Text(
                        text = "متابعة اشتراكي الآن 🔥",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }
        }
    }
}

