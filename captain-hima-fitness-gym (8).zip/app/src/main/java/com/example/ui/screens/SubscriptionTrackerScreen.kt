package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.model.*
import com.example.ui.components.shareTextContent
import com.example.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun SubscriptionTrackerScreen(
    cmsState: CaptainHimaCmsState,
    onActivateCode: (String) -> Boolean,
    onClearActiveCode: () -> Unit,
    onRenewSubscription: (String, MembershipPackage) -> Unit,
    onConfirmRenewalViaWhatsApp: (MemberSubscription, MembershipPackage) -> Unit,
    onOpenNewBooking: (String, String, String) -> Unit
) {
    val context = LocalContext.current
    val activeCode = cmsState.activeSubscriptionCode
    val activeSubscription = remember(cmsState.subscriptions, activeCode) {
        if (activeCode.isNullOrBlank()) null
        else cmsState.subscriptions.firstOrNull { it.code.equals(activeCode, ignoreCase = true) }
    }

    // Real-time UTC clock ticker so remaining days update live
    var nowUtcMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(15_000L)
            nowUtcMillis = System.currentTimeMillis()
        }
    }

    var inputCode by remember { mutableStateOf("") }
    var codeError by remember { mutableStateOf<String?>(null) }
    var renewalBannerMessage by remember { mutableStateOf<String?>(null) }
    var isSwitchingCode by remember { mutableStateOf(false) }
    var showQrVerificationDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("subscription_tracker_screen"),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        if (activeSubscription == null || isSwitchingCode) {
            item {
                SubscriptionCodeLookupCard(
                    inputCode = inputCode,
                    onInputCodeChange = {
                        inputCode = it
                        codeError = null
                    },
                    codeError = codeError,
                    recentBookings = cmsState.bookings,
                    hasActiveSub = activeSubscription != null,
                    onCancelSwitch = { isSwitchingCode = false },
                    onSubmitCode = { codeToSubmit ->
                        val ok = onActivateCode(codeToSubmit)
                        if (ok) {
                            codeError = null
                            isSwitchingCode = false
                        } else {
                            codeError = "كود الاشتراك غير مسجل. أدخل الكود الصحيح المستلم عند الحجز أو اشترك الآن في إحدى الباقات."
                        }
                    },
                    onBookNewPackage = {
                        onOpenNewBooking(
                            "اشتراك باقة",
                            "باقة 3 شهور - 1,250 ج.م (الأكثر طلباً)",
                            "قسم الرجال"
                        )
                    }
                )
            }
        }

        if (activeSubscription != null) {
            val effectiveStatus = activeSubscription.computeEffectiveStatus(nowUtcMillis)
            val realRemainingDays = activeSubscription.computeRealTimeRemainingDays(nowUtcMillis)

            // Status Banner (PENDING / REJECTED / FROZEN / EXPIRED)
            item {
                SubscriptionServerStatusBanner(
                    status = effectiveStatus,
                    orderNumber = activeSubscription.orderNumber
                )
            }

            // Celebratory Renewal Banner if just renewed
            item {
                AnimatedVisibility(visible = renewalBannerMessage != null) {
                    Surface(
                        color = EmeraldSuccess.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.5.dp, EmeraldSuccess),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Verified,
                                contentDescription = null,
                                tint = EmeraldSuccess,
                                modifier = Modifier.size(28.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "تم إرسال طلب تجديد الاشتراك! 🎉",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = CrispWhite
                                )
                                Text(
                                    text = renewalBannerMessage ?: "",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = ChampagneGold
                                )
                            }
                            IconButton(onClick = { renewalBannerMessage = null }) {
                                Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = MutedZinc)
                            }
                        }
                    }
                }
            }

            // 1. Interactive 3D Glass VIP Pass Card (Front & Back + QR Scanner Verification)
            item {
                Interactive3DGlassVipPassCard(
                    subscription = activeSubscription,
                    effectiveStatus = effectiveStatus,
                    realRemainingDays = realRemainingDays,
                    onOpenQrVerifier = { showQrVerificationDialog = true },
                    onSwitchCodeClick = {
                        inputCode = ""
                        codeError = null
                        isSwitchingCode = true
                    },
                    onLogoutCodeClick = onClearActiveCode
                )
            }

            // 2. Real-Time Remaining Duration & Progress Gauge Card
            item {
                RemainingDurationGaugeCard(
                    subscription = activeSubscription,
                    effectiveStatus = effectiveStatus,
                    realRemainingDays = realRemainingDays
                )
            }

            // 3. Full Member Personal & Subscription Details Card
            item {
                SubscriptionFullDetailsCard(
                    subscription = activeSubscription,
                    effectiveStatus = effectiveStatus
                )
            }

            // 4. Renewal & New Packages Section Header
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(FieryOrange.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Autorenew,
                                contentDescription = null,
                                tint = FieryOrange,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "تجديد الاشتراك والباقات الجديدة 🔥",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = CrispWhite
                            )
                            Text(
                                text = "جدد باقتك بخصم 50% وأرسل طلب التمديد للإدارة عبر واتساب",
                                style = MaterialTheme.typography.bodySmall,
                                color = FieryOrange
                            )
                        }
                    }
                }
            }

            // 5. All Packages for Renewal / Upgrade
            items(cmsState.packages, key = { it.id }) { pkg ->
                RenewalPackageCard(
                    pkg = pkg,
                    isCurrentPackage = activeSubscription.packageId == pkg.id,
                    onInstantRenew = {
                        onRenewSubscription(activeSubscription.code, pkg)
                        renewalBannerMessage =
                            "تم تسجيل طلب تجديد (${pkg.title}) للكود #${activeSubscription.code}!"
                    },
                    onWhatsAppConfirmRenewal = {
                        onConfirmRenewalViaWhatsApp(activeSubscription, pkg)
                    }
                )
            }
        }
    }

    if (showQrVerificationDialog && activeSubscription != null) {
        QrServerVerificationModal(
            subscription = activeSubscription,
            effectiveStatus = activeSubscription.computeEffectiveStatus(nowUtcMillis),
            realRemainingDays = activeSubscription.computeRealTimeRemainingDays(nowUtcMillis),
            onDismiss = { showQrVerificationDialog = false }
        )
    }
}

@Composable
private fun SubscriptionServerStatusBanner(
    status: SubscriptionStatus,
    orderNumber: String
) {
    val (bgColor, borderColor, title, subtitle) = when (status) {
        SubscriptionStatus.PENDING -> listOf(
            FieryOrange.copy(alpha = 0.16f),
            FieryOrange,
            "تم تسجيل طلبك بنجاح، اشتراكك في انتظار تأكيد الإدارة.",
            "رقم الطلب: ${orderNumber.ifBlank { "مسجل في السيرفر" }} • سيتم تفعيل العداد تلقائياً فور موافقة الإدارة."
        )
        SubscriptionStatus.ACTIVE -> listOf(
            EmeraldSuccess.copy(alpha = 0.14f),
            EmeraldSuccess,
            "اشتراكك مفعل ونشط على السيرفر ✅",
            "يتم احتساب الأيام المتبقية تلقائياً بالتوقيت الفعلي للسيرفر (توقيت مصر)."
        )
        SubscriptionStatus.FROZEN -> listOf(
            Color(0xFF38BDF8).copy(alpha = 0.16f),
            Color(0xFF38BDF8),
            "اشتراكك مجمد مؤقتاً (Frozen) ❄️",
            "تم إيقاف احتساب أيام الاشتراك مؤقتاً وسيتم تمديد تاريخ الانتهاء تلقائياً عند فك التجميد."
        )
        SubscriptionStatus.EXPIRED -> listOf(
            MaterialTheme.colorScheme.error.copy(alpha = 0.18f),
            MaterialTheme.colorScheme.error,
            "انتهت صلاحية اشتراكك ⚠️",
            "يرجى اختيار إحدى الباقات بالأسفل لتجديد اشتراكك."
        )
        SubscriptionStatus.REJECTED -> listOf(
            MaterialTheme.colorScheme.error.copy(alpha = 0.22f),
            MaterialTheme.colorScheme.error,
            "تم رفض طلب الاشتراك من الإدارة ❌",
            "يرجى التواصل مع إدارة كابتن هيما جيم عبر واتساب لمزيد من التفاصيل."
        )
        SubscriptionStatus.CANCELLED -> listOf(
            MutedZinc.copy(alpha = 0.16f),
            MutedZinc,
            "تم إلغاء هذه العضوية 🚫",
            "يمكنك تقديم طلب اشتراك جديد في أي وقت."
        )
    }

    Surface(
        color = bgColor as Color,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.5.dp, borderColor as Color),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title as String,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = CrispWhite
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle as String,
                style = MaterialTheme.typography.bodySmall,
                color = MutedZinc
            )
        }
    }
}

@Composable
private fun Interactive3DGlassVipPassCard(
    subscription: MemberSubscription,
    effectiveStatus: SubscriptionStatus,
    realRemainingDays: Int,
    onOpenQrVerifier: () -> Unit,
    onSwitchCodeClick: () -> Unit,
    onLogoutCodeClick: () -> Unit
) {
    var isBackSide by remember { mutableStateOf(false) }

    Surface(
        shape = RoundedCornerShape(30.dp),
        color = CardSurfaceDark,
        border = BorderStroke(1.8.dp, LuxuryGoldBorderBrush),
        shadowElevation = 26.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Glass3DSurfaceBrush)
                .padding(20.dp)
        ) {
            // Top Header Controls: Flip 3D Card, Switch Code, Logout
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    onClick = { isBackSide = !isBackSide },
                    color = FieryOrange.copy(alpha = 0.18f),
                    shape = RoundedCornerShape(50),
                    border = BorderStroke(1.dp, FieryOrange)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.FlipCameraAndroid,
                            contentDescription = null,
                            tint = FieryOrange,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = if (isBackSide) "الوجه الأمامي للبطاقة" else "الجهة الخلفية - VIP",
                            style = MaterialTheme.typography.labelMedium,
                            color = CrispWhite,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(
                        onClick = onSwitchCodeClick,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SwapHoriz,
                            contentDescription = null,
                            tint = FieryOrange,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "تغيير الكود",
                            style = MaterialTheme.typography.labelMedium,
                            color = CrispWhite
                        )
                    }
                    IconButton(
                        onClick = onLogoutCodeClick,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Logout,
                            contentDescription = "خروج",
                            tint = MutedZinc,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (!isBackSide) {
                // FRONT SIDE OF 3D GLASS VIP PASS (Matches Reference Design)
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = CardSurfaceElevated,
                    border = BorderStroke(1.5.dp, LuxuryGoldBorderBrush),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Glass3DSurfaceBrush)
                            .padding(18.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "VIP",
                                    style = MaterialTheme.typography.displaySmall.copy(
                                        fontWeight = FontWeight.Black,
                                        letterSpacing = 2.sp
                                    ),
                                    color = FieryOrange
                                )
                                Text(
                                    text = "بطاقة العضوية",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = CrispWhite
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = subscription.fullName,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Black,
                                    color = CrispWhite
                                )
                                Text(
                                    text = "#${subscription.code}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = FieryOrange
                                )
                            }

                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // Official Club Logo
                                Image(
                                    painter = painterResource(id = R.drawable.img_official_logo),
                                    contentDescription = "CAPTAIN HIMA FITNESS GYM",
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier
                                        .size(56.dp)
                                        .clip(CircleShape)
                                        .border(1.dp, FieryOrange, CircleShape)
                                )

                                // Interactive QR Code Box
                                Box(
                                    modifier = Modifier
                                        .size(92.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(ObsidianBlack)
                                        .border(1.5.dp, FieryOrange, RoundedCornerShape(12.dp))
                                        .clickable { onOpenQrVerifier() }
                                        .padding(8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    DynamicQrMatrixCanvas(
                                        payload = "CHG|${subscription.code}|${subscription.statusCode}|${subscription.expiresAtUtcMillis ?: 0L}",
                                        size = 74.dp,
                                        foregroundColor = CrispWhite
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                // BACK SIDE OF 3D GLASS VIP PASS ("الجهة الخلفية - VIP" matching reference image)
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = CardSurfaceElevated,
                    border = BorderStroke(1.5.dp, LuxuryGoldBorderBrush),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Glass3DSurfaceBrush)
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // QR Access Code
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(ObsidianBlack)
                                    .border(1.dp, FieryOrange, RoundedCornerShape(14.dp))
                                    .clickable { onOpenQrVerifier() }
                                    .padding(10.dp)
                            ) {
                                Text(
                                    text = "مسح الدخول",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = FieryOrange,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                DynamicQrMatrixCanvas(
                                    payload = "VERIFY|${subscription.code}|${subscription.orderNumber}",
                                    size = 72.dp,
                                    foregroundColor = CrispWhite
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "QR Access Code",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MutedZinc
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            // Freeze days & Terms
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Surface(
                                        color = ObsidianBlack.copy(alpha = 0.8f),
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(1.dp, GlassBorderWhite)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Text("أيام التجميد ❄️", style = MaterialTheme.typography.labelSmall, color = MutedZinc)
                                            Text(
                                                "${subscription.freezeDaysAvailable} يوم",
                                                style = MaterialTheme.typography.labelLarge,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = CrispWhite
                                            )
                                        }
                                    }
                                    Surface(
                                        color = ObsidianBlack.copy(alpha = 0.8f),
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(1.dp, FieryOrange.copy(alpha = 0.6f))
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Text("الدعوات 🎟️", style = MaterialTheme.typography.labelSmall, color = MutedZinc)
                                            Text(
                                                "${subscription.freeInvitationsLeft} دعوات",
                                                style = MaterialTheme.typography.labelLarge,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = FieryOrange
                                            )
                                        }
                                    }
                                }

                                Text(
                                    text = "شروط العضوية VIP:",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = FieryOrange
                                )
                                Text(
                                    text = "✓ الدخول 24 ساعة طوال أيام الأسبوع\n✓ الاستفادة من السبا والجاكوزي والساونا\n✓ التحقق الإلكتروني عبر رمز QR على السيرفر",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CrispWhite.copy(alpha = 0.9f),
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Quick Action Row: Server QR Verify Only (Card sharing removed per request)
            Button(
                onClick = onOpenQrVerifier,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = FieryOrange,
                    contentColor = CrispWhite
                )
            ) {
                Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("فحص وتحقق QR", fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

@Composable
private fun QrServerVerificationModal(
    subscription: MemberSubscription,
    effectiveStatus: SubscriptionStatus,
    realRemainingDays: Int,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .border(1.8.dp, LuxuryGoldBorderBrush, RoundedCornerShape(28.dp)),
            shape = RoundedCornerShape(28.dp),
            color = CardSurfaceDark,
            shadowElevation = 28.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Glass3DSurfaceBrush)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "بوابة التحقق الذكي QR",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = CrispWhite
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = MutedZinc)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Box(
                    modifier = Modifier
                        .size(210.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(ObsidianBlack)
                        .border(2.dp, FieryOrange, RoundedCornerShape(24.dp))
                        .padding(18.dp),
                    contentAlignment = Alignment.Center
                ) {
                    DynamicQrMatrixCanvas(
                        payload = "CAPTAIN_HIMA_SERVER_VERIFY|${subscription.code}|${effectiveStatus.code}|$realRemainingDays",
                        size = 170.dp,
                        foregroundColor = CrispWhite
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Surface(
                    color = ObsidianBlack.copy(alpha = 0.85f),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(
                        1.dp,
                        if (effectiveStatus == SubscriptionStatus.ACTIVE) EmeraldSuccess else FieryOrange
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "حالة التحقق على السيرفر: ${effectiveStatus.labelAr}",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (effectiveStatus == SubscriptionStatus.ACTIVE) EmeraldSuccess else FieryOrange
                        )
                        Text(
                            text = "المشترك: ${subscription.fullName} (#${subscription.code})",
                            style = MaterialTheme.typography.bodyMedium,
                            color = CrispWhite,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "الباقة: ${subscription.packageTitle} • متبقي $realRemainingDays يوم",
                            style = MaterialTheme.typography.bodySmall,
                            color = MutedZinc
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = FieryOrange)
                ) {
                    Text("إغلاق نافذة التحقق", fontWeight = FontWeight.ExtraBold, color = CrispWhite)
                }
            }
        }
    }
}

@Composable
private fun SubscriptionCodeLookupCard(
    inputCode: String,
    onInputCodeChange: (String) -> Unit,
    codeError: String?,
    recentBookings: List<BookingRecord>,
    hasActiveSub: Boolean,
    onCancelSwitch: () -> Unit,
    onSubmitCode: (String) -> Unit,
    onBookNewPackage: () -> Unit
) {
    Surface(
        color = CardSurfaceDark,
        shape = RoundedCornerShape(28.dp),
        border = BorderStroke(1.5.dp, LuxuryGoldBorderBrush),
        shadowElevation = 20.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Glass3DSurfaceBrush)
                .padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (hasActiveSub) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onCancelSwitch) {
                        Text("إلغاء والعودة لبطاقتي الحالية", color = FieryOrange)
                    }
                }
            }

            Image(
                painter = painterResource(id = R.drawable.img_official_logo),
                contentDescription = "CAPTAIN HIMA FITNESS GYM",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape)
                    .border(1.5.dp, FieryOrange, CircleShape)
            )

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "بوابة بطاقة العضوية الرقمية VIP",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.ExtraBold,
                color = CrispWhite,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "أدخل كود الاشتراك الفريد الخاص بك لعرض بطاقة VIP Glass Pass، عداد الأيام المتبقية بالوقت الحقيقي، وحالة موافقة الإدارة.",
                style = MaterialTheme.typography.bodyMedium,
                color = MutedZinc,
                textAlign = TextAlign.Center
            )

            // Show user's recent booked codes if they booked during this session
            if (recentBookings.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(CardSurfaceElevated)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "طلبات الاشتراك المسجلة على جهازك (اضغط للمتابعة):",
                        style = MaterialTheme.typography.labelMedium,
                        color = ChampagneGold
                    )
                    recentBookings.take(3).forEach { booking ->
                        Surface(
                            onClick = { onSubmitCode(booking.referenceCode) },
                            color = FieryOrange.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, FieryOrange.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${booking.fullName} • ${booking.selectedItemName.take(22)}...",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CrispWhite
                                )
                                Text(
                                    text = booking.referenceCode,
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = FieryOrange
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            OutlinedTextField(
                value = inputCode,
                onValueChange = onInputCodeChange,
                label = { Text("اكتب كود الاشتراك الفريد") },
                placeholder = { Text("أدخل الكود الخاص بك") },
                leadingIcon = {
                    Icon(Icons.Default.Key, contentDescription = null, tint = FieryOrange)
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("subscription_code_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = FieryOrange,
                    unfocusedBorderColor = GlassBorderWhite,
                    focusedTextColor = CrispWhite,
                    unfocusedTextColor = CrispWhite
                )
            )

            if (codeError != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = codeError,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.error,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { onSubmitCode(inputCode) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("submit_subscription_code_button"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = FieryOrange,
                    contentColor = CrispWhite
                )
            ) {
                Icon(Icons.Default.Login, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "عرض بطاقة العضوية وتفاصيل الاشتراك 🔑",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(
                onClick = onBookNewPackage,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, FieryOrange.copy(alpha = 0.6f))
            ) {
                Icon(Icons.Default.AddCard, contentDescription = null, tint = FieryOrange)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "مشترك جديد؟ اختر باقتك وأرسل طلب الاشتراك 🔥",
                    color = CrispWhite,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun RemainingDurationGaugeCard(
    subscription: MemberSubscription,
    effectiveStatus: SubscriptionStatus,
    realRemainingDays: Int
) {
    val progressTarget = remember(realRemainingDays, subscription.totalDays) {
        if (subscription.totalDays <= 0) 0f
        else (realRemainingDays.toFloat() / subscription.totalDays.toFloat()).coerceIn(0f, 1f)
    }
    val animatedProgress by animateFloatAsState(
        targetValue = progressTarget,
        animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
        label = "remaining_days_gauge"
    )
    val elapsedDays = (subscription.totalDays - realRemainingDays).coerceAtLeast(0)

    Surface(
        shape = RoundedCornerShape(26.dp),
        color = CardSurfaceDark,
        border = BorderStroke(1.dp, SubtleGlassBorderBrush),
        shadowElevation = 16.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Glass3DSurfaceBrush)
                .padding(20.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Timer,
                    contentDescription = null,
                    tint = FieryOrange,
                    modifier = Modifier.size(22.dp)
                )
                Text(
                    text = "مدة الاشتراك والأيام المتبقية (توقيت مصر الفعلي)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = CrispWhite
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                // Circular Progress Ring matching the reference design
                Box(
                    modifier = Modifier.size(142.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val strokeWidth = 13.dp.toPx()
                        drawArc(
                            color = Color.White.copy(alpha = 0.08f),
                            startAngle = -90f,
                            sweepAngle = 360f,
                            useCenter = false,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                        )
                        drawArc(
                            brush = Brush.sweepGradient(
                                listOf(FieryOrange, Color(0xFFFF9040), EmeraldSuccess, FieryOrange)
                            ),
                            startAngle = -90f,
                            sweepAngle = 360f * animatedProgress,
                            useCenter = false,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "$realRemainingDays",
                            style = MaterialTheme.typography.headlineLarge.copy(fontSize = 36.sp),
                            fontWeight = FontWeight.Black,
                            color = CrispWhite
                        )
                        Text(
                            text = "يوم متبقي",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = FieryOrange
                        )
                        Text(
                            text = "من ${subscription.totalDays} يوم",
                            style = MaterialTheme.typography.labelSmall,
                            color = MutedZinc
                        )
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    DurationMetricTile(
                        label = "تاريخ التفعيل",
                        value = subscription.displayStartDate(),
                        accent = EmeraldSuccess
                    )
                    DurationMetricTile(
                        label = "تاريخ الانتهاء",
                        value = subscription.displayEndDate(),
                        accent = FieryOrange
                    )
                    DurationMetricTile(
                        label = "الحالة الحالية",
                        value = effectiveStatus.code,
                        accent = if (effectiveStatus == SubscriptionStatus.ACTIVE) EmeraldSuccess else FieryOrange
                    )
                    DurationMetricTile(
                        label = "المنقضي",
                        value = "$elapsedDays يوم",
                        accent = CrispWhite
                    )
                }
            }
        }
    }
}

@Composable
private fun DurationMetricTile(
    label: String,
    value: String,
    accent: Color
) {
    Surface(
        color = CardSurfaceElevated,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.35f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MutedZinc
            )
            Text(
                text = value,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.ExtraBold,
                color = accent
            )
        }
    }
}

@Composable
private fun SubscriptionFullDetailsCard(
    subscription: MemberSubscription,
    effectiveStatus: SubscriptionStatus
) {
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = CardSurfaceDark,
        border = BorderStroke(1.dp, GlassBorderWhite),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Glass3DSurfaceBrush)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.AssignmentInd,
                    contentDescription = null,
                    tint = FieryOrange,
                    modifier = Modifier.size(22.dp)
                )
                Text(
                    text = "معلومات العضوية الكاملة",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = CrispWhite
                )
            }

            DetailInfoRow("الاسم:", subscription.fullName)
            DetailInfoRow("رقم العضوية:", "#${subscription.code}")
            if (subscription.orderNumber.isNotBlank()) {
                DetailInfoRow("رقم الطلب:", subscription.orderNumber)
            }
            DetailInfoRow("رقم الهاتف:", subscription.phone)
            DetailInfoRow("القسم:", subscription.genderCategory)
            DetailInfoRow("الباقة:", subscription.packageTitle)
            DetailInfoRow("السعر:", "${subscription.pricePaidEgp} ج.م")
            DetailInfoRow("حالة الاشتراك:", effectiveStatus.labelAr)
            DetailInfoRow("تاريخ الاشتراك:", subscription.displayStartDate())
            DetailInfoRow("تاريخ الانتهاء:", subscription.displayEndDate())
        }
    }
}

@Composable
private fun DetailInfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(CardSurfaceElevated.copy(alpha = 0.7f))
            .padding(horizontal = 12.dp, vertical = 9.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MutedZinc
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold,
            color = CrispWhite,
            textAlign = TextAlign.End
        )
    }
}

@Composable
private fun RenewalPackageCard(
    pkg: MembershipPackage,
    isCurrentPackage: Boolean,
    onInstantRenew: () -> Unit,
    onWhatsAppConfirmRenewal: () -> Unit
) {
    val bgResId = remember(pkg.durationMonths, pkg.id) {
        when {
            pkg.durationMonths >= 12 -> R.drawable.img_gym_weights_1794007816793
            pkg.durationMonths >= 6 -> R.drawable.img_gym_kickboxing_1794007819773
            pkg.durationMonths >= 3 -> R.drawable.img_gym_spa_1794007818150
            else -> R.drawable.img_gym_zumba_1794007817343
        }
    }
    val durationUnitLabel = if (pkg.durationMonths == 1 || pkg.durationMonths >= 11) "شهر" else "شهور"

    Surface(
        shape = RoundedCornerShape(26.dp),
        color = CardSurfaceDark,
        border = BorderStroke(
            width = if (isCurrentPackage || pkg.isPopular || pkg.isVip) 1.8.dp else 1.2.dp,
            brush = if (isCurrentPackage || pkg.isPopular || pkg.isVip) LuxuryGoldBorderBrush else SubtleGlassBorderBrush
        ),
        shadowElevation = 18.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            // Clear athletic background photo without heavy black or white haze
            Image(
                painter = painterResource(id = bgResId),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .matchParentSize()
                    .clip(RoundedCornerShape(26.dp)),
                alpha = 0.52f
            )
            val renewStartAlpha = if (AppThemeController.isDarkMode) 0.66f else 0.48f
            val renewMidAlpha = if (AppThemeController.isDarkMode) 0.50f else 0.32f
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                ObsidianBlack.copy(alpha = renewStartAlpha),
                                CardSurfaceDark.copy(alpha = renewMidAlpha),
                                Color.Transparent
                            )
                        )
                    )
            )
            // Top specular highlight
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.5.dp)
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color.Transparent, FieryOrange, WarmGold, Color.Transparent)
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
            ) {
                // Top Row: Badge + Current Package status
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = if (pkg.isVip) WarmGold.copy(alpha = 0.20f) else FieryOrange.copy(alpha = 0.18f),
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(1.dp, if (pkg.isVip) WarmGold else FieryOrange)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(
                                imageVector = if (pkg.isVip) Icons.Default.WorkspacePremium else Icons.Default.LocalFireDepartment,
                                contentDescription = null,
                                tint = if (pkg.isVip) WarmGold else FieryOrange,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = pkg.badgeText,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = CrispWhite
                            )
                        }
                    }

                    if (isCurrentPackage) {
                        Surface(
                            color = EmeraldSuccess.copy(alpha = 0.18f),
                            shape = RoundedCornerShape(50),
                            border = BorderStroke(1.dp, EmeraldSuccess)
                        ) {
                            Text(
                                text = "باقتك الحالية ⭐",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = EmeraldSuccess,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Middle Row: Title + Perks + Duration Badge + Price Capsule
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Text(
                            text = pkg.title,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black,
                            color = CrispWhite
                        )
                        pkg.perks.take(3).forEach { perk ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = WarmGold,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = perk,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = ChampagneGold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // Right side: Giant Duration Badge + Glowing Price Capsule
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = ObsidianBlack.copy(alpha = 0.86f),
                            border = BorderStroke(1.2.dp, FieryOrange.copy(alpha = 0.65f))
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "${pkg.durationMonths}",
                                    style = MaterialTheme.typography.headlineMedium.copy(
                                        fontSize = 26.sp,
                                        lineHeight = 28.sp
                                    ),
                                    fontWeight = FontWeight.Black,
                                    color = CrispWhite
                                )
                                Text(
                                    text = durationUnitLabel,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = FieryOrange
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(FieryGradientBrush)
                                .border(
                                    width = 1.dp,
                                    color = Color.White.copy(alpha = 0.35f),
                                    shape = RoundedCornerShape(50)
                                )
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "${pkg.discountedPriceEgp} ج.م",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Black,
                                color = CrispWhite
                            )
                        }

                        if (pkg.originalPriceEgp > pkg.discountedPriceEgp) {
                            Text(
                                text = "بدلاً من ${pkg.originalPriceEgp} ج.م",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    textDecoration = TextDecoration.LineThrough
                                ),
                                color = MutedZinc
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Action Buttons Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onInstantRenew,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("renew_pkg_${pkg.id}"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = FieryOrange,
                            contentColor = CrispWhite
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "طلب تمديد (+${pkg.durationMonths * 30} يوم)",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    OutlinedButton(
                        onClick = onWhatsAppConfirmRenewal,
                        modifier = Modifier.height(48.dp),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.2.dp, WhatsAppGreen),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = WhatsAppGreen.copy(alpha = 0.10f),
                            contentColor = WhatsAppGreen
                        )
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = null,
                            tint = WhatsAppGreen,
                            modifier = Modifier.size(17.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "واتساب",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = CrispWhite
                        )
                    }
                }
            }
        }
    }
}

