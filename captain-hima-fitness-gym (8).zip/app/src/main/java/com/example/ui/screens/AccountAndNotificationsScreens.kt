package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.*
import com.example.ui.components.shareTextContent
import com.example.ui.theme.*

@Composable
fun AccountAndSettingsScreen(
    cmsState: CaptainHimaCmsState,
    userSettings: UserSettingsState,
    onUpdateSettings: (UserSettingsState) -> Unit,
    onNavigateToTab: (MainTab) -> Unit,
    onOpenCodeDialog: () -> Unit,
    onLogoutSubscription: () -> Unit
) {
    val context = LocalContext.current
    val activeCode = cmsState.activeSubscriptionCode
    val activeSub = remember(activeCode, cmsState.subscriptions) {
        if (activeCode.isNullOrBlank()) null
        else cmsState.subscriptions.firstOrNull { it.code.equals(activeCode, ignoreCase = true) }
    }
    val effectiveStatus = remember(activeSub) {
        activeSub?.computeEffectiveStatus()
    }
    val remainingDays = remember(activeSub) {
        activeSub?.computeRealTimeRemainingDays() ?: 0
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("account_settings_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. My Account Profile Glass Card ("حسابي")
        item {
            Surface(
                color = CardSurfaceDark.copy(alpha = 0.94f),
                shape = RoundedCornerShape(28.dp),
                shadowElevation = 20.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, LuxuryGoldBorderBrush, RoundedCornerShape(28.dp))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Glass3DSurfaceBrush)
                        .padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.WorkspacePremium,
                                contentDescription = null,
                                tint = FieryOrange,
                                modifier = Modifier.size(24.dp)
                            )
                            Text(
                                text = "حسابي • CAPTAIN HIMA GYM",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = CrispWhite
                            )
                        }
                        if (activeSub != null && effectiveStatus != null) {
                            Surface(
                                color = when (effectiveStatus) {
                                    SubscriptionStatus.ACTIVE -> EmeraldSuccess.copy(alpha = 0.18f)
                                    SubscriptionStatus.PENDING -> WarmGold.copy(alpha = 0.2f)
                                    SubscriptionStatus.FROZEN -> Color(0xFF38BDF8).copy(alpha = 0.2f)
                                    else -> MaterialTheme.colorScheme.error.copy(alpha = 0.2f)
                                },
                                shape = RoundedCornerShape(50),
                                border = BorderStroke(
                                    1.dp,
                                    when (effectiveStatus) {
                                        SubscriptionStatus.ACTIVE -> EmeraldSuccess
                                        SubscriptionStatus.PENDING -> WarmGold
                                        SubscriptionStatus.FROZEN -> Color(0xFF38BDF8)
                                        else -> MaterialTheme.colorScheme.error
                                    }
                                )
                            ) {
                                Text(
                                    text = effectiveStatus.labelAr,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = CrispWhite,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Official Logo / Member Avatar Circle
                    Box(
                        modifier = Modifier
                            .size(92.dp)
                            .clip(CircleShape)
                            .background(ObsidianBlack)
                            .border(2.5.dp, LuxuryGoldBorderBrush, CircleShape)
                            .padding(4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_official_logo),
                            contentDescription = "CAPTAIN HIMA FITNESS GYM",
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = activeSub?.fullName ?: "عضو نادي كابتن هيما جيم",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Black,
                        color = CrispWhite,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = if (activeSub != null) {
                            "#${activeSub.code} • ${activeSub.genderCategory}"
                        } else {
                            "غير مرتبط بكود اشتراك نشط حالياً"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = FieryOrange
                    )

                    if (activeSub != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "${activeSub.packageTitle} • متبقي $remainingDays يوم",
                            style = MaterialTheme.typography.bodySmall,
                            color = MutedZinc,
                            textAlign = TextAlign.Center
                        )
                    } else {
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = onOpenCodeDialog,
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = FieryOrange,
                                contentColor = CrispWhite
                            ),
                            modifier = Modifier.testTag("account_enter_code_button")
                        ) {
                            Icon(Icons.Default.Key, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("إدخال كود الاشتراك لربط حسابك", fontWeight = FontWeight.ExtraBold)
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Navigation Menu Rows matching the reference image
                    AccountMenuRow(
                        icon = Icons.Default.CardMembership,
                        title = "بطاقة العضوية VIP",
                        subtitle = if (activeSub != null) "الكود #${activeSub.code} • QR التفعيل" else "استعرض بطاقة العضوية الثلاثية الأبعاد",
                        onClick = { onNavigateToTab(MainTab.SUBSCRIPTION) },
                        testTag = "account_nav_vip_card"
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    AccountMenuRow(
                        icon = Icons.Default.Verified,
                        title = "الاشتراكات والباقات",
                        subtitle = "استعرض الباقات والخصومات المتاحة وتجديد العضوية",
                        onClick = { onNavigateToTab(MainTab.PACKAGES) },
                        testTag = "account_nav_packages"
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    AccountMenuRow(
                        icon = Icons.Default.NotificationsActive,
                        title = "الإشعارات والتنبيهات",
                        subtitle = "${cmsState.notifications.count { !it.isRead }} إشعارات جديدة من الإدارة",
                        onClick = { onNavigateToTab(MainTab.NOTIFICATIONS) },
                        testTag = "account_nav_notifications"
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    AccountMenuRow(
                        icon = Icons.Default.SupportAgent,
                        title = "تواصل معنا والحجز الفوري",
                        subtitle = "${cmsState.brandInfo.phoneDisplay} • واتساب خدمة العملاء",
                        onClick = { onNavigateToTab(MainTab.BOOK) },
                        testTag = "account_nav_contact"
                    )
                }
            }
        }

        // 2. Interactive 3D Glass Settings Card ("الإعدادات")
        item {
            Surface(
                color = CardSurfaceDark.copy(alpha = 0.94f),
                shape = RoundedCornerShape(28.dp),
                shadowElevation = 18.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, Glass3DHighlightBrush, RoundedCornerShape(28.dp))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Glass3DSurfaceBrush)
                        .padding(20.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = null,
                            tint = FieryOrange,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = "الإعدادات ومظهر التطبيق",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = CrispWhite
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Theme Mode Selector Header & Visual 3D Cards (Dark: Fiery Orange & Black / Light: White & Royal Gold)
                    Text(
                        text = "مظهر التطبيق (الألوان والخطوط)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = CrispWhite
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (userSettings.isDarkMode) {
                            "المظهر الحالي: المظهر الداكن (البرتقالي الناري والأسود الفاخر)"
                        } else {
                            "المظهر الحالي: المظهر الفاتح (الأبيض والذهبي الملكي مع الخط الأسود)"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = FieryOrange,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Dark Mode Option Card (Fiery Orange + Obsidian Black)
                        val isDarkSelected = userSettings.isDarkMode
                        Surface(
                            onClick = {
                                onUpdateSettings(userSettings.copy(isDarkMode = true))
                            },
                            color = Color(0xFF0E1015),
                            shape = RoundedCornerShape(18.dp),
                            border = BorderStroke(
                                width = if (isDarkSelected) 2.dp else 1.dp,
                                color = if (isDarkSelected) Color(0xFFFF5E00) else Color(0x33FFFFFF)
                            ),
                            shadowElevation = if (isDarkSelected) 12.dp else 4.dp,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("theme_mode_dark_button")
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF050507))
                                            .border(1.5.dp, Color(0xFFFF5E00), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DarkMode,
                                            contentDescription = null,
                                            tint = Color(0xFFFF5E00),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    if (isDarkSelected) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = Color(0xFFFF5E00),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "المظهر الداكن",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                                Text(
                                    text = "البرتقالي الناري والأسود",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFFFF7A1A),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }

                        // Light Mode Option Card (Pure White + Royal Gold + Black Text)
                        val isLightSelected = !userSettings.isDarkMode
                        Surface(
                            onClick = {
                                onUpdateSettings(userSettings.copy(isDarkMode = false))
                            },
                            color = Color(0xFFFFFFFF),
                            shape = RoundedCornerShape(18.dp),
                            border = BorderStroke(
                                width = if (isLightSelected) 2.2.dp else 1.dp,
                                color = if (isLightSelected) Color(0xFFB8860B) else Color(0x55D4AF37)
                            ),
                            shadowElevation = if (isLightSelected) 12.dp else 4.dp,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("theme_mode_light_button")
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFFFAF8F3))
                                            .border(1.5.dp, Color(0xFFB8860B), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.LightMode,
                                            contentDescription = null,
                                            tint = Color(0xFFB8860B),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    if (isLightSelected) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = Color(0xFFB8860B),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "المظهر الفاتح",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFF0D0E12)
                                )
                                Text(
                                    text = "الأبيض والذهبي الملكي",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFF8B6508),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    SettingsToggleRow(
                        title = if (userSettings.isDarkMode) "تفعيل المظهر الداكن (البرتقالي الناري)" else "تفعيل المظهر الفاتح (الأبيض والذهبي الملكي)",
                        subtitle = "التبديل بين المظهر الداكن الناري والمظهر الفاتح الملكي بالخط الأسود",
                        checked = userSettings.isDarkMode,
                        onCheckedChange = {
                            onUpdateSettings(userSettings.copy(isDarkMode = it))
                        }
                    )

                    HorizontalDivider(
                        modifier = Modifier.padding(vertical = 10.dp),
                        color = GlassBorderWhite
                    )

                    SettingsToggleRow(
                        title = "تفعيل الإشعارات",
                        subtitle = "استلام تنبيهات تفعيل الاشتراك والعروض ومواعيد الانتهاء",
                        checked = userSettings.notificationsEnabled,
                        onCheckedChange = {
                            onUpdateSettings(userSettings.copy(notificationsEnabled = it))
                        }
                    )

                    HorizontalDivider(
                        modifier = Modifier.padding(vertical = 12.dp),
                        color = GlassBorderWhite
                    )

                    // Renew Card Action Row matching the reference image ("تجديد البطاقة EGP 600.00")
                    val renewPrice = activeSub?.pricePaidEgp
                        ?: cmsState.packages.firstOrNull()?.discountedPriceEgp
                        ?: 600
                    Surface(
                        onClick = { onNavigateToTab(MainTab.SUBSCRIPTION) },
                        color = CardSurfaceElevated,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, FieryOrange.copy(alpha = 0.55f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("settings_renew_card_row")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Autorenew,
                                    contentDescription = null,
                                    tint = FieryOrange,
                                    modifier = Modifier.size(22.dp)
                                )
                                Text(
                                    text = "تجديد البطاقة",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = CrispWhite
                                )
                            }
                            Text(
                                text = "EGP $renewPrice.00",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = FieryOrange
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = onLogoutSubscription,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("account_logout_button"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = FieryOrange,
                            contentColor = CrispWhite
                        )
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (activeSub != null) "تسجيل الخروج / تبديل كود العضوية" else "العودة لشاشة الدخول الرئيسية",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AccountMenuRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        onClick = onClick,
        color = CardSurfaceElevated.copy(alpha = 0.9f),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, GlassBorderWhite),
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(FieryOrange.copy(alpha = 0.16f))
                        .border(1.dp, FieryOrange.copy(alpha = 0.5f), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = FieryOrange,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = CrispWhite
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.labelSmall,
                        color = MutedZinc
                    )
                }
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                contentDescription = null,
                tint = MutedZinc
            )
        }
    }
}

@Composable
private fun SettingsToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = CrispWhite
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MutedZinc
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = CrispWhite,
                checkedTrackColor = FieryOrange,
                uncheckedThumbColor = MutedZinc,
                uncheckedTrackColor = CardSurfaceElevated
            )
        )
    }
}

@Composable
fun NotificationsScreen(
    cmsState: CaptainHimaCmsState,
    onMarkAllRead: () -> Unit,
    onNotificationClick: (GymNotificationItem) -> Unit
) {
    val notifications = cmsState.notifications
    val unreadCount = remember(notifications) { notifications.count { !it.isRead } }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("notifications_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(
                color = CardSurfaceDark.copy(alpha = 0.94f),
                shape = RoundedCornerShape(24.dp),
                shadowElevation = 18.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, LuxuryGoldBorderBrush, RoundedCornerShape(24.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Glass3DSurfaceBrush)
                        .padding(horizontal = 18.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(FieryOrange.copy(alpha = 0.18f))
                                .border(1.dp, FieryOrange, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.NotificationsActive,
                                contentDescription = null,
                                tint = FieryOrange,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "الإشعارات والتنبيهات الفورية",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = CrispWhite
                            )
                            Text(
                                text = if (unreadCount > 0) "لديك $unreadCount إشعارات غير مقروءة" else "جميع الإشعارات مقروءة",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (unreadCount > 0) FieryOrange else MutedZinc
                            )
                        }
                    }

                    if (unreadCount > 0) {
                        TextButton(
                            onClick = onMarkAllRead,
                            modifier = Modifier.testTag("mark_all_notifications_read_button")
                        ) {
                            Text(
                                text = "قراءة الكل",
                                color = FieryOrange,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }
            }
        }

        items(notifications, key = { it.id }) { item ->
            Surface(
                onClick = { onNotificationClick(item) },
                color = CardSurfaceDark.copy(alpha = 0.92f),
                shape = RoundedCornerShape(20.dp),
                shadowElevation = 10.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        width = if (!item.isRead) 1.5.dp else 1.dp,
                        brush = if (!item.isRead) LuxuryGoldBorderBrush else SubtleGlassBorderBrush,
                        shape = RoundedCornerShape(20.dp)
                    )
                    .testTag("notification_card_${item.id}")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Glass3DSurfaceBrush)
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Status Icon Badge matching the reference image (Green check, 50% red circle, Megaphone)
                    when (item.type.uppercase()) {
                        "ACTIVATED" -> {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(EmeraldSuccess.copy(alpha = 0.18f))
                                    .border(1.5.dp, EmeraldSuccess, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = EmeraldSuccess,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                        }
                        "PROMO" -> {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(LikeCrimson.copy(alpha = 0.22f))
                                    .border(1.5.dp, LikeCrimson, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "50%",
                                    style = MaterialTheme.typography.labelLarge.copy(fontSize = 13.sp),
                                    fontWeight = FontWeight.Black,
                                    color = CrispWhite
                                )
                            }
                        }
                        else -> {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(FieryOrange.copy(alpha = 0.18f))
                                    .border(1.5.dp, FieryOrange, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Campaign,
                                    contentDescription = null,
                                    tint = FieryOrange,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = CrispWhite
                            )
                            if (!item.isRead) {
                                Box(
                                    modifier = Modifier
                                        .size(9.dp)
                                        .clip(CircleShape)
                                        .background(FieryOrange)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = item.message,
                            style = MaterialTheme.typography.bodySmall,
                            color = MutedZinc
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = MemberSubscription.formatCairoDateTime(item.createdAtUtcMillis),
                            style = MaterialTheme.typography.labelSmall,
                            color = FieryOrange,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
