package com.example.ui.theme

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object AppThemeController {
    var isDarkMode by mutableStateOf(true)
}

// CAPTAIN HIMA FITNESS GYM – Dynamic Theme Palette:
// - Dark Mode: Obsidian Black + Fiery Orange + Crisp White Text
// - Light Mode: Pure White + Royal Gold + Jet Black Text

val ObsidianBlack: Color
    get() = if (AppThemeController.isDarkMode) Color(0xFF050507) else Color(0xFFFAF8F3)

val CardSurfaceDark: Color
    get() = if (AppThemeController.isDarkMode) Color(0xFF0E1015) else Color(0xFFFFFFFF)

val CardSurfaceElevated: Color
    get() = if (AppThemeController.isDarkMode) Color(0xFF161922) else Color(0xFFF3EFE4)

val GlassBorderWhite: Color
    get() = if (AppThemeController.isDarkMode) Color(0x2EFFFFFF) else Color(0x45B8860B)

val GlassFillWhite: Color
    get() = if (AppThemeController.isDarkMode) Color(0x14FFFFFF) else Color(0x1AB8860B)

// Primary Brand Accents:
// Dark Mode -> Fiery Orange (#FF5E00)
// Light Mode -> Royal Gold (#B8860B & #D4AF37)
val FieryOrange: Color
    get() = if (AppThemeController.isDarkMode) Color(0xFFFF5E00) else Color(0xFFB8860B)

val FieryOrangeDark: Color
    get() = if (AppThemeController.isDarkMode) Color(0xFFD94600) else Color(0xFF8B6508)

val WarmGold: Color
    get() = if (AppThemeController.isDarkMode) Color(0xFFFF7A1A) else Color(0xFFD4AF37)

val ChampagneGold: Color
    get() = if (AppThemeController.isDarkMode) Color(0xFFFFB070) else Color(0xFF8C660A)

val LikeCrimson = Color(0xFFFF2E63)
val WhatsAppGreen = Color(0xFF25D366)
val FacebookBlue = Color(0xFF1877F2)
val InstagramPink = Color(0xFFE1306C)

// Text Colors:
// Dark Mode -> Crisp White (#FFFFFF) & Muted Zinc (#A8AEBD)
// Light Mode -> Jet Black (#0D0E12) & Deep Charcoal (#2D313E)
val CrispWhite: Color
    get() = if (AppThemeController.isDarkMode) Color(0xFFFFFFFF) else Color(0xFF0D0E12)

val MutedZinc: Color
    get() = if (AppThemeController.isDarkMode) Color(0xFFA8AEBD) else Color(0xFF2D313E)

val SubtleZinc: Color
    get() = if (AppThemeController.isDarkMode) Color(0xFF6E7382) else Color(0xFF4B5162)

val EmeraldSuccess: Color
    get() = if (AppThemeController.isDarkMode) Color(0xFF10B981) else Color(0xFF059669)

val FieryGradientBrush: Brush
    get() = if (AppThemeController.isDarkMode) {
        Brush.horizontalGradient(
            colors = listOf(Color(0xFFFF5E00), Color(0xFFFF8533))
        )
    } else {
        Brush.horizontalGradient(
            colors = listOf(Color(0xFFD4AF37), Color(0xFFE6C55A))
        )
    }

val VerticalFieryBrush: Brush
    get() = if (AppThemeController.isDarkMode) {
        Brush.linearGradient(
            colors = listOf(Color(0xFFFF5E00), Color(0xFFD94600))
        )
    } else {
        Brush.linearGradient(
            colors = listOf(Color(0xFFD4AF37), Color(0xFFB8860B))
        )
    }

// 3D Glass Glowing Border Brush (Fiery Orange in Dark Mode / Royal Gold in Light Mode)
val LuxuryGoldBorderBrush: Brush
    get() = if (AppThemeController.isDarkMode) {
        Brush.linearGradient(
            colors = listOf(
                Color(0xFFFF5E00).copy(alpha = 0.9f),
                Color.White.copy(alpha = 0.55f),
                Color(0xFFFF5E00).copy(alpha = 0.35f)
            )
        )
    } else {
        Brush.linearGradient(
            colors = listOf(
                Color(0xFFB8860B),
                Color(0xFFD4AF37),
                Color(0xFF8B6508)
            )
        )
    }

val SubtleGlassBorderBrush: Brush
    get() = if (AppThemeController.isDarkMode) {
        Brush.linearGradient(
            colors = listOf(
                Color.White.copy(alpha = 0.30f),
                Color(0xFFFF5E00).copy(alpha = 0.25f),
                Color.White.copy(alpha = 0.08f)
            )
        )
    } else {
        Brush.linearGradient(
            colors = listOf(
                Color(0xFFD4AF37).copy(alpha = 0.65f),
                Color(0xFFB8860B).copy(alpha = 0.40f),
                Color(0xFFD4AF37).copy(alpha = 0.25f)
            )
        )
    }

val Glass3DSurfaceBrush: Brush
    get() = if (AppThemeController.isDarkMode) {
        Brush.linearGradient(
            colors = listOf(
                Color(0xFF1A1D28).copy(alpha = 0.88f),
                Color(0xFF0D0F14).copy(alpha = 0.94f),
                Color(0xFF181210).copy(alpha = 0.90f)
            )
        )
    } else {
        Brush.linearGradient(
            colors = listOf(
                Color(0xFFFFFFFF),
                Color(0xFFFCF9F2),
                Color(0xFFF6EFE0)
            )
        )
    }

val Glass3DHighlightBrush: Brush
    get() = if (AppThemeController.isDarkMode) {
        Brush.linearGradient(
            colors = listOf(
                Color.White.copy(alpha = 0.18f),
                Color.Transparent,
                Color(0xFFFF5E00).copy(alpha = 0.14f)
            )
        )
    } else {
        Brush.linearGradient(
            colors = listOf(
                Color(0xFFD4AF37).copy(alpha = 0.55f),
                Color(0xFFB8860B).copy(alpha = 0.20f),
                Color(0xFFD4AF37).copy(alpha = 0.40f)
            )
        )
    }
