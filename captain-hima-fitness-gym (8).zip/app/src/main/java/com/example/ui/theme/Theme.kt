package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

private val CaptainHimaDarkColorScheme = darkColorScheme(
    primary = Color(0xFFFF5E00),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFD94600),
    onPrimaryContainer = Color(0xFFFFFFFF),
    secondary = Color(0xFFFF7A1A),
    onSecondary = Color(0xFF050507),
    secondaryContainer = Color(0xFF161922),
    onSecondaryContainer = Color(0xFFFF7A1A),
    tertiary = LikeCrimson,
    background = Color(0xFF050507),
    onBackground = Color(0xFFFFFFFF),
    surface = Color(0xFF0E1015),
    onSurface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFF161922),
    onSurfaceVariant = Color(0xFFA8AEBD),
    outline = Color(0x2EFFFFFF)
)

private val CaptainHimaLightColorScheme = lightColorScheme(
    primary = Color(0xFFB8860B),
    onPrimary = Color(0xFF0D0E12),
    primaryContainer = Color(0xFFD4AF37),
    onPrimaryContainer = Color(0xFF0D0E12),
    secondary = Color(0xFFD4AF37),
    onSecondary = Color(0xFF0D0E12),
    secondaryContainer = Color(0xFFF3EFE4),
    onSecondaryContainer = Color(0xFF8B6508),
    tertiary = LikeCrimson,
    background = Color(0xFFFAF8F3),
    onBackground = Color(0xFF0D0E12),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF0D0E12),
    surfaceVariant = Color(0xFFF3EFE4),
    onSurfaceVariant = Color(0xFF2D313E),
    outline = Color(0x45B8860B)
)

@Composable
fun MyApplicationTheme(
    isDarkMode: Boolean = AppThemeController.isDarkMode,
    content: @Composable () -> Unit
) {
    SideEffect {
        AppThemeController.isDarkMode = isDarkMode
    }
    val colorScheme = if (isDarkMode) CaptainHimaDarkColorScheme else CaptainHimaLightColorScheme

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
