package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.google.firebase.Firebase
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.MemoryCacheSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.junit.After
import org.junit.Before
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowLog
import java.net.HttpURLConnection
import java.net.URL

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
abstract class FirestoreEmulatorTestBase {

    protected lateinit var context: Context
    protected lateinit var db: FirebaseFirestore
    protected lateinit var auth: FirebaseAuth
    protected lateinit var databaseId: String

    companion object {
        const val TEST_PROJECT_ID = "demo-test-project"
        const val FIRESTORE_HOST = "127.0.0.1"
        const val FIRESTORE_PORT = 8085
        const val AUTH_HOST = "127.0.0.1"
        const val AUTH_PORT = 9099
    }

    @Before
    fun baseSetUp() {
        ShadowLog.stream = System.out
        context = ApplicationProvider.getApplicationContext()
        databaseId = context.getString(R.string.firestore_database_id)

        FirebaseApp.clearInstancesForTest()
        FirebaseApp.initializeApp(
            context,
            FirebaseOptions.Builder()
                .setProjectId(TEST_PROJECT_ID)
                .setApplicationId("1:1234567890:android:abcdef")
                .setApiKey("fake-api-key-for-emulator")
                .build()
        )

        auth = Firebase.auth.apply {
            useEmulator(AUTH_HOST, AUTH_PORT)
        }

        db = FirebaseFirestore.getInstance(databaseId).apply {
            useEmulator(FIRESTORE_HOST, FIRESTORE_PORT)
            firestoreSettings = FirebaseFirestoreSettings.Builder()
                .setLocalCacheSettings(MemoryCacheSettings.newBuilder().build())
                .build()
        }
    }

    @After
    fun baseTearDown() {
        db.terminate()
        FirebaseApp.clearInstancesForTest()
    }

    protected suspend fun clearEmulatorData() = withContext(Dispatchers.IO) {
        val docsUrl = URL(
            "http://$FIRESTORE_HOST:$FIRESTORE_PORT/emulator/v1/projects/$TEST_PROJECT_ID/databases/$databaseId/documents"
        )
        (docsUrl.openConnection() as HttpURLConnection).apply {
            requestMethod = "DELETE"
            responseCode
            disconnect()
        }

        val authUrl = URL(
            "http://$AUTH_HOST:$AUTH_PORT/emulator/v1/projects/$TEST_PROJECT_ID/accounts"
        )
        (authUrl.openConnection() as HttpURLConnection).apply {
            requestMethod = "DELETE"
            responseCode
            disconnect()
        }
    }

    protected suspend fun signInTestUser(email: String = "alice@example.com"): String {
        val result = try {
            auth.createUserWithEmailAndPassword(email, "password123").await()
        } catch (_: Exception) {
            auth.signInWithEmailAndPassword(email, "password123").await()
        }
        return requireNotNull(result.user?.uid)
    }
}
