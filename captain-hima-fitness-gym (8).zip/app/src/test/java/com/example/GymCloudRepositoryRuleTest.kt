package com.example

import com.example.data.GymCloudRepository
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test

class GymCloudRepositoryRuleTest : FirestoreEmulatorTestBase() {

    private lateinit var repository: GymCloudRepository

    @Before
    fun setUp() = runBlocking {
        clearEmulatorData()
        repository = GymCloudRepository(context, db)
    }

    @Test
    fun ownerCanCreateAndGetBooking_otherUserIsDenied() = runBlocking {
        signInTestUser("alice@example.com")
        repository.createBooking(
            bookingId = "booking_1",
            referenceCode = "CHG-5555",
            fullName = "محمود نعيم",
            phone = "01039157200",
            genderCategory = "رجال",
            bookingType = "package",
            selectedItemName = "باقة 3 شهور",
            preferredDateTime = "السبت 8 مساءً",
            notes = "تجربة الحجز"
        )

        val fetched = repository.getBooking("booking_1")
        assertNotNull(fetched)
        assertEquals("CHG-5555", fetched?.referenceCode)

        // Sign in as Bob and verify Bob is denied reading Alice's booking
        signInTestUser("bob@example.com")
        try {
            repository.getBooking("booking_1")
            fail("Expected PERMISSION_DENIED when Bob reads Alice's booking")
        } catch (e: RuntimeException) {
            val msg = e.message.orEmpty()
            assertTrue("Expected structured JSON error with path, got: $msg", msg.contains("\"path\":\"bookings/booking_1\""))
            assertTrue("Expected operationType get, got: $msg", msg.contains("\"operationType\":\"get\""))
        }
    }

    @Test
    fun signedInUserCanCreateStoryComment() = runBlocking {
        signInTestUser("alice@example.com")
        repository.addStoryComment(
            commentId = "comment_1",
            storyId = "story_1",
            authorName = "محمود",
            text = "عاش يا كابتن هيما!"
        )
    }
}
