package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.GymCmsRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context and verify gym cms seed state`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("كابتن هيما جيم", appName)

        val repo = GymCmsRepository(context)
        val state = repo.cmsState.value
        assertEquals(5, state.stories.size)
        assertEquals(4, state.packages.size)
        assertTrue(state.groupClasses.isNotEmpty())
    }
}
