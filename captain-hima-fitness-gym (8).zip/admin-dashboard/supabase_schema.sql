-- ============================================================================
-- CAPTAIN HIMA FITNESS GYM — بروتوكول وكود إنشاء قاعدة بيانات Supabase الكامل
-- الحساب الإداري المعتمد: hema.gym0@gmail.com
-- يتحكم بالكامل في: القصص (Stories) + الأخبار والإشعارات (News) + الإعدادات والباقات (Settings) + الاشتراكات والحجوزات
-- ============================================================================

-- 1. جدول إعدادات النادي وأسعار الباقات والروابط (gym_config)
CREATE TABLE IF NOT EXISTS public.gym_config (
    id TEXT PRIMARY KEY DEFAULT 'main',
    admin_email TEXT NOT NULL DEFAULT 'hema.gym0@gmail.com',
    phone_display TEXT NOT NULL DEFAULT '01039157200',
    whatsapp_intl TEXT NOT NULL DEFAULT '201039157200',
    address_ar TEXT NOT NULL DEFAULT 'المنشية سيتي، الدور الثاني، شارع المنشية متفرع من شارع الملك فيصل، الجيزة',
    working_hours TEXT NOT NULL DEFAULT 'مفتوح 24 ساعة يومياً (7 أيام في الأسبوع) + فترات مخصصة للسيدات',
    pkg_1m_price TEXT NOT NULL DEFAULT '600',
    pkg_3m_price TEXT NOT NULL DEFAULT '1250',
    pkg_6m_price TEXT NOT NULL DEFAULT '2000',
    pkg_12m_price TEXT NOT NULL DEFAULT '2750',
    tiktok_url TEXT NOT NULL DEFAULT 'https://www.tiktok.com/@captain_hima_gym',
    facebook_page_url TEXT NOT NULL DEFAULT 'https://www.facebook.com/CaptainHimaGym',
    instagram_url TEXT NOT NULL DEFAULT 'https://www.instagram.com/captain_hima_gym',
    google_maps_url TEXT NOT NULL DEFAULT 'https://www.google.com/maps/place/CAPTAIN+HIMA+GYM/@30.0103345,31.1520416,17z',
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. جدول القصص والفيديوهات (stories) — التحكم في ريلز واستوريهات التطبيق
CREATE TABLE IF NOT EXISTS public.stories (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    subtitle TEXT NOT NULL DEFAULT '',
    badge_text TEXT NOT NULL DEFAULT 'تدريب احترافي • CAPTAIN HIMA',
    category_tag TEXT NOT NULL DEFAULT 'صالة الحديد',
    program_to_book TEXT NOT NULL DEFAULT 'باقة 3 شهور - 1,250 ج.م',
    booking_type_preset TEXT NOT NULL DEFAULT 'اشتراك باقة',
    gender_preset TEXT NOT NULL DEFAULT 'قسم الرجال',
    video_url TEXT DEFAULT NULL,
    audio_track_title TEXT NOT NULL DEFAULT 'Captain Hima Gym Official Audio 🔥',
    likes_count INTEGER NOT NULL DEFAULT 250,
    shares_count INTEGER NOT NULL DEFAULT 45,
    sort_order INTEGER NOT NULL DEFAULT 1,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. جدول الأخبار والإشعارات والعروض الفورية (notifications)
CREATE TABLE IF NOT EXISTS public.notifications (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    type TEXT NOT NULL DEFAULT 'ANNOUNCEMENT',      -- ACTIVATED, PROMO, ANNOUNCEMENT, SUBSCRIPTION
    target_code TEXT NOT NULL DEFAULT 'ALL',        -- ALL لكل العملاء أو كود مشترك محدد مثل KH8492A
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    created_at_utc_millis BIGINT NOT NULL DEFAULT (EXTRACT(EPOCH FROM NOW()) * 1000)::BIGINT
);

-- 4. جدول الاشتراكات والعضويات وحساب الأيام المتبقية (subscriptions)
CREATE TABLE IF NOT EXISTS public.subscriptions (
    code TEXT PRIMARY KEY,                          -- كود الاشتراك الفريد (مثال: KH8492A)
    order_number TEXT NOT NULL DEFAULT '',          -- رقم الطلب (مثال: ORD-294810)
    full_name TEXT NOT NULL,                        -- اسم المشترك الثلاثي
    phone TEXT NOT NULL,                            -- رقم الهاتف / واتساب
    gender_category TEXT NOT NULL DEFAULT 'قسم الرجال',
    package_id TEXT NOT NULL DEFAULT 'pkg_3m',
    package_title TEXT NOT NULL,
    price_paid_egp INTEGER NOT NULL DEFAULT 1250,
    duration_months INTEGER NOT NULL DEFAULT 3,
    total_days INTEGER NOT NULL DEFAULT 90,
    remaining_days INTEGER NOT NULL DEFAULT 90,
    start_date TEXT NOT NULL DEFAULT '',
    end_date TEXT NOT NULL DEFAULT '',
    status_code TEXT NOT NULL DEFAULT 'PENDING',    -- PENDING, ACTIVE, FROZEN, EXPIRED, REJECTED, CANCELLED
    status_ar TEXT NOT NULL DEFAULT 'في انتظار تأكيد الإدارة ⏳',
    created_at_utc_millis BIGINT NOT NULL DEFAULT (EXTRACT(EPOCH FROM NOW()) * 1000)::BIGINT,
    activated_at_utc_millis BIGINT NOT NULL DEFAULT 0,
    expires_at_utc_millis BIGINT NOT NULL DEFAULT 0,
    frozen_at_utc_millis BIGINT NOT NULL DEFAULT 0,
    accumulated_freeze_millis BIGINT NOT NULL DEFAULT 0,
    freeze_days_available INTEGER NOT NULL DEFAULT 14,
    free_invitations_left INTEGER NOT NULL DEFAULT 3,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 5. جدول طلبات الحجز والاشتراك (bookings)
CREATE TABLE IF NOT EXISTS public.bookings (
    id TEXT PRIMARY KEY,
    order_number TEXT NOT NULL,
    reference_code TEXT NOT NULL,
    full_name TEXT NOT NULL,
    phone TEXT NOT NULL,
    gender_category TEXT NOT NULL,
    booking_type TEXT NOT NULL,
    selected_item_name TEXT NOT NULL,
    price_egp INTEGER NOT NULL DEFAULT 1250,
    preferred_date_time TEXT NOT NULL DEFAULT '',
    notes TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'PENDING',
    created_at_utc_millis BIGINT NOT NULL DEFAULT (EXTRACT(EPOCH FROM NOW()) * 1000)::BIGINT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 6. جدول أكواد الاشتراك (subscription_codes)
CREATE TABLE IF NOT EXISTS public.subscription_codes (
    code TEXT PRIMARY KEY,
    is_used BOOLEAN NOT NULL DEFAULT FALSE,
    package_id TEXT NOT NULL,
    package_title TEXT NOT NULL,
    duration_months INTEGER NOT NULL,
    price_egp INTEGER NOT NULL,
    assigned_member_name TEXT NOT NULL DEFAULT '',
    assigned_member_phone TEXT NOT NULL DEFAULT '',
    order_number TEXT NOT NULL DEFAULT '',
    created_at_utc_millis BIGINT NOT NULL DEFAULT (EXTRACT(EPOCH FROM NOW()) * 1000)::BIGINT
);

-- ============================================================================
-- إدخال البيانات الافتراضية الأولية (Initial Seed Data)
-- ============================================================================
INSERT INTO public.gym_config (id, admin_email, phone_display, whatsapp_intl, pkg_1m_price, pkg_3m_price, pkg_6m_price, pkg_12m_price)
VALUES ('main', 'hema.gym0@gmail.com', '01039157200', '201039157200', '600', '1250', '2000', '2750')
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.stories (id, title, subtitle, badge_text, category_tag, program_to_book, sort_order)
VALUES
  ('story_1', 'أقوى صالة حديد Cybex في المنشية 💪🔥', 'أجهزة مستوردة حديثة ومتابعة مع كباتن محترفين على مدار 24 ساعة', 'صالة الحديد • CYBEX PRO', 'صالة الحديد', 'باقة 3 شهور - 1,250 ج.م', 1),
  ('story_2', 'قسم الكيك بوكسينج والفنون القتالية 🥊', 'تمرينات قوة ولياقة عالية لحرق الدهون وبناء العضلات', 'كيك بوكسينج • KICKBOXING', 'الحصص الجماعية', 'باقة 6 شهور - 2,000 ج.م', 2),
  ('story_3', 'منطقة السبا والجاكوزي والساونا الفاخرة 🧖‍♂️', 'استشفاء عضلي كامل بعد التمرين بأعلى معايير النظافة والرفاهية', 'سبا وجاكوزي • VIP SPA', 'السبا والجاكوزي', 'باقة سنة VIP - 2,750 ج.م', 3),
  ('story_4', 'حصص الزومبا والأيروبكس للسيدات فقط 💃', 'خصوصية تامة ومدربات محترفات لحرق حتى 800 سعرة في الحصة', 'زومبا سيدات • LADIES ZUMBA', 'قسم السيدات', 'باقة 3 شهور - 1,250 ج.م', 4)
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.notifications (id, title, message, type, target_code)
VALUES
  ('notif_welcome_1', 'خصم 50% لفترة محدودة في كابتن هيما جيم 🔥', 'اشترك الآن في باقة 3 شهور بـ 1,250 ج.م فقط بدلاً من 2,500 ج.م شامل الحديد والكارديو!', 'PROMO', 'ALL'),
  ('notif_welcome_2', 'تحديث مواعيد حصص الكيك بوكسينج والزومبا ⚡', 'يمكنك الآن حجز حصتك الجماعية مباشرة من التطبيق وتأكيدها عبر واتساب.', 'ANNOUNCEMENT', 'ALL')
ON CONFLICT (id) DO NOTHING;

-- ============================================================================
-- تفعيل الحماية (Row Level Security - RLS) وربط الإدارة بالإيميل hema.gym0@gmail.com
-- ============================================================================
ALTER TABLE public.gym_config ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscription_codes ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.is_captain_hima_admin()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN (auth.jwt() ->> 'email') IN ('hema.gym0@gmail.com', 'Manohegazy595@gmail.com');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- القراءة متاحة لتطبيق العميل (لمزامنة الإعدادات والقصص والأخبار وحالة الاشتراك)
CREATE POLICY "Public read gym_config" ON public.gym_config FOR SELECT USING (true);
CREATE POLICY "Public read stories" ON public.stories FOR SELECT USING (true);
CREATE POLICY "Public read notifications" ON public.notifications FOR SELECT USING (true);
CREATE POLICY "Public read subscriptions" ON public.subscriptions FOR SELECT USING (true);

-- العميل ينشئ طلب اشتراك وحجز جديد بحالة PENDING فقط
CREATE POLICY "Client insert pending subscription" ON public.subscriptions FOR INSERT WITH CHECK (status_code = 'PENDING');
CREATE POLICY "Client insert pending booking" ON public.bookings FOR INSERT WITH CHECK (status = 'PENDING');

-- الإدارة (hema.gym0@gmail.com) تتحكم بالكامل في جميع الجداول (إضافة، تعديل، حذف، تفعيل)
CREATE POLICY "Admin full control gym_config" ON public.gym_config FOR ALL USING (public.is_captain_hima_admin());
CREATE POLICY "Admin full control stories" ON public.stories FOR ALL USING (public.is_captain_hima_admin());
CREATE POLICY "Admin full control notifications" ON public.notifications FOR ALL USING (public.is_captain_hima_admin());
CREATE POLICY "Admin full control subscriptions" ON public.subscriptions FOR ALL USING (public.is_captain_hima_admin());
CREATE POLICY "Admin full control bookings" ON public.bookings FOR ALL USING (public.is_captain_hima_admin());
CREATE POLICY "Admin full control subscription_codes" ON public.subscription_codes FOR ALL USING (public.is_captain_hima_admin());
